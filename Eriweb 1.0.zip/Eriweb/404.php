<div align="center">
  <h1>404 - Sorry This Page does not exist</h1>
  <h4>- <a href="#" onClick="history.go(-1)">Please go to index</a> -</h4>
</div>
