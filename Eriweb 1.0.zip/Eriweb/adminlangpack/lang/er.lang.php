﻿<?php
  /**
   * Language File
   *
   * @package Eriweb
   * English
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('ናብዚ ቦታ ብቀጥታ ምምጻእ ፍቑድ ኣይኮነን');
?>
<?php
  // Global
  define('_SUBMIT', 'ኣረክብ');
  define('_DOWNLOAD', 'ዳውንሎድ');
  define('_CANCEL', 'ሰርዝ');
  define('_EDIT', 'ኣሰናድእ');
  define('_DELETE', 'ደምስስ');
  define('_CUT', 'ካት');
  define('_COPY', 'ኮፒ');
  define('_PASTE', 'ፔስት');
  define('_CHMOD', 'CHMOD');
  define('_UPLOAD', 'ኣፕሎድ');
  define('_PUBLIC', 'ፓብሊክ');
  define('_DAYS', 'መዓልታት');
  define('_WEEKS', 'ሰሙናት');
  define('_MONTHS', 'ወርሒ');
  define('_YEARS', 'ዓመት');
  define('_REGISTERED', 'ምዝጉብ');
  define('_REFRESH', 'ኣሐድስ');
  define('_FREE', '<span style="color:red">ናጻ</span>');
  define('_YES', 'እወ');
  define('_NO', 'ኣይፋል');
  define('_SAVE', 'ሴቭ');
  define('_BACK', 'ድሕሪት');
  define('_CREATED', 'እተሰርሓሉ ዕለት');
  define('_PUBLISHED', 'ተጻሒፉ');
  define('_NOTPUBLISHED', 'ኣይተጻሕፈን');
  define('_USERNAME', 'ስም ተጠቃሚ');
  define('_PASSWORD', 'ፓስዎርድ');
  define('_PAGE_NOT_FOUND', '<span>ኣስተውዕሉ!</span>እዚ እትደርልዩዎ ዘለኹም ገጽ ስሙ ተቐዪሩ፣ ተኣልዩ ወይ ውን ንግዚኡ ዘይተረኽበ ከይከውን!');
  define('_CONTENT_NOT_FOUND', '<div class="msgAlert"><span>ኣስተውዕሉ!</span>ገለ ትሕዝቶ ከም ዘእተኹም ኣረጋግጹ </div>');
  define('_SYSTEM_ERR', '<span>ጌጋ!</span>ገለ ጉድለት ተረኺቡ ኣሎ');
  define('_SYSTEM_PROCCESS', '<span>ኣስተውዕሉ!</span>ዝኾነ ዝስራሕ ነገር የለን');
  define('_REQ_FIELD', 'ግድነት ክምላእ ዘለዎ ');
  define('_ACTIONS', 'ተግባራት');
  define('_DEL_CONFIRM', 'ብርግጽ ነዚ ክትድምስስዎ ትደልዩ ዲኹም?<br /><strong>እዚ ሓንሳብ እንትተጌሩ ክምለስ ኣይከኣልን ኢዩ!!!</strong>');
  define('_REQ1', ' ብ ');
  define('_REQ2', ' ዝተመልከቱ ግድነት ክምልኡ ዘለዎም ኢዮም');
  define('_CON_PAGE', 'ናይ ትሕዝቶ ገጽ');
  define('_EXT_LINK', 'ግዳማዊ ሊንክ');
  define('_HOME', 'ርእሰ-ገጽ');
  define('_YOUAREHERE', 'ኣብዚ ኣለኹም');
  define('_MENU', 'ሜንዩ');
  define('_PAGE', 'ገጽ');
  define('_POST', 'ጽሑፍ');
  define('_MODULE', 'ሞድዩል');
  define('_GALLERY', 'ጋለሪ');
  define('_MEMBERSHIP', 'ኣባልነት');
  define('_TRANSACTION', 'ንግዳዊ ጉዳያት');
  define('_LANGUAGE', 'ቋንቋ');
  define('_IMAGE', 'ስእሊ');
  define('_USER', 'ተጠቃሚ');
  define('_USER_A', 'ንጡፍ ተጠቃሚ');
  define('_USER_I', 'ዘይንጡፍ ተጠቃሚ');
  define('_USER_P', 'ተጠቃሚ ኣብ ትጽቢት');
  define('_USER_B', 'ዝተኸልከለ ተጠቃሚ');
  define('_DELETED', 'ተደምሲሱ!');
  define('_UPDATED', 'ተማዓራርዩ!');
  define('_WELCOME', 'መርሓባ');
  
  // Months
  define('_JAN', 'ጥሪ');
  define('_FEB', 'ለካቲት');
  define('_MAR', 'መጋቢት');
  define('_APR', 'ሚያዝያ');
  define('_MAY', 'ግንቦት');
  define('_JUN', 'ሰነ');
  define('_JUL', 'ሓምለ');
  define('_AUG', 'ነሓሰ');
  define('_SEP', 'መስከረም');
  define('_OCT', 'ጥቅምቲ');
  define('_NOV', 'ሕዳር');
  define('_DEC', 'ታሕሳስ');

  // Months Short
  define('_JA_', 'ጥሪ');
  define('_FE_', 'ለካ');
  define('_MA_', 'መጋ');
  define('_AP_', 'ሚያ');
  define('_MY_', 'ግን');
  define('_JU_', 'ሰነ');
  define('_JL_', 'ሓምለ');
  define('_AU_', 'ነሓሰ');
  define('_SE_', 'መስ');
  define('_OC_', 'ጥቅ');
  define('_NO_', 'ሕዳ');
  define('_DE_', 'ታሕ');
  
  // Day Names
  define('_MONDAY', 'ሰኑይ');
  define('_TUESDAY', 'ሶሉስ');
  define('_WEDNESDAY', 'ረቡዕ');
  define('_THURSDAY', 'ሓሙስ');
  define('_FRIDAY', 'ዓርቢ');
  define('_SATURDAY', 'ቀዳም');
  define('_SUNDAY', 'ሰንበት');

  // Day Names Short
  define('_MON', 'ሰኑ');
  define('_TUE', 'ሶሉ');
  define('_WED', 'ረቡ');
  define('_THU', 'ሓሙ');
  define('_FRI', 'ዓር');
  define('_SAT', 'ቀዳ');
  define('_SUN', 'ሰን');
 
   // Day Names Min
  define('_MO', 'ሰ');
  define('_TU', 'ሶ');
  define('_WE', 'ረ');
  define('_TH', 'ሓ');
  define('_FR', 'ዓ');
  define('_SA', 'ቀ');
  define('_SU', 'ሰን');

   // Sitemap
  define('_SM_SITE_MAP', 'መሐበሪ ሳይት');
  define('_SM_SITE_MAP_TITLE', 'መሐበሪ ሳይት');

   // Admin User Permissions
  define('_UP_POLL', '-- ድምጺ ብምርጫ');
  define('_UP_COMMENTS', '-- ኣገባብ ርእይቶ');
  define('_UP_EVENTS', '-- ዓውደ ኣዋርሕ ምስ መዛግብ');
  define('_UP_GALLERY', '-- ጋለሪ');
  define('_UP_JSLIDER', '-- ስላይደር');
  define('_UP_JTABS', '-- ታብሌታት');
  define('_UP_TWITTS', '-- እዋናውያን ትዊታት');
  define('_UP_NSLIDER', '-- ናይ ዜና ስላይደር');
  define('_UP_RSS', '-- ኣር.ኤስ.ኤስ ፓርሰር');
  define('_UP_DBACKUP', 'ትሕጃ ዳታበይዝ');
  
   // Admin Navigation
  define('_N_MENUS', 'ሜንዩ');
  define('_N_PAGES', 'ገጻት');
  define('_N_POSTS', 'ጽሑፋት');
  define('_N_MODS', 'ሞድዩላት');
  define('_N_MEMBS', 'ኣባልነታት');
  define('_N_MEMBSET', 'ኣገባብ ኣባልነት');
  define('_N_GATES', 'ጌትዌይ');
  define('_N_TRANS', 'ንግዳዊ ጉዳያት');
  define('_N_LAYS', 'መልክዕ ኣቀማምጣ');
  define('_N_USERS', 'ተጠቀምቲ');
  define('_N_CONF', 'ኣሰራርዓ');
  define('_N_EMAILS', 'ዓይነት ኢ-መይል');
  define('_N_NEWSL', 'ፓምፍሌት');
  define('_N_LANGS', 'ኣማሓዳድራ ቋንቋ');
  define('_N_LOGS', 'ኣማሓዳድራ መዝገብ');
  
  define('_N_VIEWS', 'ሳይት ኣርኢ');
  define('_N_LOGOUT', 'ውጻእ');
  define('_N_BACK', 'ትሕጃ');
  define('_N_FM', 'ፋይል ምሕደራ');

   // System Logging
  define('_LG_TITLE1', 'መዝገብ ንምርኣይ');  
  define('_LG_INFO1', 'ኣብዚ ኩሎም መዛግብኩም ክትርእይዎም ትኽእሉ'); 
  define('_LG_SUBTITLE1', 'ናይ ቀረባ ግዜ ዝተፈጸሙ ተግባራት መዝገብ'); 
  define('_LG_EMPTY', 'መዛግብ ባዶ ግበር'); 
  define('_LG_EMPTY_LOGS', 'ሰደቓ መዝገብ ባዶ ግበር');
  define('_LG_STATS_EMPTY', '<span>ኣገናዕ!</span>ሰደቓ መዝገብ ባዶ ኮይኑ!');
  define('_LG_WHEN', 'ዕለት');
  define('_LG_USER', 'ተጠቃሚ');
  define('_LG_IP', 'ኣይ-ፒ');
  define('_LG_TYPE', 'ዓይነት');
  define('_LG_MESSAGE', 'መልእኽቲ መዝገብ');
  define('_LG_LOGOUT', ' ወጺኡ');
  define('_LG_LOGIN', ' ኣትዩ');
  define('_LG_CONTACT_SENT', 'ናይ ወኸሳ ሕቶ ኣረኪቡ');
  define('_LG_COMMENT_SENT', 'ሓድሽ ርእይቶ ኣረኪቡ');
  define('_LG_PROFILE_UPDATED', 'ፕሮፋይል ኣመዓራርዩ');
  define('_LG_PASS_RESET', 'ፓስዎርድ ከምብሓድሽ ሪሰት ክግበረሉ ሓቲቱ');
  define('_LG_USER_REGGED', 'ተመዝጊቡ');
  define('_LG_MEM_ACTIVATED', ' ኣክቲቨይት ናይ');
  define('_LG_PAYMENT_OK', 'ገዚኡ');
  define('_LG_PAYMENT_ERR', 'ዝፈሸለ ኣከፋፍላ ናይ ');
 
  // User Account/Register/Login/Activation
  define('_UA_TITLE1', 'ሕሳብኩም ኣመሓድሩ');   
  define('_UA_INFO1', '<span>ሓበሬታ!</span>ኣብዚ ፕሮፋይልኩም ክትልውጡ ፣ ኣባልነት ከተደንፍዑ ወ.ዘ.ተ ... ትኽእሉ'); 
  define('_UA_SUBTITLE1', 'ኣሰናድኦ ሕሳብ ተጠቃሚ'); 
  define('_UA_UPDATE', 'ፕሮፋይል ኣመሓይሹ'); 
  define('_UA_SEL_MEMBERSHIP', 'ዓይነት ኣባልነትኩም ኣመሓይሹ');
  define('_UA_CUR_MEMBERSHIP', 'ሕጂ ዘሎ ኣባልነት');
  define('_UA_VALID_UNTIL', 'ዘብቅዓሉ ዕለት');
  define('_UA_NO_MEMBERSHIP', 'ኣባልነት የለን');
  define('_UA_ACTIVATE', 'ኣባልነት ኣክቲቨይት ግበሩ');
  define('_UA_UPDATEOK', '<span>ኣገናዕ!</span> ፕሮፋይልኩም ኣመሓዪሽኩሞ ኣለኹም');
  define('_UA_INFO2', 'መእተዊ ንኣባል');
  define('_UA_TITLE2', 'መእተዊ ብሕሳብ');
  define('_UA_SUBTITLE2', '<span>ሓበሬታ!</span>ብኽብረትኩም ናብ ሕሳብኩም ንኽትኣትዉ ብቑዕ ስም-ተጠቃሚን ፓስዎርድን ኣእትዉ');
  define('_UA_LOGINNOW', 'ሕጂ እተዉ');
  define('_UA_CLICKTOREG', 'ንኽትምዝገቡ ኣብዚ ጠውቑ');
  define('_UA_TITLE3', 'ፓስዎርድ ዘጥፈአ');
  define('_UA_SUBTITLE3', '<span>ሓበሬታ!</span>ፓስዎርድኹም ሪሰት ንኽትገብሩ ስም-ተጠቃምን ኢ-መይልኩምን ኣብ ታሕቲ ኣእትዉ። መንነትኩም ንምርግጋጽ ናብ ኢ-መልኩም ገለ ነገር ክስደደልኩም ኢዩ።<br />ነቲ ነገር ምስ ተቐበልኩሞ ፣ ን ሕሳብኩም ሓድሽ ፓስዎርድ ክትመርጹ ክትክእሉ ኢኹም።');
  define('_UA_PASS_RTOTAL', 'ንመታኣማመኒ ነዛ ሕቶ መልሱ? 5 + 5 =');
  define('_UA_PASS_RTOTAL_R', 'ብኽብረትኩም መልሲ ኣእትዉ');
  define('_UA_PASS_RTOTAL_R1', 'ዝኣተወ መልሲ ቅኑዕ ኣይኮነን');
  define('_UA_PASS_RSUBMIT', 'ኣረክብ');
  define('_UA_PASS_R_OK', '<span>ኣገናዕ!</span>ፓስዎርድኹም ተቀዪሩ ኣሎ። ንተወሳኺ ሓበሬታ ኢ-መይልኩም ተወከሱ!');
  define('_UA_PASS_R_ERR', '<span>ጌጋ!</span>ኣብ መስርሕ ገለ ጉድለት ተረኺቡ ኣሎ። ብኽብረትኩም ንኣማሓዳሪ ተወከሱ።');
  define('_UA_TITLE4', 'ምዝገባ ተጠቀምቲ');   
  define('_UA_INFO4', '<span>ምልክታ!</span>ንምምዝጋብ ነዚ ኣብ ታሕቲ ዘሎ ፎርም ምልኡ።'); 
  define('_UA_SUBTITLE4', 'ሕሳብ ስራሕ'); 
  define('_UA_PASSWORD2', 'ፓስዎርድ ድግማ'); 
  define('_UA_PASSWORD2_T', 'ፓስዎርድ ብዉሑዱ 6 ፊደላት ክህልዎ ኣለዎ።'); 
  define('_UA_REG_RTOTAL', 'ንመተኣማመኒ መልሲ ናይዛ ሕቶ እንታይ ኢዩ? 5 + 4 =');
  define('_UA_REG_RTOTAL_R', 'ብኽብረትኩም መልሲ ኣእትዉ።');
  define('_UA_REG_RTOTAL_R1', 'ዝኣተወ መልሲ ቅኑዕ ኣይኮነን');
  define('_UA_REG_ACC', 'ሕሳብ ኣመዝግብ');
  define('_UA_NOMORE_REG', '<span>ምልክታ!</span>ይቕሬታ፣ ኣብዚ ግዜ\'ዚ ተወሳኺ ምዝገባታት ኣይንቕበልን ኢና።');
  define('_UA_MAX_LIMIT', '<span>ምልክታ!</span>ይቕሬታ፣ ንተመዝገቡ ተጠቂምቲ ዝተሓዝአ ቦታ መሊኡ ኢዩ።');
  define('_UA_REG_ERR', '<span>ጌጋ!</span>ኣብ መስርሕ ምዝግባ ገለ ጉድለት ተረኺቡ ኣሎ። ብኽብረትኩም ንኣምሓዳሪ ተወከሱ...');
  define('_UA_REG_OK', '<span>ኣገናዕ!</span>ተመዝጊብኩም ኣለኹም። ንተወሳኺ ሓበሬታ ኢ-መይልኩም ተወከሱ!');
  define('_UA_TITLE5', 'ሕሳብ ኣክቲቨይት');   
  define('_UA_INFO5', '<span>ሓበሬታ!</span>ኣብዚ ሕሳብኩም ኣክቲቨይት ክትገብሩ ትኽእሉ። ብኽብረትኩም ኢ-መይልኩምን ዝተቐበልኩሞ ናይ ኣችቲቬሽን ኮድን ኣእትዉ።'); 
  define('_UA_SUBTITLE5', 'ሕሳብኩም ኣችቲቨይት ግበሩ'); 
  define('_UA_TOKEN', 'ኣችቲቨይት መግበሪ');
  define('_UA_ACTIVATE_ACC', 'ኣችቲቨይት');
  define('_UA_TOKEN_R', 'እዚ ሕሳብ ብዓንተቦኡ ኣችቲቨይት ተጌሩ ኢዩ!');
  define('_UA_TOKEN_R1', 'ኮድ ብቑዕ ኣይኮነን"');
  define('_UA_TOKEN_OK1', '<span>ኣገናዕ!</span>ሕሳብኩም ኣችቲቨይት ተጌሩ!');
  define('_UA_TOKEN_OK2', '<span>ኣገናዕ!</span>ሕጂ ሕሳብኩም ንጡፍ ኮይኑ\'ሎ። እንተኾነ ኣማሓዳሪ ክሳብ ዘፍቅደልኩም ቁሩብ ክትጽበዩ ኢኹም።');
  define('_UA_TOKEN_R_ERR', '<span>ጌጋ!</span>ኣብ መስርሕ ኣክቲቨይሽን ገለ ጉድለት ተረኺቡ ኣሎ። ብኽብረትኩም ንኣማሓዳሪ ተወከሱ።');
  define('_UA_ACC_ERR1', '<span>ጌጋ!</span>ነዚ ገጽ ንምርኣይ ክትምዝገቡ ኣለኩም።');
  define('_UA_ACC_ERR2', '<span>ጌጋ!</span>ነዚ ገጽ ንምርኣይ ብቑዕ ኣባልነት ክህልወኩም ኣለዎ።');
  define('_UA_P_SUMMARY', 'ጽማቝ ሓበሬታ');
  define('_UA_REGISTER', 'መዝግቡ');
  define('_UA_LOGIN', 'እተው');
         
  // Contact Form
  define('_CF_NAME', 'ስም');
  define('_CF_NAME_R', 'ብኽብረትኩም ስምኩም ኣእትዉ');
  define('_CF_TOTAL', 'ንመተኣማመኒ ነዛ ሕቶ መልሱ? 3 + 5 =');
  define('_CF_TOTAL_R', 'ብኽብረትኩም መልሲ ኣእትዉ');
  define('_CF_TOTAL_ERR', 'ዝኣተወ መልሲ ቅኑዕ ኣይኮነን');
  define('_CF_EMAIL', 'ኢ-መይል');
  define('_CF_EMAIL_R', 'ብኽብረትኩም ኢ-መይልኩም ኣእትዉ');
  define('_CF_SUBJECT', 'ርእሰ ጽሑፍ');
  define('_CF_SUBJECT_1', '--- እንታይ ትሓስቡ ኣለኹም? ---');
  define('_CF_SUBJECT_2', 'ናእዳ');
  define('_CF_SUBJECT_3', 'ነቐፌታ');
  define('_CF_SUBJECT_4', 'ርእይቶ');
  define('_CF_SUBJECT_5', 'እወዓውዑ');
  define('_CF_SUBJECT_6', 'ደገፍ');
  define('_CF_SUBJECT_7', 'ካልእ');
  define('_CF_EMAIL_ERR', 'ዝኣተወ ኢ-መይል ብቑዕ ኣይኮነን!');
  define('_CF_MSG', 'መልእኽትኹም');
  define('_CF_MSG_R', 'ብኽብረትኩም መልእኽትኹም ኣእትዉ');
  define('_CF_SEND', 'ሕቶ ኣረክብ');
  define('_CF_SUBJECT1', 'ግብረመልሲ ኢ-መይል ካብ: ');
  define('_CF_ERROR', 'ኢ-መይል በዞም ዝስዕቡ ጌጋታት ክስደድ ኣይከኣለን:');
  define('_CF_OK', '<span>ነመስግን!</span>መልእኽትኹም ተሰዲዱ ኣሎ');
    
  // Admin Backup
  define('_BK_BACKUP_OK', '<span>ኣገናዕ!</span>ትሕጃ ዳታበይዝ ተሰሪሑ ኣሎ!');
  define('_BK_RESTORE_OK', '<span>ኣገናዕ!</span>ዳታበይዝ ናብ ንቡር ተመሊሱ ኣሎ!');
  define('_BK_DELETE_OK', '<span>ኣገናዕ!</span>ትሕጃ ተደምሲሱ ኣሎ!');
  define('_BK_TITLE1', 'ትሕጃታትኩም ኣመሓድሩ');
  define('_BK_INFO1', 'ዳታበይዝኩም ቀጻሊ ትሕጃ ከምዝህልዎ ኣረጋግጹ። ዳታበይዝኩም ባዕልኹም ንምዕቃብ ኣብ \'ትሕጃ ስራሕ\' ዝብል ጠውቑ።<br />
  ትሕጃታት ኣብ [<strong>/admin/backups/</strong>] ዝብል ፎልደር ይቅመጡ፣ ካብዚ ኣብ ታሕቲ ዘሎ ሊስታ ካኣ ዳውንሎድ ክግበሩ ይኽእሉ። <br />
  እቲ ናይ ቀረባ ግዜ ትሕጃ ብሽሮዋይ ሕብሪ ተመልኪቱ ኣሎ።');
  define('_BK_CREATE', 'ትሕጃ ስራሕ');
  define('_BK_SUBTITLE1', 'ናይ ቀረባ ግዜ ትሕጃታት');
  define('_BK_RESTORE_DB', 'ዳታበይዝ ናብ ንቡር ምለስ');
  define('_BK_RESTORE_BK', 'ትሕጃ ናብ ንቡር ምለስ');
  define('_BK_DELETE_BK', 'ትሕጃ ደምስስ');
  
  // Admin Configuration
  define('_CG_UPDATED', '<span>ኣገናዕ!</span>ኣሰራርዓ ሲስተም ተማዓራርዩ ኣሎ!');
  define('_CG_ONLYADMIN', '<span>ሓበሬታ!</span>ይቕሬታ ነዚ ገጽ ዘርኢ መሰል ምሕደራ የብልኩምን');
  define('_CG_TITLE1', 'ኣሰራርዓ ሲስተም');
  define('_CG_INFO1', 'ኣብዚ ኣሰራርዓ ሲስተምኩም ከተማዓራርዩ ትኽእሉ።');
  define('_CG_SUBTITLE1', 'ኣሰራርዓ ሲስተምኩም ኣመዓራርዩ');
  define('_CG_SITENAME', 'ስም ዌብሳይት');
  define('_CG_SITENAME_R', 'ብኽብረትኩም ስም ዌብሳይት ኣእትዉ!');
  define('_CG_SITENAME_T', 'ስም ናይ ዌብሳይት');
  define('_CG_COMPANY', 'ስም ኩባንያ');
  define('_CG_COMPANY_T', 'እዚ ጭርሖ ዌብሳይት ኮይኑ ጥቓ ርእሲ ዌብሳይት ይሰፍር');
  define('_CG_WEBURL', 'ዩ.ኣር.ኤል ናይ ዌብሳይት');
  define('_CG_WEBURL_R', 'ብኽብረትኩም ዩ.ኣር.ኤል ናይ ዌብሳይት ኣእትዉ!');
  define('_CG_WEBURL_T', ' ብኽብረትኩም ምሉእ ዩ.ኣር.ኤል ናይ ዌብሳይት ብዘይ ናይ የማናይ ጫፍ ስላሽ ኣእትዉ (ንኣብነት http://www.yourdomain.com)');
  define('_CG_WEBEMAIL', 'ኢ-መይል ዌብሳይት');
  define('_CG_WEBEMAIL_R', 'ብኽብረትኩም ብቑዕ ኢ-መይል ናይ ዌብሳይት ኣእትዉ!');
  define('_CG_WEBEMAIL_T', 'እዚ እቲ ዋና ናይ ኢ-መይል ምልክታታት ዝስደድዎ ኢ-መይል ኢዩ። ከምኡ ውን <br />ኣውቶማቲክ ኢ-መይል ኣብ ምስዳድ ኣብ ናይ ሰዳዲ ቦታ ዝጸሓፍ ኢ-መይል ንሱ ኢዩ። ');
  define('_CG_THEME', 'መልክዕ ዌብሳይት');
  define('_CG_LOGO', 'ኣርማ ኩባንያ');
  define('_CG_LOGO_B', 'ኣፕሎድ ንምግባር ጠውቑ');
  define('_CG_LOGO_R', 'እዚ ዓይነት ፋይል ኩልኩል ኢዩ። ብዘይካ jpg ፣ png ፣ gif ወይ ውን swf ካልእ ዓይነት ፋይል ኣይፍቀድን።');
  define('_CG_LOGO_DEL', 'ኣርማ ደምስስ');
  define('_CG_LOGO_T', 'ዝኾነ ኣርማ እንተዘየለ ስም ኩባንያ ከም ኣርማ የገልግል');
  define('_CG_OFFLINE', 'ሳይት ኦፍላይን');
  define('_CG_OFFLINE_T', 'ሳይት ንጡፍ እንተዘይሃልዩ ካብ ስራሕ ወጻኢ ምህላዉ ዘመልክት መልእኽቲ ይረአ።<br />ሳይትኩም ንምርኣይ ከም ኣማሓዳሪ ኴንካ እቶ');
  define('_CG_SEO', 'ሰርች ኢንጅን ኦፕቲማይዜሽን(SEO)');
  define('_CG_SEO_T', 'ኣብ ሰርቨርኩም Apache mod_rewrite እንተደኣ ኣሎ \'እወ\' ምረጹ።');
  define('_CG_PERPAGE', 'ቁጽሪ ኣብ ገጽ ዝጸሓፉ ነገራት');
  define('_CG_PERPAGE_T', 'ንፓጂኔሽን ገጻት ዝውሰድ ውሁብ ቁጽሪ');
  define('_CG_SHORTDATE', 'ዕለት ብሓጺር');
  define('_CG_LONGDATE', 'ዕለት ብነዊሕ');
  define('_CG_DTZ', 'ውሁብ ናይ ግዜ ዞባ(ታይም ዞን)');
  define('_CG_DTZ_T', 'ብኽብረትኩም ብቑዕ ናይ ግዜ ዞባ(ታይም ዞን) ምረጹ');
  define('_CG_LANG', 'ውሁብ ቋንቋ');
  define('_CG_LANG_SHOW', 'ቋንቋ ኣርኢ');
  define('_CG_LANG_SHOW_T', 'እወ እንተኾይኑ ፣ ቀያሪ ቋንቋ ናብ ተጠቀምቲ ይረአ።');
  define('_CG_THUMB_WH', 'ቁመት/ጎኒ ስእሊ');
  define('_CG_THUMB_W_R', 'ብኽብረትኩም ጎኒ ስእሊ ኣእትዉ!');
  define('_CG_THUMB_H_R', 'ብኽብረትኩም ቁመት ስእሊ ኣእትዉ!');
  define('_CG_THUMB_WH_T', 'ውሁብ ናይ ስእሊ ጎኒ/ቁመት');
  define('_CG_IMG_WH', 'ቁመት/ጎኒ ስእሊ');
  define('_CG_IMG_W_R', 'ብኽብረትኩም ጎኒ ስእሊ ኣእትዉ!');
  define('_CG_IMG_H_R', 'ብኽብረትኩም ቁመት ስእሊ ኣእትዉ!');
  define('_CG_IMG_WH_T', 'ውሁብ ናይ ዓቢ ስእሊ ጎኒ/ቁመት');
  define('_CG_CURRENCY', 'ውሁብ ባጤራ');
  define('_CG_CURRENCY_R', 'ብኽብረትኩም ብቑዕ ባጤራ ኣእትዉ');
  define('_CG_CURRENCY_T', 'ብኽብረትኩም ባጤራኹም ከም NFA, USD, EUR ኣእትዉ');
  define('_CG_CUR_SYMBOL', 'ምልክት ባጤራ');
  define('_CG_CUR_SYMBOL_T', 'ብኽብረትኩም ምልክት ባጤራኹም ከም Nfa $, &euro;, &pound; ኣእትዉ');
  define('_CG_REGVERIFY', 'ምርግጋጽ ምዝገባ');
  define('_CG_REGVERIFY_T', 'እወ እንተኾይኑ ተጠቀምቲ ኢ-መይሎም የረጋግጹ');
  define('_CG_AUTOVERIFY', 'ኣውቶማቲክ ምዝገባ');
  define('_CG_AUTOVERIFY_T', 'እወ እንተኾይኑ ተጠቀምቲ ድሕሪ ምዝገባ ክኣትዉ ይኽእሉ።<br />ኣይፋል እንተኾይኑ ኣማሓዳሪ ንኩሉ ሕሳብ ከፍቅደሉ ኣለዎ።');
  define('_CG_REGALOWED', 'ምዝገባ ኣፍቅድ');
  define('_CG_REGALOWED_T', 'ምዝገባ ተጠቀምቲ ኣኽእል/ኣይተኽእል');
  define('_CG_NOTIFY_ADMIN', 'ምልክታ ምዝገባ');
  define('_CG_NOTIFY_ADMIN_T', 'ድሕሪ ዝኾነ ምዝገባ ምልክታ ተቐበል');
  define('_CG_USERLIMIT', 'ምዝገባ ተጠቃሚ ኣኽእል/ኣይተኽእል');
  define('_CG_USERLIMIT_T', 'ቁጽሪ ክምዝገቡ ዝፍቀደሉ ተጠቀምቲ መጥን<br /> 0 = ዘይተኣደነ..');
  define('_CG_LOGIN_ATTEMPT', 'ናይ ምኣታው ፈተነታት');
  define('_CG_LOGIN_ATTEMPT_T', 'ኣማሓዳሪ ወይ ተጠቃሚ (x) ናይ ምእታው ፈተነታት ምስፈሸለ ንክንደይ ግዜ ይጽበ?<br /><strong>ውሁብ:</strong> 30 ደቓይቕ (1800) ካልኢታትን 3 ፈተነ ምእታው');
  define('_CG_MAILER', 'ውሁብ ሰዳዲ ኢ-መይል(መይለር)');
  define('_CG_LOG_ON', 'ኩሎም ንጥፈታት መዝግብ');
  define('_CG_LOG_ON_T', 'ኩሉ ናይ ተጠቃሚ/ሲስተም ንጥፈታት ይተኸተል\'ዶ።<br />ምልክታ፣ ብመንጽሩ ክንዱኡ ዝምዕባዩ ዳታ ኣብ ዳታበይዝ ክቕመጥ ኢዩ።');
  define('_CG_MAILER_T', ' PHP Mailer ወይ SMTP ፕሮቶኮል ኢ-መይል ንምስዳድ ተጠቀም።');
  define('_CG_SMTP_HOST', 'ስም ናይ SMTP ማሽን');
  define('_CG_SMTP_HOST_R', 'ብኽብረትኩም ብቑዕ ስም SMTP ማሽን ኣእትዉ!');
  define('_CG_SMTP_HOST_T', 'ቀንዲ SMTP ሰርቨር። ንኣብነት:(mail.yourserver.com)');
  define('_CG_SMTP_USER', 'ስም-ተጠቃሚ SMTP');
  define('_CG_SMTP_USER_R', 'ብኽብረትኩም ብቑዕ ስም-ተጠቃሚ SMTP ኣእትዉ!');
  define('_CG_SMTP_PASS', 'ፓስዎርድ SMTP');
  define('_CG_SMTP_PASS_R', 'ብኽብረትኩም ብቑዕ ፓስዎርድ ኣእትዉ!');
  define('_CG_SMTP_PORT', 'ፖርት SMTP');
  define('_CG_SMTP_PORT_R', 'ብኽብረትኩም ብቑዕ ፖርት SMTP ኣእትዉ!');
  define('_CG_SMTP_PORT_T', 'ናይ ኢ-መይል ሰርቨር ፖርት (25 ወይ 26 ክኸውን ይኽእል። ናይ ጂ-መይል 456 ንYahoo ካኣ 587) ርግጸኛ እንተዘይኴንኩም ንኣአንጋዲ ተወከሱ።');
  define('_CG_GA', 'ናይ ጉግል ጸብጻባት');
  define('_CG_GA_T', 'ናይ ጉግል ጸብጻባት ኮድኩም ኣብዚ ፔስት ግበሩ።');
  define('_CG_GA_I', 'ንናይ ጉግል ጸብጻባት ናብ <a href="http://www.google.com/analytics" target="_blank">ናይ ጉግል ጸብጻባት(Google Analytics)</a>');
  define('_CG_METAKEY', 'ኣብ መላእ ሳይት ዝርከቡ ሜታ-ቃላት');
  define('_CG_METAKEY_T', 'እዞም ሜታ-ቃላት ዌብሳይትኩም ንምግላጽ ይጠቕሙ።');
  define('_CG_METADESC', 'ናይ መላእ ሳይት ሜታ-መግለጺ');
  define('_CG_METADESC_T', 'ሜታ-መግለጺ ሕጽር ዝበለ ጽማቝ ናይ ህሉው ገጽ\'ዩ።');
  define('_CG_UPDATE', 'ኣሰራርዓ ኣመዓራሪ');

  // Admin Email Layout
  define('_ET_TITLE1', 'መልክዕ ኢ-መይልኩም ኣመሓድሩ &rsaquo; መልክዕ ኣሰናድኡ');  
  define('_ET_INFO1', 'ኣብዚ መልክዕ ናይ ኢ-መይልኩም ከተማዓራርዩ ትኽእሉ።'); 
  define('_ET_SUBTITLE1', 'መልክዕ ኢ-መይልኩም ይሰናዳእ ኣሎ &rsaquo; '); 
  define('_ET_TTITLE', 'መልክዕ ኣርእስቲ:'); 
  define('_ET_TTITLE_R', 'ብኽብረትኩም መልክዕ ኣርእስቲ ኣእትዉ!'); 
  define('_ET_SUBJECT', 'ቅዉም ነገር ኢ-መይል'); 
  define('_ET_SUBJECT_T', 'ብኽብረትኩም ቅዉም ነገር ኢ-መይልኩም ኣእትዉ!');
  define('_ET_BODY_R', 'ትሕዝቶ መልክዕ ግድን የድሊ!'); 
  define('_ET_VAR_T', 'ኣብ ውሽጢ [ ] ዘሎ ኣይቅየርን ኢዩ'); 
  define('_ET_UPDATE', 'መልክዕ ኣመዓራርዩ');
  define('_ET_TITLE2', 'መልክዕ ኢ-መይልኩም ኣመዓራርዩ');  
  define('_ET_INFO2', 'መልክዕ ኢ-መይልኩም ኣብ ታሕቲ እነሀ። ትሕዝቶ መልክዕ ከከም ድልየታትኩም ክትቀያይርዎ ትኽእሉ።'); 
  define('_ET_SUBTITLE2', 'መልክዕ ኢ-መይልኩም'); 
  define('_ET_EDIT', 'መልክዕ ኣሰናድኡ ');
  define('_ET_NOTEMPLATE', '<span>ጌጋ!</span>ኩሉ ናይ ኢ-መይልኩም መልክዕ ኣጥፊእኩም ኣለኹም። ከም እንደገና ባዕልኹም ከተእትውዎ ከድልየኩም ኢዩ።');
  define('_ET_UPDATED', '<span>ኣገናዕ!</span>ናይ ኢ-መይልኩም መልክዕ ተማዓራርዩ');

  // Admin Language Manager
  define('_LA_TITLE1', 'ቋንቋታትኩም ኣመዓራርዩ &rsaquo; ቋንቋ ኣሰናድኡ');  
  define('_LA_INFO1', 'ኣብዚ ንቋንቋ ዝምልከት ነገራት ከተመዓራርዩ ትኽእሉ'); 
  define('_LA_SUBTITLE1', 'ቋንቋ ይመዓራረ ኣሎ &rsaquo; ');
  define('_LA_TTITLE', 'ስም ቋንቋ'); 
  define('_LA_TTITLE_R', 'ብኽብረትኩም ስም ቋንቋ ኣእትዉ');
  define('_LA_COUNTRY_ABB', 'ስም ሃገር ብሓጺር');
  define('_LA_COUNTRY_ABB_R', 'ብኽብረትኩም ኣሕጽሮተ ስም ሃገር ኣእትዉ');
  define('_LA_COUNTRY_ABB_ERR', 'ዘእተኹሞ ኣሕጽሮተ ስም ሃገር ሓድሽ ዘይኣተወ ኣይኮነን');
  define('_LA_COUNTRY_ABB_T', 'እዚ እቲ 2 ዝፊደሉ ኮድ ኣሕጽሮተ ስም ሃገር ኢዩ');
  define('_LA_FLAG_ERR', 'እዚ ዝተመርጸ ቋንቋ የለን!');
  define('_LA_UPDATE', 'ቋንቋ ኣመኣራርዩ');
  define('_LA_TITLE2', 'ቋንቋ ኣመዓራርዩ &rsaquo; ቋንቋ ወስኹ');  
  define('_LA_INFO2', 'ኣብዚ ሓድሽ ቋንቋ ከተእትዉ ትኽእሉ.'); 
  define('_LA_SUBTITLE2', 'ቋንቋ ይውሰኽ ኣሎ');
  define('_LA_ADD_INFO', 'ኣብነት ቋንቋ ኣወሳስኻ: <strong>ቋንቋ ዓረብ</strong> ክትውስኹ እንተደሊኹም ፣ ስም ቋንቋ->العربية ኣእትዉ ፣ ኣሕጽሮተ ስም ሃገር->sa ፣ ጸሓፊ->ስም ዌብሳይትኩም ');
  define('_LA_ADD', 'ቋንቋ ወስኽ');
  define('_LA_ADD_NEW', 'ሓድሽ ቋንቋ ወስኹ');
  define('_LA_TITLE3', 'ቋንቋታት ኣመዓራርዩ');  
  define('_LA_INFO3', 'ኣብዚ ዝርከቡ ቋንቋታት ኩሎም ኣብ ታሕቲ ተዘርዚሮም ኣለዉ።<br /><strong>ሓበሬታ: ቋንቋ እንተደምሲስኩም ኩሉ ምስቲ ቋንቋ ዝተሓሓዝ ዘበለ ነገር ከምዝድምሰስ ፍለጡ።</strong>'); 
  define('_LA_SUBTITLE3', 'ቋንቋታት '); 
  define('_LA_EDIT', 'ቋንቋታት ኣሰናድኡ'); 
  define('_LA_FLAG', 'ባንዴራ ሃገር');
  define('_LA_AUTHOR', 'ጸሓፊ');
  define('_LA_NOLANG', '<span>ጌጋ!</span>ኩሉ ናይ ቋንቋታትኩም ፋይላት መልክዕ ኣጥፊእኩም ኣለኹም። ከም እንደገና ባዕልኹም ከተእትውዎም ከድልየኩም ኢዩ።');
  define('_LA_LANG_DELOK', '<span>ኣገናዕ!</span>ቋንቋ ተደምሲሱ ኣሎ');
  define('_LA_LANG_ADDOK', '<span>ኣገናዕ!</span>ቋንቋ ተወሲኹ ኣሎ');
  define('_LA_UPDATED', '<span>ኣገናዕ!</span>ቋንቋ ተማዓራርዩ ኣሎ');
    
  // Admin Newsletter
  define('_NL_TITLE1', 'ፓምፍሌት');  
  define('_NL_INFO1', 'ኣብዚ ንኹሎም ዝመረጽዎ ተጠቀምቲ ፓምፍሌት ክትሰዱሎም ትኽእሉ'); 
  define('_NL_SUBTITLE1', 'ፓምፍሌት ይስደድ ኣሎ'); 
  define('_NL_RECIPIENTS', 'ተቐበልቲ');
  define('_NL_ALL', 'ኩሎም ተጠቀምቲ');
  define('_NL_REGED', 'ዝተመዝገቡ ኣባላት');
  define('_NL_PAID', 'ዝኸፍሉ ኣባላት');
  define('_NL_SUBSCRIBED', 'ፓምፍሌት ዝመረጹ');
  define('_NL_SUBJECT', 'ቅዉም ነገር ፓምፍሌት');
  define('_NL_SUBJECT_R', 'ብኽብረትኩም ቅዉም ነገር ፓምፍሌት ኣእትዉ');
  define('_NL_BODY_R', 'ብኽብረትኩም መልእኽቲ ኢ-መይልኩም ኣእትዉ!');
  define('_NL_SEND', 'ኢ-መይል ስደድ');
  define('_NL_SENT_OK', '<span>ኣገናዕ!</span>ኩሎም ኢ-መይላትኩም ተሰዲዶም ኣለዉ!');
  define('_NL_SENT_ERR', '<span>ጌጋ!</span>ገለ ካብ ኢ-መይላትኩም ክብጽሑ ኣይተኻእሉን!');

  // Admin Gateway
  define('_GW_TITLE1', 'ጌትዌይ ኣመዓራርዩ &rsaquo; ኣሰናድኦ ጌትዌይ');  
  define('_GW_INFO1', 'ኣብዚ ናይ ጌትዌይኩም ኣሰራርዓ ከተመዓራርዩ ትኽእሉ'); 
  define('_GW_SUBTITLE1', 'ጌትዌይ ይሰናዳእ &rsaquo; '); 
  define('_GW_NAME', 'ስም ጌትዌይ'); 
  define('_GW_NAME_R', 'ብኽብረትኩም ስም ጌትዌይ ኣእትዉ');
  define('_GW_LIVE', 'ቀጥታዊ መስርሕ ስርዑ');
  define('_GW_LIVE_T', 'ኣብ ቀጥታዊ መስርሕ ኩሎም ክፍሊታት ኣብ ሓቀኛ ግዜ(real time) ይግበሩ');
  define('_GW_ACTIVE', 'ንጡፍ');
  define('_GW_ACTIVE_T', 'ንኣገባብ ክፍሊት ድሉዋት ዝኾኑ እቶ ንጡፋት ጌትዌያት እዮም');
  define('_GW_IPNURL', 'ዩ.ኣር.ኤል(Url) IPN');
  define('_GW_UPDATE', 'ጌትዌይ ኣመዓራርዩ');
  define('_GW_TITLE2', 'ጌትዌይኩም ኣመዓራርዩ');  
  define('_GW_INFO2', 'ኣብዚ ዝርዝር ናይ ዘለዉኹም ድሉዋት ጌትዌይ ከተማሓድሩ ትኽእሉ'); 
  define('_GW_SUBTITLE2', 'ጌትዌይ');
  define('_GW_EDIT', 'ጌትዌይ ኣሰናድኡ');
  define('_GW_NOGATEWAY', '<span>ጌጋ!</span>ኩሎም ጌትዌያት ጠፊኦምኹም ኣለዉ። ከም እንደገና ባዕልኹም ከተእትውዎም ከድልየኩም ኢዩ።');
  define('_GW_UPDATED', '<span>ኣገናዕ!</span>ኣሰራርዓ ጌትዌይ ተማዓራርዩ');
  
  define('_GW_HELP_PP', '<p><a href="http://www.paypal.com/" title="ፔይ-ፓል(PayPal)" rel="nofollow" target="_blank">ምስ ፔይ-ፓል ሕሳብ ክትሰርሑ ኣብዚ ጠውቑ</a> </p>
			<p><strong>ስም ጌትዌይ</strong> - ስም ናይ ክፍሊት ኣገልግሎት ኣብዚ ኣእትዉ</p>
			<p><strong>ንጥፈት</strong> - ነዚ ናይ ክፍሊት ኣገልግሎት ንጡፍ ንምግባር \'እወ\' ምረጹ <br />
			<p><strong>ናይ ፔይ-ፓል ኢ-መይልኩም</strong> - ናይ ፔይ-ፓል ቢዝነስ(PayPal Business) ኢ-መይልኩም ኣብዚ ኣእትዉ</p>
			<p><strong>ናይ ባጤራ ኮድ</strong> - ናይ ባጤራ ኮድ ኣብዚ ኣእትዉ። ቅቡላት ምርጫታት እዞም ዝስዕቡ ኢዮም: </p>
				<ul>
					<li> NFA (ናቕፋ ኤርትራ)</li>
					<li> USD (ዶላር ኣሜሪካ)</li>
					<li> EUR (ዩሮ) </li>
					<li> GBP (ፓውንድ ስተርሊንግ) </li>
					<li> CAD (ዶላር ካናዳ) </li>
					<li> JPY (የን ጃፓን) </li>
					<li> እንተተገዲፉ, ኩሎም ናይ ገንዘብ ኮዳት ውሁብ ናይ ባጤራ ኮድ ክጥቀሙ እዮም </li>
				</ul>
			<p><strong>ይሰርሕ የለን</strong> - እዚ ቦታ\'ዚ ኣይሰርሕን\'ዩ። ባዶ ይገደፍ </p>
	        <p><strong>ዩ.ኣር.ኤል IPN</strong> - እንድሕሪ ዝደጋገም ክፍሊት ትጥቀሙ ኴንኩም ፣ ኣብ ሕሳብኩም ንIPN ንጡፍ ክትገብሩዎ ይግባእ: </p>');
  define('_GW_HELP_MB', '<p><a href="http://www.moneybookers.com/" title="http://www.moneybookers.net/" rel="nofollow">ምስ ማኒቡከርዝ(MoneyBookers) ሕሳብ ንምስራሕ ኣብዚ ጠውቑ</a></p>
			<p><strong>ስም ጌትዌይ</strong> - ስም ናይ ክፍሊት ኣገልግሎት ኣብዚ ኣእትዉ</p>
			<p><strong>ንጡፍ</strong> - ነዚ ናይ ክፍሊት ኣገልግሎት ንጡፍ ንምግባር \'እወ\' ምረጹ <br />
			<p><strong>ናይ ማኒቡከርዝ ኢ-መይልኩም</strong> - ናይ ማኒቡከርዝ (MoneyBookers) ኢ-መይልኩም ኣብዚ ኣእትዉ </p>
			<p><strong>ፓስዎርድ(Secret Passphrase)</strong> - እዚ ፈለማ ኣብ ናይ ማኒቡከርዝ ዌብሳይት(Moneybookers.com) ክስራሕ ዘለዎ ኢዩ</p>
	        <p><strong>ዩ.ኣር.ኤል(Url) IPN</strong> - እንድሕሪ ዝደጋገም ክፍሊት ትጥቀሙ ኴንኩም ፣ ኣብ ሕሳብኩም ንIPN ንጡፍ ክትገብሩዎ ይግባእ: </p>');
       
  // Admin File manager
  define('_FM_DELOK', '<span>ኣገናዕ!</span>ገለ ካብ ፎልደራትን ፋይላትን ተደምሲሶም ኣለዉ');
  define('_FM_DELOK_DIR', '<span>ኣገናዕ!</span>ካብ ፎልደራት ገለ ተደምስሱ ኣለኹም');
  define('_FM_DELOK_FILE', '<span>ኣገናዕ!</span>ካብ ፋይላት ገለ ተደምስሱ ኣለኹም');
  define('_FM_SEL_ERR', '<span>ኣስተውዕሉ!</span>ብውሑዱ ሓደ ፋይል/ፎልደር ምረጹ');
  define('_FM_DEL_ERR', '<span>ጌጋ!</span>ፋይልን ፎልደርን ኣብ ምድምሳስ ነለ ጉድለት ተረኺቡ ኣሎ');
  define('_FM_DEL_ERR2', '<span>ጌጋ!</span>ተመሪጹ ዘሎ ፋይል ወይ ፎልደር ብቑዕ ኣይኮነን');
  define('_FM_FILENAME_R', '<span>ጌጋ!</span>ብኽብረትኩም ብቑዕ ስም ፋይል ኣእትዉ');
  define('_FM_FILENAME_T', 'ሓድሽ ስም ፋይልኩም ኣእትዉ');
  define('_FM_FILENAME1', '<span>ኣገናዕ!</span>ፋይል ');
  define('_FM_FILENAME2', 'ተሰሪሑ ኣሎ');
  define('_FM_FILENAME_ERR', '<span>ጌጋ!</span>ኣብ ምስራሕ ፋይል ገለ ጉድለት ተረኺቡ ኣሎ');
  define('_FM_DIRPER_OK', '<span>ኣገናዕ!</span>ናይ ምኽፋት ፍቓዳት(Permissions) ተቐያዪሮም ኣለዉ');
  define('_FM_DIRPER_ERR', '<span>ጌጋ!</span>ፍቓዳት ኣብ ምቅይያር ገለ ጉድለት ተረኺቡ ኣሎ።ፍቓዳት ናይ');
  define('_FM_DIR_NAME_R', '<span>ጌጋ!</span>ብኽብረትኩም ስም ፎልደር ኣእትዉ');
  define('_FM_DIR_NAME_T', 'ሓድሽ ስም ፎልደርኩም ኣእትዉ');
  define('_FM_DIR_OK1', '<span>ኣገናዕ!</span>ፎልደር');
  define('_FM_DIR_OK2', 'ተሰሪሑ ኣሎ');
  define('_FM_DIR_ERR', '<span>ጌጋ!</span>ኣብ ምስራሕ ፎልደር ገለ ጉድለት ተረኺቡ ኣሎ');
  define('_FM_DIR_DEL_OK1', '<span>ኣገናዕ!</span>ፎልደር');
  define('_FM_DIR_DEL_OK2', 'ተደምሲሱ ኣሎ');
  define('_FM_DIR_DEL_ERR', '<span>ጌጋ!</span>ኣብ ምድምሳስ ፎልደር ገለ ጉድለት ተረኺቡ ኣሎ');
  define('_FM_PER_OK1', '<span>ኣገናዕ!</span>ፍቓዳት ናይ');
  define('_FM_PER_OK2', 'ተቐዪሮም');
  define('_FM_PER_ERR', '<span>ጌጋ!</span>ፍቓዳት ኣብ ምቅይያር ገለ ጉድለት ተረኺቡ ኣሎ።ፍቓዳት ናይ');
  define('_FM_PER_OCT_ERR', '<span>ጌጋ!</span>ብኽብረትኩም ብቑዕ ነገር ኣእትዉ');
  define('_FM_FILE_OK1', '<span>ኣገናዕ!</span>ፋይል');
  define('_FM_FILE_OK2', 'ተደምሲሱ');
  define('_FM_FILE_ERR', '<span>ጌጋ!</span>ኣብ ምድምሳስ ፋይል ገለ ጉድለት ተረኺቡ ኣሎ');
  define('_FM_NO_DIR1', '<div class="msgError"><span>ጌጋ!</span>"');
  define('_FM_NO_DIR2', 'ፎልደር ኣይኮነን !!!</div>');
  define('_FM_ACCESS1', '<div class="msgError"><span>ጌጋ!</span>');
  define('_FM_ACCESS2', 'ኩልኩል ! <br>ነዚ ፎልደር ንምድምሳስ ዘኽእለኩም ፍቓድ የብልኩምን</div>');
  define('_FM_DELFILE_D', 'ፋይል/ፎልደር ደምስስ');
  define('_FM_DELFILE_DM', 'እዚ ብቐዋምነት ምስተደምሰሰ ፈጺሙ ኣይምለስን ኢዩ። ብርግጽ ክትድምስስዎ ትደልዩ ዲኹም?');
  define('_FM_DELDIR_D', 'ፎልደር ደምስስ');
  define('_FM_DELDIR_DM', 'እዚ ፎልደርን ኩሎም ኣብ ውሽጡ ዝርከቡ ፋይላትን ብቐዋምነት ምስተደምሰሱ ፈጺሞም ኣይምለሱን ኢዮም። ብርግጽ ክትድምስስዎም ትደልዩ ዲኹም?');
  define('_FM_DELMUL_D', 'ብዙሓት ፋይላት/ፎልደራት ደምስስ');
  define('_FM_DELMUL_DM', 'ነዚ ፋይል ወይ ፎልደር ክትድምስስዎ ትደልዩ ዲኩም?');
  define('_FM_CHMOD_D', 'CHMOD ፋይል/ፎልደር');
  define('_FM_CHMOD_DM', 'ብኽብረትኩም ሓድሽ ፍቓድ ኣእትዉ<br />[ x = 1 , w = 2 , r = 4 ] <br />እቲ ቁጽሪ ኦክታዊ(octal-ቁጽርታት ዓዲ 8 [ካብ 0 -ክሳብ- 7] ክኸውን ኣለዎ (0666 , 0755 ወ.ዘ.ተ)');
  define('_CHMOD_I', 'CHMOD ብንጽል');
  define('_CHMOD_M', 'CHMOD ብኣልማማ');
  define('_FM_TITLE', 'ኣመሓዳሪ ፋይል');
  define('_FM_CURDIR', 'ህሉው ፎልደር');
  define('_FM_MFILEUPL', 'ፋይል ኣፕሎድ ብኣልማማ');
  define('_FM_VIEW_ALL', 'ኩሎም ፋይላት');
  define('_FM_SIZE', 'ግዝፊ');
  define('_FM_PERM', 'ፍቓድ');
  define('_FM_NAME', 'ስም');
  define('_FM_PATH', 'መንገዲ ፋይል(Path)');
  define('_FM_CREATE', 'ስራሕ');
  define('_FM_SEL_ALL', 'ንኩሎም ፋይላት ምረጽ ወይ ኣይትምረጽ');
  define('_FM_DIRS', 'ፎልደራት');
  define('_FM_FILES', 'ፋይላት');
  define('_FM_FILE', 'ፋይል');
  define('_FM_DELFILE', 'ፋይል ደምስስ');
  define('_FM_VIEWFILE', 'ፋይል ረአ');
  define('_FM_NEWFILE', 'ሓድሽ ፋይል');
  define('_FM_CHGPER', 'ፍቕዳት ቀይሩ');
  define('_FM_EDITFILE', 'ፋይል ኣሰናድኡ');
  define('_FM_NEWDIR', 'ሓድሽ ፎልደር');
  define('_FM_FILESAVEOK1', '<span>ኣገናዕ!</span>');
  define('_FM_FILESAVEOK2', 'ተዓቂቡ ኣሎ');
  define('_FM_FILESAVEERR1', '<span>ጌጋ!</span>');
  define('_FM_FILESAVEERR2', 'ጉድለት ኣብ ምዕቃብ !!!');
  define('_FM_EDITING', 'ኣሰናድኦ');
  define('_FM_UPLOAD', 'ኣፕሎድ');
  define('_FM_FILSIZE', 'ግዝፊ ፋይል');
  define('_FM_FILEOWNER', 'ወናኒ');
  define('_FM_FILELM', 'ናይ መወዳእታ ዝተቐየረሉ');
  define('_FM_FILEGROUP', 'ጉጅለ');
  define('_FM_FILLA', 'ናይ መወዳእታ ዝተኸፍተሉ');
  define('_FM_UPLOAD_ERR1', 'ጌጋ: እዚ ናይ ኣፕሎድ ፎልደር\'ዚ የለን!');
  define('_FM_UPLOAD_ERR2', 'ጌጋ: እዚ ናይ ኣፕሎድ ፎልደር\'ዚ ክጸሓፈሉ ኣይክእልን(NOT writable) ኢዩ!');
  define('_FM_UPLOAD_ERR3', 'ኣይተመርጸን');
  define('_FM_UPLOAD_ERR4', 'ግጉይ ተለቃቢ ፋይል(Wrong file extension)');
  define('_FM_UPLOAD_ERR5', 'ኣፕሎድ ፈሺሉ። እቲ ፋይል ');
  define('_FM_UPLOAD_ERR6', 'ብዓንተቦኡ ኣብዚ ዝነበረ ማለት\'ዩ።');
  define('_FM_UPLOAD_ERR7', 'ዕዉት ኣፕሎድ።');
  define('_FM_UPLOAD_ERR8', 'ኣፕሎድ ፈሺሉ');
  define('_FM_UPLOAD_ERR9', '<span>ጌጋ!</span>ብኽብረትኩም ኣፕሎድ ዝግበር ፋይል ምረጹ');
  define('_FM_VIEWING', '');
  define('_FM_FILE_SEL', 'ፋይል ምረጽ');
  
  // Admin Get Remote Links
  define('_RL_SELECT', '--- ትሕዝቶ ገጽ ምረጽ ---');
  
  // Admin Layout
  define('_LY_TITLE', 'መልክዕ ኣመዓራርዩ');
  define('_LY_INFO', 'ኣብዚ መልክዕ ከተማዓራርዩ ትኽእሉ።<br />መጀመርታ ነቲ መልክዑ ከተማዓራርዩዎ ዝደለኹም ገጽ ካብ መምረጺ ሕረዩ።');
  define('_LY_SEL_PAGE', '--- ገጽ ምረጹ ---');
  define('_LY_VIEW_FOR', 'መልክዕ ትሕዝቶ');
  define('_LY_NOMODS', '<span>ሓበሬታ!</span>ድሉዋት ሞድዩላት የለዉን');
  
  // Admin Login
  define('_LG_INFO', 'ንኽትኣትዉ ስም-ተጠቃምን/ፓስዎርድን ኣእትዉ');
  define('_LG_BACK', 'ናብ ቅድሚት ተመለስ');
  
  define('_LG_ERROR1', 'ብኽብረትኩም ብቑዕ ስም-ተጠቃምን/ፓስዎርድን ኣእትዉ።');
  define('_LG_ERROR2', 'ስም-ተጠቃምን ፓስዎርድን ምስ ኣብ ዳታበይዝ ዘለዉ ስም-ተጠቃምን/ፓስዎርድን ኣይተዛመዱን');
  define('_LG_ERROR3', 'ሕሳብኩም ተኸልኪሉ ኣሎ');
  define('_LG_ERROR4', 'ሕሳብኩም ንጡፍ የለን');
  define('_LG_ERROR5', 'ኢ-መይልኩም ከተረጋግጹ ኣለኩም');
  define('_LG_BRUTE_RERR', 'ናይ ምእታው ፈተነታት እምብዛ በዚሑ። መሊስኩም ቅድሚ ምፍታንኩም ብኽብረትኩም ን<strong>%MINUTES%</strong> ደቓይቕ ተጸበዩ።');
  
  // Admin Main
  define('_MN_TITLE', 'ናብ መካነ ምሕደራ እንቋዕ ብደሓን መጻእኩም');
  define('_MN_INFO', 'እዚ ናይ ኤሪ-ዌብ ኩለንትናዊ መቆጻጸሪ ኮይኑ፣ ካብዚ ንዌብሳይትኩም ብዘይ ዝኾነ ቴክኒካዊ ፍልጠት ከተመዓራርዩ ትኽእሉ።');
  define('_MN_SUBTITLE', 'እዋናዊ ስታቲስቲካዊ ሓበሬታ');
  define('_MN_INFO2', 'ኣብዚ ናይ በጻሕቲ ስታቲስቲክስ ክትዕዘቡ ትኽእሉ።');
  define('_MN_M_STATS', 'ወርሓዊ ስታቲስቲክስ');
  define('_MN_M_STATS_FOR', 'ወርሓዊ ስታቲስቲክስ ናይ');
  define('_MN_EMPTY_STATS', 'ሰደቓ ስታቲስቲክስ ባዶ ግበር');
  define('_MN_NOSTATS', '<span>ኣስትውዕሉ!</span>ናይ ዝተመርጸ ወርሒ/ዓመት ስታቲስቲካዊ ሓበሬታ የለን።');
  define('_MN_TOTAL_V', 'ጠቕላላ ምብጻሕ');
  define('_MN_TOTAL_H', 'ጠቕላላ ምርኣይ');
  define('_MN_UNIQUE_V', 'ንጽል ምብጻሕ');
  define('_MN_STATS_EMPTY', '<span>ኣገናዕ!</span>ሰደቓ ስታቲስቲክስ ባዶ ኮይኑ!');
  	  
  // Admin Menus
  define('_MU_TITLE1', 'ሜንዩ ኣመዓራርዩ &rsaquo; ሜንዩ ኣሰናድኡ');  
  define('_MU_INFO1', 'ኣብዚ ንሜንዩ ዝምልከት ምትዕርራያት ክትገብሩ ትኽእሉ'); 
  define('_MU_SUBTITLE1', 'ትሕዝቶ ሜንዩ ኣሰናድኡ &rsaquo; '); 
  define('_MU_NAME', 'ስም ሜንዩ'); 
  define('_MU_NAME_R', 'ብኽብረትኩም ስም ሜንዩ ኣእትዉ'); 
  define('_MU_NAME_T', 'ስም ናይ ሜንዩ ኣብ ዌብሳይት ከም መማእዘኒ ክረአ ኢዩ');
  define('_MU_MENUS', 'ሜንዩ'); 
  define('_MU_PARENT', 'ልዕሊኡ ዝርከብ ሜንዩ'); 
  define('_MU_TOP', 'እቲ ዝለዓለ'); 
  define('_MU_TOP_T', 'ካብ መምረጺ ሕረዩ፣ ወይ ልዕሊኡ ሜንዩ እንተዘየለ &quot;እቲ ዝለዓለ&quot; ዝብል ከም ዘለዎ ግደፍዎ።'); 
  define('_MU_TYPE', 'ዓይነት ትሕዝቶ'); 
  define('_MU_TYPE_R', 'ብኽብረትኩም ዓይነት ትሕዝቶ ምረጹ');
  define('_MU_TYPE_SEL', '--- ዓይነት ትሕዝቶ ምረጹ ---');
  define('_MU_TYPE_SEL_T', 'እዚ ሜንዩ\'ዚ ናብ ዝስዕብ ይወስድ:<br />ናይ ትሕዝቶ ገጽ<br />ግዳማዊ ሊንክ');
  define('_MU_LINK', 'ናይ ትሕዝቶ ሊንክ');
  define('_MU_LINK_T', 'http:// ኢሉ ዝጅምር ሙሉእ ዩ.ኣር.ኤል(full url) ኣእትዉ');
  define('_MU_TARGET', '--- Target ---');
  define('_MU_TARGET_S', '_Self');
  define('_MU_TARGET_B', '_Blank');
  define('_MU_PUB', 'ሜንዩ ተጻሒፉ');
  define('_MU_HOME', 'ርእሰ-ገጽ');
  define('_MU_HOME_T', ' "እወ" እንተኾይኑ እዚ እቲ ውሁብ ሜንዩ ርእሰ-ገጽ ይኸውን');
  define('_MU_UPDATE', 'ሜንዩ ኣመዓራርዩ');
  define('_MU_TITLE2', 'ሜንዩ ኣመዓራርዩ');
  define('_MU_INFO2', 'ነዚ ኣብ ታሕቲ ዘሎ ፎርም ተጠቂምኩም ሓድሽ ኣብ ዌብሳይት ዝረአ መማእዘኒ መንዩ ስርሑ<br />');
  define('_MU_SUBTITLE2', 'ሓድሽ ሜንዩ ይውሰኽ ኣሎ');
  define('_MU_NONE', '--- ወላሓደ ---');
  define('_MU_ADD', 'ሜንዩ ወስኽ');
  define('_MU_SAVE', 'ቦታ ሜንዩ ዓቅብ');
  define('_MU_UPDATED', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!');
  define('_MU_ADDED', '<span>ኣገናዕ!</span>ሜንዩ ተማዓራርዩ ኣሎ!');
  define('_MU_SORTED', '<span>ኣገናዕ!</span>ሜንዩ ተወጊኑ ኣሎ!');
  
  // Admin Modules
  define('_MO_TITLE1', 'ገጻት ኣመዓራርዩ &rsaquo; ሞድዩል ኣሰናድኡ');  
  define('_MO_INFO1', 'ኣብዚ ሞድዩልኩም ከተመዓራርዩ ትኽእሉ'); 
  define('_MO_SUBTITLE1', 'ሞድዩል ኣሰናድኡ &rsaquo;');
  define('_MO_TITLE', 'ኣርእስቲ ሞድዩል');
  define('_MO_TITLE_R', 'ብኽብረትኩም ናይ ሞድዩል ኣርእስቲ ኣእትዉ');
  define('_MO_PUB', 'ሞድዩል ተጻሒፉ');
  define('_MO_SHOW_TITLE', 'ኣርእስቲ ኣርኢ');
  define('_MO_ALT_CLASS', 'ተወሳኺ ክላስ');
  define('_MO_ALT_CLASS_T', 'ሞድዩል ንምምልኻዕ ተወሰኽቲ ናይ css ክላሳት ክትገብሩ ትኽእሉ');
  define('_MO_BODY', 'ትሕዝቶ ሞድዩል');
  define('_MO_DESC', 'መግለጺ ናይ ሞድዩል');
  define('_MO_UPDATE', 'ሞድዩል ኣመዓራርዩ');
  define('_MO_TITLE2', 'ሞድዩል ኣመዓራርዩ &rsaquo; ሞድዩል ወስኹ');
  define('_MO_INFO2', 'ኣብዚ ሓድሽ ሞድዩል ክትውስኹ ትኽእሉ ');
  define('_MO_SUBTITLE2', 'ሞድዩል ወስኽ');
  define('_MO_ADD', 'ሓድሽ ሞድዩል ወስኽ');
  define('_MO_TITLE3', 'ሞድዩል ኣመዓራርዩ');
  define('_MO_INFO3', 'ኣብዚ ሞድዩልኩም ከተመዓራርዩ ትኽእሉ');
  define('_MO_SUBTITLE3', 'ሞድዩላት ');
  define('_MO_CREATED', 'ሞድዩል ተሰሪሑ');
  define('_MO_PUB2', 'ተጻሒፉ');
  define('_MO_EDIT', 'ሞድዩል ኣሰናድኡ');
  define('_MO_CONFIG', 'ስርዑ');
  define('_MO_SYS', 'ሞድዩል ');
  define('_MO_NOMOD', '<span>ኣስተውዕል!</span>ዝኾነ ሞድዩል የብልኩምን');
  define('_MO_UPDATED', '<span>ኣገናዕ!</span>ሞድዩል ተመዓራርዩ ኣሎ!');
  define('_MO_ADDED', '<span>ኣገናዕ!</span>ሞድዩል ተወሲኹ ኣሎ!');

  // Admin Memberships
  define('_MS_TITLE1', 'ኣባልነት ኣመዓራርዩ &rsaquo; ኣባልነት ኣሰናድኡ');
  define('_MS_INFO1', 'ኣብዚ ንኣባልነት ዝምልከት ምትዕርራያት ክትገብሩ ትኽእሉ');
  define('_MS_SUBTITLE1', 'ኣሰናድኦ ኣባልነት &rsaquo; ');
  define('_MS_TITLE', 'ኣርእስቲ ኣባልነት');
  define('_MS_TITLE_R', 'ብኽብረትኩም ኣርእስቲ ኣባልነት ኣእትዉ!');
  define('_MS_PRICE', 'ዋጋ ናይ ኣባልነት');
  define('_MS_PRICE_R', 'ብኽብረትኩም ብቑዕ ዋጋ ኣእትዉ!');
  define('_MS_PRICE_T', 'ዋጋ ብ0.00 መልክዕ ኣእትዉ ');
  define('_MS_PERIOD', 'ናይ ኣባልነት ግዜ');
  define('_MS_PERIOD_R', 'ብኽብረትኩም ናይ ኣባልነት ግዜ ኣእትዉ!');
  define('_MS_PERIOD_R2', 'ግዜ ብቑጽሪ ክኸውን ኣለዎ!');
  define('_MS_PERIOD_T', 'ኣባልነት ቅድሚ ምብቅዑ ዘሎ ግዜ።<br />ብቑዓት ቁጽርታት ዝስዕቡ ኢዮም:<br />
  	  ዝፍቀድ መዓልታት ካብ 1 ክሳብ 90<br />
  	  ዝፍቀድ ሰሙናት ካብ 1 ክሳብ 52<br />
      ዝፍቀድ ኣዋርሕ ካብ 1 ክሳብ 24<br />
      ዝፍቀድ ዓመታት ካብ 1 ክሳብ 5');
  define('_MS_TRIAL', 'ናይ ፈተነ ኣባልነት');
  define('_MS_TRIAL_T', 'ናይ ፈተነ ኣባልነት ንሓደ ግዜ ጥራይ ይኸውን።<br /> ብጠቕላላ 1 ናይ ፈተነ ኣባልነት ጥራይ ክህሉ ኣለዎ');
  define('_MS_RECURRING', 'ተደጋጋሚ ክፍሊት');
  define('_MS_RECURRING_T', '');
  define('_MS_PRIVATE', 'ናይ ግሊ ኣባልነት');
  define('_MS_PRIVATE_T', 'ናይ ግሊ ኣባልነት ንተራ ተጠቀምቲ ኣይወሃብን።');
  define('_MS_ACTIVE', 'ኣባልነት ንጡፍ ግበር');
  define('_MS_ACTIVE_T', 'ብዘይካ ንጡፍ ኣባልነት ንዘለዎም ንኻልኦት ክፍሊት የለን።');
  define('_MS_DESC', 'መግለጺ ኣባልነት');
  define('_MS_UPDATE', 'ኣባልነት ኣመዓራርዩ ኣሎ');
  define('_MS_TITLE2', 'ኣባልነት ኣመዓራርዩ &rsaquo; ኣባልነት ወስኽ');
  define('_MS_INFO2', 'ኣብዚ ሓድሽ ዓይነት ኣባልነት ክትውስኹ ትኽእሉ');
  define('_MS_SUBTITLE2', 'ኣባልነት ወስኽ');
  define('_MS_ADD', 'ኣባልነት ወስኽ');
  define('_MS_ADD_NEW', 'ሓድሽ ኣባልነት ወስኹ');
  define('_MS_TITLE3', 'ኣባልነት ኣመዓራርዩ ');
  define('_MS_INFO3', 'ኣብዚ ንኣባልነት ዝምልከት ምምዕርራያት ክትገብሩ ትኽእሉ።<br /><strong>ምልክታ: ንንጡፋት ተጠቀምቲ ዝተዋህበ ኣባልነት ትድምስሱ ከትህልዉ ኣረጋግጹ።</strong>');
  define('_MS_SUBTITLE3', 'ንኣባልነት ዝምልከት');
  define('_MS_EDIT', 'ኣባልነት ኣሰናድኡ');
  define('_MS_TITLE4', 'ኣርእስቲ');
  define('_MS_PRICE2', 'ዋጋ');
  define('_MS_EXPIRY', 'ዘብቅዓሉ');
  define('_MS_DAYS2', ' መዓልታት');
  define('_MS_DESC2', 'መግለጺ');
  define('_MS_ACTIVE2', 'ንጥፈት');
  define('_MS_NOMBS', '<span>ኣስተውዕሉ!</span>ዝኾነ ንኣባልነት ዝምልከት ነገር የለን።');
  define('_MS_UPDATED', '<span>ኣገናዕ!</span>ኣባልነት ተማዓራርዩ ኣሎ!');
  define('_MS_ADDED', '<span>ኣገናዕ!</span>ኣባልነት ተወሲኹ ኣሎ!');
  define('_MS_TRIAL_USED', '<span>ሓበሬታ!</span>ይቕሬታ፣ ናይ ፈተነ ኣባልነትኩም ተጠቂምምኩሙሉ ኢኹም!');
  define('_MS_MEM_ACTIVE_OK', '<span>ኣገናዕ!</span>ኣባልነት ንጡፍ ኣግቢርኩም ኣለኹም ');
  define('_MS_MEM_ACTIVE_ERR', '<span>ጌጋ!</span>ኣባልነትኩም ንጡፍ ኣብ ምግባር ገለ ጉድለት ተረኺቡ ኣሎ። ብኽብረትኩም ንኣመሓዳሪ ተወከሱ!');


  // Admin Transactions
  define('_TR_TITLE1', 'ናይ ኣባልነት ንግዳዊ ጉዳያት ኣመዓራርዩ');
  define('_TR_INFO1', 'ኣብዚ ኩሉ ንንግዳዊ ጉዳያት ዝምልከት ክትርእዩ ትኽእሉ');
  define('_TR_SUBTITLE1', '');
  define('_TR_FINDPAY', 'መጠን ክፍሊት...');
  define('_TR_SHOW_FROM', 'ካብ');
  define('_TR_SHOW_TO', 'ናብ');
  define('_TR_FIND', 'ድለይ');
  define('_TR_EXPORTXLS', 'ናብ ቅዲ ኤክሰል ኣውጽእ');
  define('_TR_VIEW_REPORT', 'ጸብጻብ');
  define('_TR_PAY_FILTER', 'መጻረዪ ክፍሊት');
  define('_TR_RESET_FILTER', '-- መጻረዪ ክፍሊት ሪሰት --');
  define('_TR_MEMNAME', 'ስም ኣባልነት');
  define('_TR_USERNAME', 'ስም-ተጠቃሚ');
  define('_TR_AMOUNT', 'መጠን ግንዘብ');
  define('_TR_PAYDATE', 'ዕለት ክፍሊት');
  define('_TR_PROCESSOR', 'ፕሮሰሰር');
  define('_TR_STATUS', 'ኩነታት');
  define('_TR_NOTRANS', '<span>ኣስተውዕሉ!</span>ዝኾነ ንግዳዊ ጉዳያት የለን።');
  define('_TR_TITLE2', 'ናይ ኣባልነት ሽያጥ');
  define('_TR_INFO2', 'ኣብዚ ናይ መሸጣ ጸብጻብ ክረአ ይከኣል');
  define('_TR_SUBTITLE2', 'ጸብጻብ መሸጣ');
  define('_TR_SALES3', 'ስታቲስቲክስ-መሸጣ ናይ ');
  define('_TR_MONTHSALES3', 'ወርሓዊ ስታቲስቲክስ-መሸጣ ናይ ');
  define('_TR_MONTHVIEW', 'ናብ ወርሓዊ ቀይር');
  define('_TR_YEARVIEW', 'ናብ ዓመታዊ ቀይር');
  define('_TR_MONTHSTATS', 'ወርሓዊ ስታቲስቲክስ');
  define('_TR_SALEITEMS', ' ነገራት');
  define('_TR_TOTSALES', 'ጠቕላላ መሸጣታት');
  define('_TR_TOTREV', 'ጠቕላላ ኣታዊ');
  define('_TR_AVERAGE', 'ገምጋም መሸጣ');
  define('_TR_MONTHYEAR', 'ወርሒ / ዓመት');
  define('_TR_TOTALYEAR', 'ጠቕላላ ዓመት');
  define('_TR_NOYEARSALES', '<span>ኣስተውዕሉ!</span>ናይ ዝተመርጸ ዓመት ሽያጥ የለን');
  define('_TR_NOMONTHSALES', '<span>ኣስተውዕሉ!</span>ናይ ዝተመርጸ ዓመት ሽያጥ የለን');
    
  // Admin Pages
  define('_PG_TITLE1', 'ገጻት ኣመዓራርዩ &rsaquo; ገጽ ኣሰናድኡ');
  define('_PG_INFO1', 'ኣብዚ ገጻት ከተመዓራርዩ ትኽእሉ.');
  define('_PG_SUBTITLE1', 'ገጽ ኣሰናድኡ &rsaquo; ');
  define('_PG_TITLE', 'ኣርእስቲ ገጽ');
  define('_PG_TITLE_R', 'ብኽብረትኩም ኣርእስቲ ገጽ ኣእትዉ');
  define('_PG_SLUG', 'ሳጓ ገጽ');
  define('_PG_SLUG_T', 'እዚ ሳጓ ኣብ መማእዘኒ ብራውዘር ይረአ።<br />ጥርሑ እንተተገዲፉ ግን ኣርእስቲ ገጽ ይረአ።');
  define('_PG_NO_POSTS', 'ኣብ\'ዚ ገጽ\'ዚ ዝኾነ ጽሑፍ የለን!');
  define('_PG_YES_POSTS', 'ኣብ\'ዚ ገጽ ዘለዉ ጽሑፋት');
  define('_PG_PUB', 'ምዝርጋሕ ገጽ');
  define('_PG_CC', 'ፎርም ናይ ወኸሳ ኣተሓሕዝ');
  define('_PG_CC_T', 'እዚ ምርጫ\'ዚ ወኸሳታት ካብ ትሕዝቶ ንክትውስኹ የኽእለኩም።<br/>እቲ ናይ ወኸሳ ፎርም ድሕሪ እቲ ትሕዝቶ ይቕመጥ።');
  define('_PG_GAL', 'ጋለሪ ኣተሓሕዝ');
  define('_PG_COMMENTS', 'ርእይቶ ኣፍቅድ');
  define('_PG_COMMENTS_T', ' \'እወ\' እንተኾይኑ ብዛዕባ\'ዚ ገጽ ርእይቶታት ክህልዉ ኢዮም።<br/>እቶም ርእይቶታት ድሕሪ ትሕዝቶኹም ይሰፍሩ።');
  define('_PG_MEMBERSHIP_R', 'ብኽብረትኩም እንተወሓደ ሓደ ዓይነት ኣባልነት ምረጹ');
  define('_PG_GAL_SEL', '--- ጋለሪ ምረጹ ---');
  
  define('_PG_ACCESS_L', 'መእተዊ ደረጃ');
  define('_PG_MEM_LEVEL', 'ደረጃ ኣባልነት');
  define('_PG_NOMEM_REQ', '-- ኣባልነት ኣይሕተትን --');
  define('_PG_MEM_LEVEL_T', 'ኣባልነት ብኣልማማ ንምምራጽ ጠዊቕኩም ሓዙ።');
  
  define('_PG_KEYS', 'ናይ ገጽ ገለጽቲ ቃላት');
  define('_PG_KEYS_T', 'ናይ ገጽ ገለጽቲ ሜታ-ቃላት ብኮማ እናፈላለኹም ኣእትዉ።');
  define('_PG_DESC', 'መግለጺ ገጽ');
  define('_PG_UPDATE', 'ገጻት ኣመዓራሪ');
  define('_PG_TITLE2', 'ገጻት ኣመዓራርዩ &rsaquo; ገጽ ወስኽ');
  define('_PG_INFO2', 'ኣብዚ ሓድሽ ገጽ ክትውስኹ ትኽእሉ');
  define('_PG_SUBTITLE2', 'ገጽ ወስኽ');
  define('_PG_ADD', 'ሓድሽ ገጽ ወስኽ');
  define('_PG_TITLE3', 'ገጻት ኣመዓራርዩ');
  define('_PG_INFO3', 'ኣብዚ ገጻትኩም ከተማዓራርዩ ትኽእሉ።<br /><strong>ምልክታ: ገጻት ምድምሳስ ንኹሉ ኣብኦም ዝርከቡ ጽሑፋት ምድምሳስ ማለት\'ዩ።</strong>');
  define('_PG_SUBTITLE3', 'ገጻት');
  
  define('_PG_HOME', 'ርእሰ-ገጽ');
  define('_PG_ISCC', 'ናይ ወኸሳ ፎርም');
  define('_PG_EDIT', 'ገጽ ኣሰናድኡ');
  define('_PG_VIEW_P', 'ጽሑፋት ኣርኢ');
  define('_PG_NEW_P', 'ሓድሽ ፎርም');
  define('_PG_NOPAGES', '<span>ኣስተውዕሉ!</span>ክሳብ ሕጅ ዝኾነ ገጻት የብልኩምን።');
  define('_PG_ISCCPAGE', 'ናይ ወኸሳ ገጽ');
  define('_PG_UPDATED', '<span>ኣገናዕ!</span>ትሕዝቶ ገጽ ተመዓራርዩ ኣሎ!');
  define('_PG_ADDED', '<span>ኣገናዕ!</span>ትሕዝቶ ገጽ ተወሲኹ ኣሎ!');
  define('_PG_COPIED', '<span>ኣገናዕ!</span>ትሕዝቶ ገጽ ተቐዲሑ ኣሎ!');

  // Admin Posts
  define('_PO_TITLE1', 'ጽሑፍ ኣመዓራርዩ &rsaquo; ጽሑፍ ኣሰናድኡ');
  define('_PO_INFO1', 'ኣብዚ ትሕዝቶ ጽሑፍ ከተማዓራርዩ ትኽእሉ');
  define('_PO_SUBTITLE1', 'ትሕዝቶ ጽሑፍ ኣሰናድኡ &rsaquo; ');
  define('_PO_TITLE', 'ኣርእስቲ ጽሑፍ');
  define('_PO_TITLE_R', 'ብኽብረትኩም ጽሑፍ ኣርእስቲ ኣእትዉ');
  define('_PO_PARENT', 'ላዕለዋይ ገጽ');
  define('_PO_PUB', 'ጽሑፍ ሰፊሩ' );  
  define('_PO_SHOW_T', 'ኣርእስቲ ኣርኢ');
  define('_PO_BODY', 'ትሕዝቶ ጽሑፍ');
  define('_PO_UPDATE', 'ጽሑፍ ኣመዓራርዩ');
  define('_PO_TITLE2', 'ጽሑፍ ኣመዓራርዩ &rsaquo; ጽሑፍ ወስኹ');
  define('_PO_INFO2', 'ኣብዚ ሓድሽ ጽሑፍ ክትውስኹ ትኽእሉ');
  define('_PO_SUBTITLE2', 'ትሕዝቶ ጽሑፍ ወስኽ');
  define('_PO_ADD', 'ሓድሽ ጽሑፍ ወስኽ');
  define('_PO_TITLE3', 'ጽሑፋት ኣመዓራርዩ');
  define('_POINFO3', 'ኣብዚ ጽሑፋትኩም ከተማዓራርዩ ትኽእሉ');
  define('_PO_SUBTITLE3', 'ትሕዝቶ ጽሑፋት');
  define('_PO_PAGE_TITLE', 'ኣርእስቲ ገጽ');
  define('_PO_EDIT', 'ጽሑፍ ኣሰናድኡ');
  define('_PO_NOPOST', '<span>ኣስተውዕሉ!</span>ክሳብ ሕጂ ኣብዚ ገጽ\'ዚ ዝኾነ ጽሑፋት የለን።');
  define('_PO_UPDATED', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!');
  define('_PO_ADDED', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተወሲኹ!');
  
  // Admin Users
  define('_UR_TITLE1', 'ገጻት ኣመዓራርዩ &rsaquo; ተጠቀምቲ ኣሰናድኡ');
  define('_UR_INFO1', 'ኣብዚ ኴንኩም ብዛዕባ ተጠቀምቲ ንዘሎ ሓበሬታ ከተመዓራርዩ ትኽእሉ።');
  define('_UR_SUBTITLE1', 'ህሉው ተጠቃሚ ኣሰናድኡ &rsaquo; ');
  define('_UR_PASS_T', 'ፓስዎርድ ትቕይሩ እንተዘይኴንኩም ባዶ ግደፉዎ');
  define('_UR_EMAIL', 'ኢ-መይልኩም');
  define('_UR_EMAIL_R', 'ብኽብረትኩም ብቑዕ ኢ-መይል ኣእትዉ።');
  define('_UR_EMAIL_R1', 'ዝኣተወ ኢ-መይል ድሮ ኣብ ጥቅሚ ውዒሉ ኣሎ።');
  define('_UR_EMAIL_R2', 'ዝኣተወ ኢ-መይል ብቑዕ ኣይኮነን።');
  define('_UR_EMAIL_R3', 'ከምዚ ዝኣተወ ኢ-መይል ዝበሃል የለን።');
  define('_UR_FNAME', 'ስም ');
  define('_UR_FNAME_R', 'ብኽብረትኩም ስም ኣእትዉ');
  define('_UR_LNAME', 'ስም ኣቦ');
  define('_UR_LNAME_R', 'ብኽብረትኩም ስም ኣቦ ኣእትዉ');
  define('_UR_NAME', 'ስም');
  define('_UR_NOMEMBERSHIP', '--- ኣባልነት ኣይግደድን---');
  define('_UR_LEVEL', 'ደረጃ ተጠቃሚ');
  define('_UR_PERM', 'ፍቓድ ተጠቃሚ');
  define('_UR_PERM_T', 'ኣየኖት ኣካላት ኢዮም ኣማሓዳሪ ክኸፍቶም ዝኽእል ምረጽ።<br/> እዚ ንስሩዓት ኣማሓደርቲ ጥራይ ይምልከት። ላዕለዋይ ኣማሓዳሪ(Super Admin) ሙሉእ ክእለት ኣለዎ።<br />ብኣልማማ ንምምራጽ Ctrl/Command ሓዙ።');
  define('_UR_STATUS', 'ኩነታት ተጠቃሚ');
  define('_UR_SADMIN', 'ላዕለዋይ ኣማሓዳሪ(Super Admin)');
  define('_UR_ADMIN', 'ኣመሓዳሪ(Admin)');
  define('_UR_ADMIN_T', 'ላዕለዋይ ኣመሓዳሪ(Super Admin) ሙሉእ መሰል ኣለዎ።<br />ኣመሓዳሪ(Admin) ፍቓድ ክወሃብ ይኽእል።<br />ተጠቃሚ ግን ምዝጉብ ተጠቃሚ ጥራይ ኢዩ።');
  define('_UR_ACTIVE', 'ተጠቃሚ ንጡፍ ኣሎ');
  define('_UR_IS_NEWSLETTER', 'መራጺ ፓምፍሌት');
  define('_UR_NOTIFY', 'ንተጠቃሚ ኣመልክት');
  define('_UR_NOTIFY_T', 'ናይ "እንቃዕ ብደሓን መጻእኩም" ኢ-መይል ናብዚ ተጠቃሚ ስደድ።');
  define('_UR_LASTLOGIN', 'ናይ መወዳእታ ምእታው');
  define('_UR_LASTLOGIN_IP', 'መወዳእታ ዝኣተወ ኣይ-ፒ(IP)');
  define('_UR_DATE_REGGED', 'ዕለት ምዝገባ');
  define('_UR_UPDATE', 'ተጠቃሚ ኣመዓራሪ');
  define('_UR_TITLE2', 'ተጠቃሚ ኣመዓራርዩ &rsaquo; ተጠቃሚ ወስኽ');
  define('_UR_INFO2', 'ኣብዚ ሓድሽ ተጠቃሚ ክይውስኹ ትኽእሉ');
  define('_UR_SUBTITLE2', 'ሓድሽ ተጠቃሚ ይውሰኽ ኣሎ');
  define('_UR_USERAVAIL', 'እዚ ስም-ተጠቃሚ ክትጥቀሙሉ ትኽእሉ ኢኹም');
  define('_UR_USERNOAVAIL', 'እዚ ስም-ተጠቃሚ ክትጥቀሙሉ ኣይትኽእሉን ኢኹም');
  define('_UR_USERNAME_R', 'ብኽብረትኩም ብቑዕ ስም-ተጠቃሚ ኣእትዉ');
  define('_UR_USERNAME_R0', 'ይቕሬታ, እዚ ስም-ተጠቃሚ ኣብ ዳታበይዝና የለን');
  define('_UR_USERNAME_R1', 'ስም-ተጠቃሚ እምብዛ ሓጺሩ(ትሕቲ 4 ፍደላት ኮይኑ)');
  define('_UR_USERNAME_R2', 'ኣብ ስም-ተጠቃሚ ዘይብቑዓት ካብ ፊደላት ወጻኢ(ከም # * & %  ወ.ዘ.ተ )ኣትዮም ኣለዉ');
  define('_UR_USERNAME_R3', 'ይቕሬታ, እዚ ስም-ተጠቃሚ ድሮ ተታሒዙ ኢዩ');
  define('_UR_PASSWORD_R', 'ብኽብረትኩም ብቑዕ ፓስዎርድ ኣእትዉ');
  define('_UR_PASSWORD_R1', 'ፓስዎርድ እምብዛ ሓጺሩ(ትሕቲ 6 ፍደላት ኮይኑ)');
  define('_UR_PASSWORD_R2', 'ኣትዩ ዘሎ ፓስዎርድ ፊደላትን ቁጽርታትን ዝሓወሰ ኣይኮነን');
  define('_UR_PASSWORD_R3', 'ኣትዩ ዘሎ ፓስዎርድ ምስ\'ቲ ቀዳማይ ኣይተዛመደን!');
  define('_UR_ADD', 'ሓድሽ ተጠቃሚ ኣእትዉ');
  define('_UR_TITLE3', 'ተጠቀምቲ ኣመዓራርዩ ');
  define('_UR_INFO3', 'ኣብዚ ተጠቀምትኹም ከተመሓድሩ ትኽእሉ። <br />ንተጠቀምቲ ኣብ ስም-ተጠቃሚኦም ብምጥዋቕ ኢ-መይል ክትሰዱሎም ትኽእሉ');
  define('_UR_SUBTITLE3', 'ተጠቀምቲ ');
  define('_UR_FIND_UNAME', 'ስም-ተጠቃሚ ድለ');
  define('_UR_USR_FILTER', 'መምየዪ ተጠቃሚ');
  define('_UR_RESET_FILTER', '--- መምየዪ ተጠቃሚ ሪሰት ግበር ---');
  define('_UR_SHOW_FROM', 'ካብ');
  define('_UR_SHOW_TO', 'ናብ');
  define('_UR_FIND', 'ድለ');
  define('_UR_EDIT', 'ተጠቃሚ ኣሰናድኡ');
  define('_UR_NOUSER', '<span>ኣስተውዕሉ!</span>ክሳብ ሕጂ ዝኾኑ ተጠቀምቲ የለዉን');
  define('_UR_UPDATED', '<span>ኣገናዕ!</span>ተጠቃሚ ተማዓራርዩ ኣሎ!');
  define('_UR_ADDED', '<span>ኣገናዕ!</span>ተጠቃሚ ተወሲኹ ኣሎ!');
  define('_UR_ADMIN_E', '<span>ጌጋ!</span>ዋና ላዕለዋይ ኣማሓዳሪ(main Super Admin account) ክድምሰስ ኣይከኣልን!');

  // Pagination
  define('_PAG_PREV', 'ዝሓለፈ');
  define('_PAG_NEXT', 'ዝስዕብ');
  define('_PAG_GOTO', 'ናብ ገጽ');
  define('_PAG_OF', 'ካብ');
  define('_PAG_IPP', 'ኣብ ገጽ ዝሰፍሩ ነገራት');
    
  // Admin Help Layout
  define('_HP_LAYOUT_TITLE', 'ምሕደራ ንድፊ');
  define('_HP_LAYOUT_BODY', 'ንድፊ ኣብ ገጽ ብዳይናሚካዊ ዝኾነ ኣገባብ ሞዱላት ከተስፍሩ ይሕግዝ<br />
    ነፍሲወከፍ ገጽ ክሳብ 4 ናይ ሞዱል ኣቀማምጣታት ክህልዎ ይኽእል። እዚኦም ላዕሊ ፣ ታሕቲ ፣ የማንን ጸጋምን እዮም።<br />
    ንዘለዉ ሞዱላት ካብ ኣብ ጸጋም ዝርከብ ከብሒ ናብቲ መትሓዚ ንድፊ ጎቲትኩም-ከተቐምጥዎም(Drag and drop) ትኽእሉ።<br />
    መስርዕ ቦታ ሞዱላት ንምቅይያር ውን ንላዕልን ንታሕትን ምጕታት ይከኣል።<br />
    ንሞድዩል ካብ መትሓዚ ንድፊ ክትኣልይዎ እንተደሊኹም ናብ ጸጋማይ ከብሒ ከም እንደገና ክትመልስዎ ትኽእሉ።<br />
    <p class="info">ዝደለኹሞ ገጽ ካብ መምረጺ ሜንዩ ሕረዩ\'ሞ ሞድዩላት ኣንብሩሉ።<br />
      ከም ውሁብ ኩሉ ግዜ ርእሰ-ገጽ ተመሪጹ ይጸንሕ።</p>');
  
  // Admin Help Pages
  define('_HP_PAGES_TITLE', 'ምሕደራ ገጻት');
  define('_HP_PAGES_BODY', '<ul>
    <li><span>ኣርእስቲ ገጽ? :</span>እዚ ኣብ መካነ ኣርእስቲ ናይ ብራውዘር(browser title bar) ዝጸሓፍ ኢዩ</li>
    <li><span>ገጽ ይጸሓፍ\'ዶ? :</span>ንተጠቀምቲ ዝረኣዩ እቶም ዝተጻሕፉ ገጻት ጥራይ ኢዮም</li>
    <li><span>ርእሰ-ገጽ? :</span>እዚ እንተተመሪጹ እዚ ገጽ እቲ ውሁብ ርእሰ-ገጽ ይኸውን</li>
    <li><span>ናይ ወኸሳ ፎርም? :</span>"እወ" እንተኢልኩም እዚ ገጽ ከም ናይ ወኸሳ ገጽ ከገልግል ኢዩ</li>
    <li><span>ምልቃብ ጋለሪ? :</span>እዚ እንተመሪጽኩም እዚ ገጽ ናይ ባዕሉ ጋለሪ ክሕልዎ ኢዩ</li>
	<li><span>ናብዚ ገጽ ንምእታው ዘድሊ ደረጃ? :</span>ኣማራጺታት; ፓብሊክ, ምዝጉባት, ኣባላት
	<ul>
	<li><span>ፓብሊክ:</span> - ኩሎም ተጠቀምቲ ናብዚ ገጽ ክመጹ ይኽእሉ</li>
	<li><span>ምዝጉባት:</span> - እዚ ገጽ ንዝተመዝገቡ ተጠቀምቲ ጥራይ ክፉት ይኸውን</li>
	<li><span>ኣባላት:</span> - እዚ ገጽ ንብቑዕ ኣባልነት ዘለዎም ተጠቀምቲ ጥራይ ክፉት ይኸውን</li>
	</ul>
	</li>
	<li><span>ርእይቶታት? :</span>"እወ" እንተኢልኩም ኣብ ትሕቲ እዚ ገጽ ርእይቶታት ክህልዉ ኢዮም</li>
    <li><span>ገለጽቲ ቃላት(Keywords) ናይዚ ገጽ? :</span>እዞም ቃላት ነዚ ገጽ ኣብ ምድላይ የገልግሉ</li>
    <li><span>መግለጺ ናይዚ ገጽ? :</span>እዚ መግለጺ ነዚ ገጽ ኣብ ምድላይ የገልግል</li>
  </ul>');
  define('_HP_PAGES_TIP', 'ነዚ ብምጕታት <img src="images/handle.png" alt=""/> ናይ ጽሑፍ ተርታ ኣመዓራርዩ');
  
  // Admin Help Posts
  define('_HP_POSTS_TITLE', 'ምሕደራ ጽሑፋት');
  define('_HP_POSTS_BODY', '<ul>
    <li><span>ኣርእስቲ ጽሑፍ? :</span>እዚ ናይ ጽሑፍኩም ኣርእስቲ ምዃኑ እዩ</li>
    <li><span>ልዕሊኡ ዝርከብ ገጽ? :</span>ነዚ ካብ መምረጺ ሓሪኹም ጽሑፍኩም ኣንብሩሉ</li>
    <li><span>ጽሑፍ ይጸሓፍ\'ዶ? :</span>ንተጠቀምቲ ዝረኣዩ እቶም ዝተጻሕፉ ጽሑፋት ጥራይ ኢዮም</li>
    <li><span>ኣርእስቲ ይረአ\'ዶ? :</span>ናይ ጽሑፍ ክትሪኡ ከምትደልዩ ምረጹ</li>
    <li><span>ጽሑፍ Body:</span>ኣብዚ ትሕዝቶ ጽሑፍኩም ኣእትዉ</li>
  </ul>');
  define('_HP_POSTS_TIP', 'ንነፍሲወከፍ ገጽ ልዕሊ ሓደ ጽሑፍ ከተንብሩሉ ከምእትኽእሉ ኣይትረስዑ');
?>