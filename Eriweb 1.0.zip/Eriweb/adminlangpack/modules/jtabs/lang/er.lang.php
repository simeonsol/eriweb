﻿<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('ናብዚ ቦታ ብቐጥታ ምምጻእ ኣይፍቀድን ኢዩ');
?>
<?php
  // Global
  define('MOD_JT_TITLE1', 'ሞድዩላት ኣመሓድሩ  &rsaquo; ሰሌዳታት(Tabs) ኣሰናድኡ');
  define('MOD_JT_INFO1', 'ኣብዚ ናይ ትሕዝቶ ሰሌዳ ኣሰራርዓኹም ከተመዓራርዩ ትኽእሉ');
  define('MOD_JT_SUBTITLE1', 'ሞድዩል ኣሰናድኦ &rsaquo; ');
  define('MOD_JT_TITLE', 'ኣርእስቲ ሰሌዳ');
  define('MOD_JT_TITLE_R', 'ብኽብረትኩም ኣርእስቲ ሰሌዳ ኣእትዉ');
  define('MOD_JT_PUB', 'ሰሌዳ ተጻሒፉ');
  define('MOD_JT_BODY', 'ትሕዝቶ ሰሌዳ');
  define('MOD_JT_BODY_R', 'ብኽብረትኩም ትሕዝቶ ሰሌዳ ኣእትዉ');
  define('MOD_JT_UPDATE', 'ሰሌዳ ኣመዓራሪ');
  define('MOD_JT_TITLE2', 'ሞድዩላት ኣመሓድሩ  &rsaquo; ሓድሽ ሰሌዳ ወስኹ');
  define('MOD_JT_INFO2', 'ኣብዚ ሓድሽ ሰሌዳ ክትውስኹ ትኽእሉ');
  define('MOD_JT_SUBTITLE2', 'ሰሌዳ ይውሰኽ ኣሎ');
  define('MOD_JT_ADD', 'ሰሌዳ ወስኽ');
  define('MOD_JT_TITLE3', 'ሞድዩል ኣመሓድር &rsaquo; ሞድዩል ኣመዓራርዩ');
  define('MOD_JT_INFO3', 'ኣብዚ ናይ ሞድዩላትኩም ኣሰራርዓ ከተመዓራርዩ ትኽእሉ።<br />ተርታ ሰሌዳታት ንምምዕርራይ ብቑጽሪ ሰሌዳ(tab ID(#))ጠዊቕኩም ጉተቱ, ብድሕሪኡ ኣብ ዝመረጽኩሞ ቦታ ኣቐሚጥኩም ን<strong>ቦታ ዓቅብ</strong> ዝብል ጠውቑ');
  define('MOD_JT_SUBTITLE3', 'ሞድዩል ኣመዓራርዩ &rsaquo; ');
  define('MOD_JT_POS', 'ቦታ');
  define('MOD_JT_POS_SAVE', 'ቦታ ዓቅብ');
  define('MOD_JT_EDIT', 'ኣሰናድኡ');
  define('MOD_JT_TAB', 'ሰሌዳ');
  define('MOD_JT_NONEWS', '<span>ሓበሬታ!</span>ክሳብ ሕጂ ዝኾነ ትሕዝቶ የለን። ብኽብረትኩም ሰሌዳታት ወስኹ!');
  define('MOD_JT_UPDATED', '<span>ኣገናዕ!</span>ትሕዝቶ ሰሌዳ ተመዓራርዩ!');
  define('MOD_JT_ADDED', '<span>ኣገናዕ!</span>ትሕዝቶ ሰሌዳ ተወሲኹ!');
  define('MOD_JT_SUPDATED', '<span>ኣገናዕ!</span>ተርታ ሰሌዳ ተማዓራርዩ!');
?>