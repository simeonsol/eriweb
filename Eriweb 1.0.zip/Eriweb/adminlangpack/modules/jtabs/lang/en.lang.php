<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<?php
  // Global
  define('MOD_JT_TITLE1', 'Manage CMS Modules &rsaquo; Edit Tab Item');
  define('MOD_JT_INFO1', 'Here you can update your tab item.');
  define('MOD_JT_SUBTITLE1', 'Edit Content Module &rsaquo; ');
  define('MOD_JT_TITLE', 'Tab Title');
  define('MOD_JT_TITLE_R', 'Please Enter Tab Title');
  define('MOD_JT_PUB', 'Tab Published');
  define('MOD_JT_BODY', 'Tab Body');
  define('MOD_JT_BODY_R', 'Please enter Tab Body');
  define('MOD_JT_UPDATE', 'Update Tab');
  define('MOD_JT_TITLE2', 'Manage CMS Modules &rsaquo; Add Tab Item');
  define('MOD_JT_INFO2', 'Here you can add your tab item.');
  define('MOD_JT_SUBTITLE2', 'Adding Tab Item');
  define('MOD_JT_ADD', 'Add Tab Item');
  define('MOD_JT_TITLE3', 'Manage CMS Module &rsaquo; Configure Module');
  define('MOD_JT_INFO3', 'Here you can configure your content modules.<br />To reorder tabs click and drag tab ID(#), position it where you want it, than click on <strong>Save Position</strong> button.');
  define('MOD_JT_SUBTITLE3', 'Configure Module &rsaquo; ');
  define('MOD_JT_POS', 'Position');
  define('MOD_JT_POS_SAVE', 'Save Position');
  define('MOD_JT_EDIT', 'Edit');
  define('MOD_JT_TAB', 'Tab');
  define('MOD_JT_NONEWS', '<span>Info!</span>You don\'t have any content yet. Please add!');
  define('MOD_JT_UPDATED', '<span>Success!</span>Tab item updated successfully!');
  define('MOD_JT_ADDED', '<span>Success!</span>Tab item added successfully!');
  define('MOD_JT_SUPDATED', '<span>Success!</span>Tab Order updated successfully!');
?>