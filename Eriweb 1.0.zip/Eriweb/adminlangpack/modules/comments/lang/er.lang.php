﻿<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('ናብዚ ቦታ ብቐጥታ ምምጻእ ኣይፍቀድን ኢዩ');
?>
<?php
  // Front
  define('MOD_CM_COMMENTS', 'ርእይቶታት');
  define('MOD_CM_NOCOMMENTS', 'ክሳብ ሕጂ ዝኾነ ርእይቶታት የለን');
  define('MOD_CM_REPLY', 'መልሲ ግደፉ');
  define('MOD_CM_NAME', 'ስም:');
  define('MOD_CM_COMMENT', 'ርእይቶ');
  define('MOD_CM_E_NOT_V', 'ኣይረአን ኣሎ');
  define('MOD_CM_WEB', 'ዌብሳይት:');
  define('MOD_CM_CAPTCHA_N', 'ንመተኣማመኒ ነዛ ሕቶ መልሱ? 6 + 3:');
  define('MOD_CM_ADDCOMMENT', 'ርእይቶ ወስኹ');
  define('MOD_CHAR_REMAIN1', '<strong>');
  define('MOD_CHAR_REMAIN2', '<\/strong> ፊደላት ተሪፉኩም ኣሎ');
  define('MOD_CM_REPLY2', 'መልሲ');
  define('MOD_CM_MSGOK1', '<span>ነመስግን!</span> ጽሑፍኩም ተረኪቡ ኣሎ');
  define('MOD_CM_MSGOK2', '<span>ነመስግን!</span> ጽሑፍኩም ተረኪቡ ኣሎ, ኣብ መስርሕ ምጽራይ ካኣ ኣሎ');
  define('MOD_CM_MSGERR3', '<span>ሓበሬታ!</span> ይቕሬታ,ኣብዚ ምዝጉባትን ዝኣተዉን  ተጠቀምቲ ጥራይ ኢዮም ርእይቶታት ክጽሕፉ ዝኽእሉ። ብኽብረትኩም እተዉ/ተመዝገቡ');
  
  // Post
  define('MOD_CM_E_NAME', 'ብኽብረትኩም ብቑዕ ስም ኣእትዉ');
  define('MOD_CM_E_CAPTCHA', 'ብኽብረትኩም ዝረኣየኩም ዘሎ ኮድ ብትኽክል ኣእትዉ');
  define('MOD_CM_E_CAPTCHA2', 'ዝኣተወ ኮድ ብቑዕ ኣይኮነን');
  define('MOD_CM_E_EMAIL', 'ብኽብረትኩም ኢ-መይልኩም ኣእትዉ');
  define('MOD_CM_E_EMAIL2', 'ዝኣተወ ኢ-መይል ብቑዕ ኣይኮነን');
  define('MOD_CM_E_WWW', 'ዝኣተወ ዌብሳይት ብቑዕ ኣይኮነን። ዌብሳይት ብ http:// ክጅምር ኣለዎ');
  define('MOD_CM_E_COMMENT', 'ብኽብረትኩም ርእይቶኹም ኣእትዉ');
  define('MOD_CM_MSG_ERR', 'ርእይቶ በዞም ዝስዕቡ ምኽንያታት ክስደድ ኣይተኻእለን:');
  define('MOD_CM_MSG_ADMIN', 'ሓድሽ ርእይቶ መጺኡ ኣሎ');
  
  // Backend
  define('MOD_CM_TITLE1', 'ሞድዩላት ኣመሓድሩ &rsaquo; ኣሰራርዓ ርእይቶታት');
  define('MOD_CM_INFO1', 'ኣብዚ ኣሰራርዓ ርእይቶታትኩም ከተመዓራርዩ ትኽእሉ');
  define('MOD_CM_SUBTITLE1', 'ኣሰራርዓ ርእይቶታትኩም ኣመዓራርዩ');
  define('MOD_CM_UNAME_R', 'ስም-ተጠቃሚ ግድን የድሊ');
  define('MOD_CM_UNAME_T', 'ርእይቶ ንምጽሓፍ ስም-ተጠቃሚ ግድን የድሊ\'ዶ?');
  define('MOD_CM_EMAIL_R', 'ኢ-መይል ግድን የድሊ');
  define('MOD_CM_EMAIL_T', 'ርእይቶ ንምጽሓፍ ኢ-መይል ግድን የድሊ\'ዶ?');
  define('MOD_CM_CAPTCHA', 'ኮድ ኣርእይ');
  define('MOD_CM_CAPTCHA_T', 'ስፓም(spam) ንምውጋድ ኮድ ኣርእይ');
  define('MOD_CM_WWW', 'ዌብሳይት ኣርእይ');
  define('MOD_CM_WWW_T', 'ናይ ፖስተራት ዌብሳይት ኣርእይ');
  define('MOD_CM_UNAME_S', 'ስም-ተጠቃሚ ኣርእይ');
  define('MOD_CM_UNAME_ST', 'ናይ ፖስተራት ስም-ተጠቃሚ ኣርእይ');
  define('MOD_CM_EMAIL_S', 'ኢ-መይል ኣርእይ');
  define('MOD_CM_EMAIL_ST', 'ናይ ፖስተራት ኢ-መይል ኣርእይ። Required for using Gravatar Services');
  define('MOD_CM_REG_ONLY', 'ፓብሊክ');
  define('MOD_CM_REG_ONLY_T', '"ኣይፋል" እንተኾይኑ, ብዘይካ ምዝጉባትን ዝኣተዉን ተጠቀምቲ ካልኦት ርእይቶታት ክጽሕፉ ኣይክእሉን<br /> ከምኡ እንተዘይኮይኑ ግን ኩሎም በጻሕቲ ርእይቶታት ከምድላዮም ክጽሕፉ ይኽእሉ');
  define('MOD_CM_SORTING', 'ርእይቶታት ይምመዩ ኣለዉ');
  define('MOD_CM_SORTING_T', '--- ናይ ቀረባ ግዜ &rsaquo; ላዕሊ ---');
  define('MOD_CM_SORTING_B', '--- ናይ ቀረባ ግዜ &rsaquo; ታሕቲ ---');
  define('MOD_CM_CHAR', 'ናይ ፊደላት ገደብ');
  define('MOD_CM_CHAR_T', 'ናይ ርእይቶ ፊደላት ገደብ ግበሩሎም');
  define('MOD_CM_PERPAGE', 'ርእይቶታት ኣብ ነፍሲወከፍ ገጽ');
  define('MOD_CM_PERPAGE_T', 'ኣብ ነፍሲወከፍ ገጽ ዝሰፍሩ ርእይቶታት');
  define('MOD_CM_AA', 'ኣውቶማቲክ ኣጽድቕ');
  define('MOD_CM_AA_T', 'ኩሎም ርእይቶታት ብኣውቶማቲካዊ ኣገባብ ኣጽድቕ');
  define('MOD_CM_NOTIFY', 'ምልክታታት');
  define('MOD_CM_NOTIFY_T', 'ንነፍሲወከፍ ዝተወሰኸ ርእይቶ ኢ-መይል ስደድ።<br />እዚ ነቲ ውሁብ ናይ ሳይት ኢ-መይል ክጥቀም ኢዩ።');
  define('MOD_CM_DATE', 'ዓይነት ዕለት');
  define('MOD_CM_DATE_T', 'ንግዜ ጽሑፍ ዘርኢ ዓይነት ዕለት');
  define('MOD_CM_DATE_R', 'ብኽብረትኩም ብቑዕ ዓይነት ዕለት ምረጹ');
  define('MOD_CM_WORDS', 'ኣነወርቲ/ጽዩፋት ቃላት');
  define('MOD_CM_WORDS_T', 'ኣብ ሓደ መስመር ሓደ ቃል ኣእትዉ። ነፍሲወከፍ ቃል ብ *** ክትካእ ኢዩ።');
  define('MOD_CM_UPDATE_B', 'ምምዕርራያት ግበሩ');
  define('MOD_CM_TITLE3', 'ሞድዩል ኣመሓድሩ &rsaquo; ሞድዩል ኣመዓራርዩ');
  define('MOD_CM_INFO3', 'ኣብዚ ሞድዩላትኩም ከተመዓራርዩ ትኽእሉ');
  define('MOD_CM_SUBTITLE3', 'ሞድዩል ኣመዓራርዩ &rsaquo; ');
  define('MOD_CM_CONFIG', 'ኣሰራርዓ ርእይቶታት');
  define('MOD_CM_SHOWFROM', 'Show Items From:'); // ነዚኣን ሓንገል የድልየን!!!!
  define('MOD_CM_SHOWTO', 'Show Items To:');
  define('MOD_CM_FIND', 'ርኸብ');
  define('MOD_CM_FILTER', 'መጻረዪ ርእይቶታት:');
  define('MOD_CM_FILTER_R', '-- መጻረዪ ርእይቶታት ሪሰት(Reset) ግበር --');
  define('MOD_CM_UNAME', 'ስም-ተጠቃሚ');
  define('MOD_CM_EMAIL', 'ኢ-መይል');
  define('MOD_CM_CREATED', 'ተሰሪሑ');
  define('MOD_CM_PNAME', 'ስም ገጽ');
  define('MOD_CM_VIEW', 'ኣርእይ');
  define('MOD_CM_STATUS', 'ኩነታት');
  define('MOD_CM_VIEW_P', 'ርእይቶ ኣርእይ');
  define('MOD_CM_APPROVE', 'ኣጽድቑ');
  define('MOD_CM_DISAPPROVE', 'ኮንኑ');
  define('MOD_CM_NONCOMMENTS', '<span>ሓበሬታ!</span>ክሳብ ሕጂ ዝኾነ ርእይቶታት የለን!!!');
  define('MOD_CM_UPDATED', '<span>ኣገናዕ!</span>ኣሰራርዓ ርእይቶታት ተመዓራርዩ!');
  define('MOD_CM_NA', '<span>ኣስተውዕሉ!</span>ብኽብረትኩም ርእይቶታት ምረጹ!');
  define('MOD_CM_APPROVED', '<span>ኣገናዕ!</span>ዝተመረጹ ርእይቶታት ጸዲቖም ኣለዉ');
  define('MOD_CM_DISAPPROVED', '<span>ኣገናዕ!</span>ጽተመረጹ ርእይቶታት ተኾኒኖም ኣለዉ');
  define('MOD_CM_DELETED', '<span>ኣገናዕ!</span>ዝተመረጹ ርእይቶታት ተደምሲሶም ኣለዉ');
?>