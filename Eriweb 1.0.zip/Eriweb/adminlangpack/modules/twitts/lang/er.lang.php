﻿<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('ናብዚ ቦታ ብቐጥታ ምምጻእ ኣይፍቀድን ኢዩ');
?>
<?php
  // Global
  define('MOD_TW_TITLE1', 'ሞድዩላት ኣመሓድሩ  &rsaquo; ናይ ቀረባ ግዜ ትዊታት(Twitts) ኣሰናድኡ');
  define('MOD_TW_INFO1', 'ኣብዚ ናይ ትዊተር ኣሰራርዓኹም ከተመዓራርዩ ትኽእሉ');
  define('MOD_TW_SUBTITLE1', 'ሞድዩል ኣሰናድኡ &rsaquo; እዋናውያን ትዊታት');
  define('MOD_TW_USER', 'ስም-ተጠቃሚ');
  define('MOD_TW_USER_R', 'ብኽብረትኩም ስም-ተጠቃሚ ኣእትዉ');
  define('MOD_TW_USER_T', 'ናይ ትዊተር ስም-ተጠቃሚ ኣእትዉ');
  define('MOD_TW_COUNT', 'ቆጻሪ ትዊተር');
  define('MOD_TW_COUNT_R', 'ብኽብረትኩም ብቑዕ ቁጽሪ ኣእትዉ');
  define('MOD_TW_COUNT_T', 'ቁጽሪ ዝረኣዩ ትዊታት');
  define('MOD_TW_TRANS_S', 'ፍጥነት ምቅይያር ትዊታት');
  define('MOD_TW_TRANS_S_T', 'ፍጥነት ምቅይያር ናይ ትዊታት። ቁጽሪ ብሚሊሰከንድ ኣእትዉ<br />1000 ሚሊሰከንድ = 1 ሰከንድ(ካልኢት)');
  define('MOD_TW_SHOW_IMG', 'ምስሊ ኣርእይ');
  define('MOD_TW_SHOW_IMG_T', 'ምስሊ ይረአ\'ዶ ይተሓባእ?');
  define('MOD_TW_TRANS_T', 'ምቅይያር ዘብቅዓሉ');
  define('MOD_TW_UPDATE', 'ምምዕርራይ ግበሩ');
  define('MOD_TW_UPDATED', '<span>ኣገናዕ!</span>ናይ ትዊተር ኣሰራርዓ ተመዓራርዩ ኣሎ!');
?>