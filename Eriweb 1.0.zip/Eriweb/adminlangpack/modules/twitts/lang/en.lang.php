<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<?php
  // Global
  define('MOD_TW_TITLE1', 'Manage CMS Modules &rsaquo; Edit Latest Twitts');
  define('MOD_TW_INFO1', 'Here you can update your twitter configuration.');
  define('MOD_TW_SUBTITLE1', 'Edit Content Module &rsaquo; Latest Twitts');
  define('MOD_TW_USER', 'Your Username');
  define('MOD_TW_USER_R', 'Please Enter Your Username');
  define('MOD_TW_USER_T', 'Enter your twitter username');
  define('MOD_TW_COUNT', 'Twitter Counter');
  define('MOD_TW_COUNT_R', 'Please Enter valid number');
  define('MOD_TW_COUNT_T', 'Number of twitts to show');
  define('MOD_TW_TRANS_S', 'Transition Speed');
  define('MOD_TW_TRANS_S_T', 'Speed of the transition. Enter number in Milliseconds<br />1000 Milliseconds = 1 Second');
  define('MOD_TW_SHOW_IMG', 'Show Avatar');
  define('MOD_TW_SHOW_IMG_T', 'Whether or not to show/hide avatar');
  define('MOD_TW_TRANS_T', 'Transition Timeout');
  define('MOD_TW_UPDATE', 'Update Settings');
  define('MOD_TW_UPDATED', '<span>Success!</span>Twitter settings updated successfully!');
?>