<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<?php
  // Global
  define('MOD_JQ_TITLE', 'Manage CMS Modules &rsaquo; jQuerySlider');
  define('MOD_JQ_CAPTION', 'Image Caption');
  define('MOD_JQ_CAPTION_R', 'Please Enter Image Caption');
  define('MOD_JQ_POS', 'Position');
  define('MOD_JQ_LINK', 'Link');
  define('MOD_JQ_EDIT', 'Edit');
  define('MOD_JQ_DEL', 'Delete');
  define('MOD_JQ_NOIMG', '<span>Info!</span>You don\'t have any images yet. Please upload');
  define('MOD_JQ_SAVE_POS', 'Save Position');
  
  define('MOD_JQ_URL_T', 'Select Url Type');
  define('MOD_JQ_EXTLINK', 'External Link');
  define('MOD_JQ_EXTLINK_T', 'Enter full url starting with http:// Eg.<br />http://www.mysite.com/somefile.html');
  define('MOD_JQ_INTLINK', 'Internal Link');
  define('MOD_JQ_INTPAGE', 'Internal Page');

  define('MOD_JQ_INFO3', 'Here you can configure your content module.');
  define('MOD_JQ_INFO3_1', '<br />To reorder images click and drag image ID(#), position it where you want it, than click on <strong>Save Position</strong> button.');
  define('MOD_JQ_SUBTITLE3', 'Configure Module &rsaquo; ');
  define('MOD_JQ_CONF', 'Configuration');
  
  define('MOD_JQ_UPDATE', 'Update Image');
  define('MOD_JQ_IMGFILE', 'Image File');
  define('MOD_JQ_SLIDE', 'Slide Image');
  define('MOD_JQ_IMG_SEL', 'Select Image');
  define('MOD_JQ_IMGFILE_R', 'Please Select Image to Upload');
  define('MOD_JQ_IMGUPLOAD', 'Upload Image');
  
  define('MOD_JQ_TRANS_EF', 'Transition Effect');
  define('MOD_JQ_ANI_SPEED', 'Animation Speed');
  define('MOD_JQ_ANI_SPEED_R', 'Please Enter Animation Speed in Miliseconds');
  define('MOD_JQ_ANI_SPEED_T', 'Enter Animation Speed in Miliseconds.<br />1 second = 1000 milliseconds');
  define('MOD_JQ_ANI_TIME', 'Animation Time');
  define('MOD_JQ_ANI_TIME_R', 'Please Enter Animation Time in Miliseconds');
  define('MOD_JQ_ANI_TIME_T', 'Enter Animation Time in Miliseconds.<br />1 second = 1000 milliseconds');
  define('MOD_JQ_S_NAV', 'Show Navigation');
  define('MOD_JQ_S_NAV_T', 'Yes to show navigation arrows (Left/Right)');
  define('MOD_JQ_S_NAV_H', 'Show only on hover');
  define('MOD_JQ_S_NAV_H_T', 'Yes to show (Left/Right) arrows on mouse hover');
  define('MOD_JQ_PAUSE', 'Pause on Hover');
  define('MOD_JQ_PAUSE_T', 'Yes to pause the animation on mouse hover');
  define('MOD_JQ_S_CONTROLL', 'Show Controlls');
  define('MOD_JQ_S_CONTROLL_T', 'Yes to show navigation buttons');
  define('MOD_JQ_S_CAPTION', 'Show Image Caption');
  define('MOD_JQ_S_CAPTION_T', 'Yes to show image caption');
  define('MOD_JQ_BUT_CONF_U', 'Update Configuration');
  define('MOD_JQ_CONF_UPDATED', '<span>Success!</span>Configuration updated successfully!');
  define('MOD_JQ_SUPDATED', '<span>Success!</span>Slide Order updated successfully!');
  
  // Class
  define('MOD_JQ_FILE_ERR', '<span>Error!</span>File could not be moved from temporary upload folder to image folder.');
  define('MOD_JQ_ADDED', '<span>Success!</span>Image added successfuly.');
  define('MOD_JQ_UPDATED', '<span>Success!</span>Image updated successfuly.');
?>