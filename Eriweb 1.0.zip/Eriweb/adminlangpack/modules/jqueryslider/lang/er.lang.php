﻿<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('ናብዚ ቦታ ብቐጥታ ምምጻእ ኣይፍቀድን ኢዩ');
?>
<?php
  // Global
  define('MOD_JQ_TITLE', 'ሞድዩላት ኣመሓድሩ  &rsaquo; ስላይደር');
  define('MOD_JQ_CAPTION', 'ጽሑፈ ስእሊ');
  define('MOD_JQ_CAPTION_R', 'ብኽብረትኩም ጽሑፈ ስእሊ ኣእትዉ');
  define('MOD_JQ_POS', 'ቦታ');
  define('MOD_JQ_LINK', 'ሊንክ');
  define('MOD_JQ_EDIT', 'ኣሰናድኡ');
  define('MOD_JQ_DEL', 'ደምስሱ');
  define('MOD_JQ_NOIMG', '<span>ሓበሬታ!</span>ክሳብ ሕጂ ዝኾነ ኣሳእል የብልኩምን። ብኽብረትኩም ስእሊ ኣፕሎድ(upload) ግበሩ');
  define('MOD_JQ_SAVE_POS', 'ቦታ ዓቅብ');
  
  define('MOD_JQ_URL_T', 'ዓይነት ዩ.ኣር.ኤል(Url) ምረጹ');
  define('MOD_JQ_EXTLINK', 'ድዳማዊ ሊንክ');
  define('MOD_JQ_EXTLINK_T', 'ብ http:// ዝጅምር ሙሉእ ዩ.ኣር.ኤል(Url) ኣእትዉ። ንኣብነት <br />http://www.Eriweb.com/welcome.html');
  define('MOD_JQ_INTLINK', 'ውሽጣዊ ሊንክ');
  define('MOD_JQ_INTPAGE', 'ውሽጣዊ ገጽ');

  define('MOD_JQ_INFO3', 'ኣብዚ ናይ ሞድዩላትኩም ኣሰራርዓ ከተመዓራርዩ ትኽእሉ');
  define('MOD_JQ_INFO3_1', '<br />ተርታ ሰሌዳታት ንምምዕርራይ ብቑጽሪ ሰሌዳ(image ID(#))ጠዊቕኩም ጉተቱ, ብድሕሪኡ ኣብ ዝመረጽኩሞ ቦታ ኣቐሚጥኩም ን<strong>ቦታ ዓቅብ</strong> ዝብል ጠውቑ');
  define('MOD_JQ_SUBTITLE3', 'ሞድዩል ኣመዓራርዩ &rsaquo; ');
  define('MOD_JQ_CONF', 'ኣሰራርዓ');
  
  define('MOD_JQ_UPDATE', 'ስእሊ ኣመዓራርዩ');
  define('MOD_JQ_IMGFILE', 'ስእሊ ');
  define('MOD_JQ_SLIDE', 'ስላይድ ስእሊ');
  define('MOD_JQ_IMG_SEL', 'ስእሊ ምረጹ');
  define('MOD_JQ_IMGFILE_R', 'ብኽብረትኩም ኣፕሎድ(Upload) ዝግበር ስእሊ ምረጹ');
  define('MOD_JQ_IMGUPLOAD', 'ኣፕሎድ ግበር');
  
  define('MOD_JQ_TRANS_EF', 'ዓይነት ምቅይያር');
  define('MOD_JQ_ANI_SPEED', 'ፍጥነት ምንቅስቓስ');
  define('MOD_JQ_ANI_SPEED_R', 'ብኽብረትኩም ፍጥነት ምንቅስቓስ ብሚሊሰከንድ ኣእትዉ');
  define('MOD_JQ_ANI_SPEED_T', 'ፍጥነት ምንቅስቓስ ብሚሊሰከንድ ኣእትዉ<br />1 ሰከንድ(ካልኢት) = 1000 ሚሊሰከንድ');
  define('MOD_JQ_ANI_TIME', 'ግዜ ምንቅስቓስ');
  define('MOD_JQ_ANI_TIME_R', 'ብኽብረትኩም ግዜ ምንቅስቓስ ብሚሊሰከንድ ኣእትዉ');
  define('MOD_JQ_ANI_TIME_T', 'ግዜ ምንቅስቓስ ብሚሊሰከንድ ኣእትዉ <br />1 ሰከንድ(ካልኢት) = 1000 ሚሊሰከንድ');
  define('MOD_JQ_S_NAV', 'መማእዘኒ ኣርእይ');
  define('MOD_JQ_S_NAV_T', '"እወ" እንተኢልኩም ቀስቲ መማእዘኒ ይረአ(የማን/ጸጋም)');
  define('MOD_JQ_S_NAV_H', 'ማውስ ኣብ ምዝንባይ(hover) ኣርእይ');
  define('MOD_JQ_S_NAV_H_T', 'ቀስቲ መማእዘኒ(የማን/ጸጋም) ንምርኣይ ');
  define('MOD_JQ_PAUSE', 'ማውስ ኣብ ምዝንባይ(hover) ምንቅስቓስ ኣቋርጽ');
  define('MOD_JQ_PAUSE_T', '"እወ" እንተኢልኩም ማውስ ኣብ ምዝንባይ(hover) ምንቅስቓስ የቋርጽ');
  define('MOD_JQ_S_CONTROLL', 'መቆጻጸሪ ኣርእይ');
  define('MOD_JQ_S_CONTROLL_T', '"እወ" እንተኢልኩም መማእዘንቲ ይረኣዩ');
  define('MOD_JQ_S_CAPTION', 'ጽሑፈ ስእሊ ኣርእይ');
  define('MOD_JQ_S_CAPTION_T', '"እወ" እንተኢልኩም ጽሑፈ ስእሊ ይረአ');
  define('MOD_JQ_BUT_CONF_U', 'ምምዕርራያት ግበር');
  define('MOD_JQ_CONF_UPDATED', '<span>ኣገናዕ!</span>ምምዕርራያት ተገይሩ!');
  define('MOD_JQ_SUPDATED', '<span>ኣገናዕ!</span>ትርታ ስላይድ ተመዓራርዩ!');
  
  // Class
  define('MOD_JQ_FILE_ERR', '<span>ጌጋ!</span>ፋይል ካብ ግዝያዊ ናይ ኣፕሎድ ፎልደር(temporary upload) ናብ ናይ ስእሊ ፎልደር ክግዕዝ ኣይከኣለን');
  define('MOD_JQ_ADDED', '<span>ኣገናዕ!</span>ስእሊ ተወሲኹ');
  define('MOD_JQ_UPDATED', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ');
?>