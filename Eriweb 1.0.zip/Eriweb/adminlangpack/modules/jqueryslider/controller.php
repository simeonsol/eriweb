<?php
  /**
   * Controller
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: controller.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  define("_VALID_PHP", true);
  
  require_once("../../init.php");
  if (!$user->is_Admin())
      redirect_to("../../login.php");
  
  require_once("lang/" . $core->language . ".lang.php");
  require_once("admin_class.php");
  
  $slider = new jQuerySlider();
?>
<?php
  /* Update Configuration */
  if (isset($_POST['updateConfig'])):
  $slider->updateConfiguration();
  endif;
?>
<?php
  /* Proccess Image */
  if (isset($_POST['processSliderImage']))
      : if (isset($_POST['processImage']))
      : if (!empty($_FILES['filename']['name']))
      : $res = move_uploaded_file($_FILES['filename']['tmp_name'], EriwebLITE . "modules/jqueryslider/slides/" . $_FILES['filename']['name']);
  if ($res)
      : print $_FILES['filename']['name'];
  else
      : $this->msgError(MOD_JQ_FILE_ERR);
  endif;
  else
      : endif;
  elseif (isset($_POST['processSliderImage']))
      : $slider->sliderid = (isset($_POST['sliderid'])) ? $_POST['sliderid'] : 0; 
	  $slider->processSliderImage();
  endif;
  endif;
?>
<?php
  /* Update Images Order */
  if (isset($_GET['sortslides'])) :
      $slider->updateOrder();
 endif;
?>
<?php
  /* Delete slider images*/
  if (isset($_POST['deleteSlide'])):
	$temp = sanitize($_POST['deleteSlide']);
	list($id,$filename) = explode(":",$temp);
									  
	@unlink(EriwebLITE . 'modules/jqueryslider/slides/'.$filename);
	$db->delete("mod_slider", "id='" . $id . "'");
	
	$title = sanitize($_POST['slidetitle']);
	print ($db->affected()) ? $Eriwebsec->writeLog(MOD_JQ_SLIDE .' <strong>'.$title.'</strong> '._DELETED, "", "no", "module") . $core->msgOk(MOD_JQ_SLIDE .' <strong>'.$title.'</strong> '._DELETED) : $core->msgAlert(_SYSTEM_PROCCESS);
  endif;
?>