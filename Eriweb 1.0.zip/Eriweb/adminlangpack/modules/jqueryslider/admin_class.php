<?php
  /**
   * jQuerySlider Class
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: class_admin.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
  
  class jQuerySlider
  {
      
	  private $mTable = "mod_slider";
	  public $sliderid = null;


      /**
       * jQuerySlider::__construct()
       * 
       * @return
       */
      function __construct()
      {
          $this->getSliderId();
      }

	  /**
	   * jQuerySlider::getSliderId()
	   * 
	   * @return
	   */
	  private function getSliderId()
	  {
	  	  global $core;
		  if (isset($_GET['sliderid'])) {
			  $sliderid = (is_numeric($_GET['sliderid']) && $_GET['sliderid'] > -1) ? intval($_GET['sliderid']) : false;
			  $sliderid = sanitize($sliderid);
			  
			  if ($sliderid == false) {
				  $core->error("You have selected an Invalid SliderId","jQuerySlider::getSliderId()");
			  } else
				  return $this->sliderid = $sliderid;
		  }
	  }
	  
	  /**
	   * jQuerySlider::getSliderImages()
	   * 
	   * @return
	   */
	  public function getSliderImages()
	  {
		  global $db;
		  
		  $sql = "SELECT * FROM " . $this->mTable . " ORDER BY position";
		  $row = $db->fetch_all($sql);
		  
		  return ($row) ? $row : 0;
	  }
	  
	  /**
	   * jQuerySlider::getSliderImages()
	   * 
	   * @return
	   */
	  function processSliderImage()
	  {
		  global $db, $core, $Eriwebsec;
		  
		  if (empty($_POST['title'.$core->dblang]))
			  $core->msgs['title'] = MOD_JQ_CAPTION_R;
		  
		  if (!$this->sliderid) {
			  if (!isset($_POST['filename']))
				  $core->msgs['name'] = MOD_JQ_IMGFILE_R;
		  }
		  
		  if (empty($core->msgs)) {
			  $data['title'.$core->dblang] = sanitize($_POST['title'.$core->dblang]);
			  
			  if (isset($_POST['urltype'])&& $_POST['urltype'] == "internal" && isset($_POST['page_id'])) {
				  $data['url'] = createPageLink(intval($_POST['page_id']));
				  $data['urltype'] = "int";
				  $data['page_id'] = intval($_POST['page_id']);
			  } elseif (isset($_POST['urltype'])&& $_POST['urltype'] == "external" && isset($_POST['url'])) {
				  $data['url'] = sanitize($_POST['url']);
				  $data['urltype'] = "ext";
				  $data['page_id'] = "DEFAULT(page_id)";
			  } else {
				  $data['url'] = "#";
				  $data['urltype'] = "ext";
				  $data['page_id'] = "DEFAULT(page_id)";
			  }
			  
			  if (!$this->sliderid) {
				  $data['filename'] = $_POST['filename'];
			  }
			  ($this->sliderid) ? $db->update($this->mTable, $data, "id='" . (int)$this->sliderid . "'") : $db->insert($this->mTable, $data);
			  $message = ($this->sliderid) ? MOD_JQ_UPDATED : MOD_JQ_ADDED;
			  
			  ($db->affected()) ? $Eriwebsec->writeLog($message, "", "no", "module") . $core->msgOk($message) : $core->msgAlert(_SYSTEM_PROCCESS);
				 
		  } else
			  print $core->msgStatus();
	  }

	  /**
	   * jQuerySlider::getConfiguration()
	   * 
	   * @return
	   */
	  public function getConfiguration()
	  {
		  global $db;
		  
		  $sql = "SELECT * FROM mod_slider_config";
		  $row = $db->first($sql);
		  
		  return ($row) ? $row : 0;
	  }
	   
	  /**
	   * jQuerySlider::getSliderImages()
	   * 
	   * @return
	   */
	  function updateConfiguration()
	  {
		  global $db, $core, $Eriwebsec;
		  
		  if ($_POST['animation'] == "")
			  $core->msgs['animation'] = MOD_JQ_ANI_SPEED_R;
		  
		  if ($_POST['anispeed'] == "")
			  $core->msgs['anispeed'] = MOD_JQ_ANI_TIME_R;
		  
		  if (empty($this->msgs)) {
			  $data = array(
					'animation' => sanitize($_POST['animation']), 
					'anispeed' => intval($_POST['anispeed']),
					'anitime' => intval($_POST['anitime']),
					'shownav' => intval($_POST['shownav']),
					'shownavhide' => intval($_POST['shownavhide']),
					'controllnav' => intval($_POST['controllnav']),
					'hoverpause' => intval($_POST['hoverpause']),
					'showcaption' => intval($_POST['showcaption'])
			  );
			  $db->update("mod_slider_config", $data);
			  
			  ($db->affected()) ? $Eriwebsec->writeLog(MOD_JQ_CONF_UPDATED, "", "no", "module") . $core->msgOk(MOD_JQ_CONF_UPDATED) :  $core->msgAlert(_SYSTEM_PROCCESS);
		  } else
			  print $core->msgStatus();
	  }
	   
	  /**
	   * jQuerySlider::updateOrder()
	   * 
	   * @return
	   */
	  public function updateOrder()
	  {
		  global $db, $core;
		  	  
		  foreach ($_POST['node'] as $k => $v) {
			  $p = $k + 1;
			  $data['position'] = intval($p);
			  $db->update($this->mTable, $data, "id='" . (int)$v . "'");
		  }
		  
		  ($db->affected()) ? $core->msgOk(MOD_JQ_SUPDATED) : $core->msgAlert(_SYSTEM_PROCCESS);
	  }
  }
?>