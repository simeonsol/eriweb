<?php
  /**
   * Gallery
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: gallery.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');

  if(!$user->getAcl("Gallery")): print $core->msgAlert(_CG_ONLYADMIN, false); return; endif;
    
  require_once("lang/" . $core->language . ".lang.php");
  require_once("admin_class.php");
  $gal = new Gallery();
?>
<?php switch($core->maction): case "edit": ?>
<h1><img src="images/mod-sml.png" alt="" /><?php echo MOD_GA_TITLE1;?></h1>
<p class="info"><span><?php echo $core->langIcon();?></span><?php echo MOD_GA_INFO1 . _REQ1 . required() . _REQ2;?></p>
<h2><?php echo MOD_GA_SUBTITLE1.' &rsaquo; '.$gal->title;?></h2>
<form action="" method="post" id="admin_form" name="admin_form">
  <table cellspacing="0" cellpadding="0" class="formtable">
    <tr>
      <td width="200"><?php echo MOD_GA_NAME;?>: <?php echo required();?></td>
      <td><input name="title<?php echo $core->dblang;?>" type="text" class="inputbox required" value="<?php echo $gal->title;?>" size="55" title="<?php echo MOD_GA_NAME_R;?>"/></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_IPR;?>: <?php echo required();?></td>
      <td><input name="rows" type="text" class="inputbox required" value="<?php echo $gal->rows;?>" size="5" title="<?php echo MOD_GA_IPR_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(MOD_GA_IPR_T);?></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_THUMB_W;?>: <?php echo required();?></td>
      <td><input name="thumb_w" type="text" class="inputbox required" value="<?php echo $gal->thumb_w;?>" size="5" title="<?php echo MOD_GA_THUMB_W_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(MOD_GA_THUMB_W_T);?></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_THUMB_H;?>: <?php echo required();?></td>
      <td><input name="thumb_h" type="text" class="inputbox required" value="<?php echo $gal->thumb_h;?>" size="5" title="<?php echo MOD_GA_THUMB_H_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(MOD_GA_THUMB_H_T);?></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_IMG_W;?>: <?php echo required();?></td>
      <td><input name="image_w" type="text" class="inputbox required" value="<?php echo $gal->image_w;?>" size="5"  title="<?php echo MOD_GA_IMG_W_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(MOD_GA_IMG_W_T);?></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_IMG_H;?>: <?php echo required();?></td>
      <td><input name="image_h" type="text" class="inputbox required" value="<?php echo $gal->image_h;?>" size="5" title="<?php echo MOD_GA_IMG_H_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(MOD_GA_IMG_H_T);?></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_RESIZE;?>:</td>
      <td><span class="input-out">
        <label for="method-1"><?php echo MOD_GA_METHOD_1;?></label>
        <input name="method" type="radio" id="method-1"  value="1" <?php getChecked($gal->method, 1); ?> />
        <label for="method-2"><?php echo MOD_GA_METHOD_0;?></label>
        <input name="method" type="radio" id="method-2" value="0" <?php getChecked($gal->method, 0); ?> />
        <?php echo tooltip(MOD_GA_RESIZE_T);?></span></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_WATERMARK;?>:</td>
      <td><span class="input-out">
        <label for="watermark-1"><?php echo _YES;?></label>
        <input name="watermark" type="radio" id="watermark-1"  value="1" <?php getChecked($gal->watermark, 1); ?> />
        <label for="watermark-2"><?php echo _NO;?></label>
        <input name="watermark" type="radio" id="watermark-2" value="0" <?php getChecked($gal->watermark, 0); ?> />
        <?php echo tooltip(MOD_GA_WATERMARK_T);?></span></td>
    </tr>
    <tr>
      <td><input type="submit" name="submit" class="button" value="<?php echo MOD_GA_UPDATE;?>" /></td>
      <td><a href="index.php?do=modules&amp;action=config&amp;mod=gallery" class="button-alt"><?php echo _CANCEL;?></a></td>
    </tr>
  </table>
  <input name="galid" type="hidden" value="<?php echo $gal->galid;?>" />
</form>
<?php echo $core->doForm("processGallery","modules/gallery/controller.php");?>
<?php break;?>
<?php case"add": ?>
<h1><img src="images/mod-sml.png" alt="" /><?php echo MOD_GA_TITLE2;?></h1>
<p class="info"><span><?php echo $core->langIcon();?></span><?php echo MOD_GA_INFO2 . _REQ1 . required() . _REQ2;?></p>
<h2><?php echo MOD_GA_SUBTITLE2;?></h2>
<form action="" method="post" id="admin_form" name="admin_form">
  <table cellspacing="0" cellpadding="0" class="formtable">
    <tr>
      <td width="200"><?php echo MOD_GA_NAME;?>: <?php echo required();?></td>
      <td><input name="title<?php echo $core->dblang;?>" type="text" class="inputbox required" size="55" title="<?php echo MOD_GA_NAME_R;?>"/></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_FOLDER;?>: <?php echo required();?></td>
      <td><input name="folder" type="text" class="inputbox required" size="55" title="<?php echo MOD_GA_FOLDER_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(MOD_GA_FOLDER_T);?></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_IPR;?>: <?php echo required();?></td>
      <td><input name="rows" type="text" class="inputbox required" size="5" title="<?php echo MOD_GA_IPR_R;?>"/>
      &nbsp;&nbsp; <?php echo tooltip(MOD_GA_IPR_T);?></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_THUMB_H;?>: <?php echo required();?></td>
      <td><input name="thumb_w" type="text" class="inputbox required" size="5" title="<?php echo MOD_GA_THUMB_W_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(MOD_GA_THUMB_W_T);?></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_THUMB_H;?>: <?php echo required();?></td>
      <td><input name="thumb_h" type="text" class="inputbox required" size="5" title="<?php echo MOD_GA_THUMB_H_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(MOD_GA_THUMB_H_T);?></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_IMG_W;?>: <?php echo required();?></td>
      <td><input name="image_w" type="text" class="inputbox required" size="5"  title="<?php echo MOD_GA_IMG_W_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(MOD_GA_IMG_W_T);?></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_IMG_H;?>: <?php echo required();?></td>
      <td><input name="image_h" type="text" class="inputbox required" size="5" title="<?php echo MOD_GA_IMG_H_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(MOD_GA_IMG_H_T);?></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_RESIZE;?>:</td>
      <td><span class="input-out">
        <label for="method-1"><?php echo MOD_GA_METHOD_1;?></label>
        <input name="method" type="radio" id="method-1"  value="1" checked="checked" />
        <label for="method-2"><?php echo MOD_GA_METHOD_0;?></label>
        <input name="method" type="radio" id="method-2" value="0" />
        <?php echo tooltip(MOD_GA_RESIZE_T);?></span></td>
    </tr>
    <tr>
      <td><?php echo MOD_GA_WATERMARK;?>:</td>
      <td><span class="input-out">
        <label for="watermark-1"><?php echo _YES;?></label>
        <input name="watermark" type="radio" id="watermark-1"  value="1" />
        <label for="watermark-2"><?php echo _NO;?></label>
        <input name="watermark" type="radio" id="watermark-2" value="0" checked="checked" />
        <?php echo tooltip(MOD_GA_WATERMARK_T);?></span></td>
    </tr>
    <tr>
      <td><input type="submit" name="submit" class="button" value="<?php echo MOD_GA_ADDMOD_GALLERY;?>" /></td>
      <td><a href="index.php?do=modules&amp;action=config&amp;mod=gallery" class="button-alt"><?php echo _CANCEL;?></a></td>
    </tr>
  </table>
</form>
<?php echo $core->doForm("processGallery","modules/gallery/controller.php");?>
<?php break;?>
<?php case"images": ?>
<?php $imagerow = $gal->getGalleryImages();?>
<h1><img src="images/gallery-sml.png" alt="" /><?php echo MOD_GA_TITLE3 . $gal->title;?></h1>
<p class="info"><span><?php echo $core->langIcon();?></span><?php echo MOD_GA_INFO3;?></p>
<h2><span><a href="javascript:void(0);" onclick="$('#gallery').dialog('open'); return false" class="button-sml"><?php echo MOD_GA_ADD_IMG;?></a></span><?php echo MOD_GA_SUBTITLE3_. $gal->title . MOD_GA_SUBTITLE31_;?></h2>
<div id="gallery" title="<?php echo MOD_GA_IMG_UPLOAD;?>">
  <div id="upload"><span class="button-alt"><?php echo MOD_GA_IMG_ADD;?></span></div>
  <div id="status"><img src="images/ajax-loader.gif" alt="" /></div>
  <ul id="img-list">
  <li style="display:none"></li>
  </ul>
</div>
<?php if($imagerow == 0):?>
<?php echo $core->msgAlert(MOD_GA_NOIMG,false);?>
<?php else:?>
<div>
  <ul id="galleryrow">
    <?php foreach($imagerow as $row):?>
    <li id="item_<?php echo $row['id'];?>"style="min-height:<?php echo $gal->thumb_h;?>px;">
    <div class="controller"><img src="<?php echo SITEURL.'/'.$gal->galpath . $gal->folder.'/thumbs/'.$row['thumb'];?>" alt="<?php echo $row['title'.$core->dblang];?>" />
    <span class="control"><a href="javascript:void(0);" onclick="$('#options-<?php echo $row['id'];?>').dialog('open'); return false">
      <img src="images/edit.png" alt="" title="<?php echo MOD_GA_EDIT_IMG;?>" class="tooltip"/></a>
      <a href="<?php echo SITEURL.'/'.$gal->galpath . $gal->folder.'/'.$row['thumb'];?>" title="<?php echo $row['description'.$core->dblang];?>" rel="prettyPhoto[pp_gal]">
      <img src="images/search.png" alt="<?php echo $row['title'.$core->dblang];?>" title="<?php echo MOD_GA_VIEW_IMG;?>" class="tooltip view" /></a>
      <a href="javascript:void(0);" class="delete" rel="<?php echo $row['title'.$core->dblang];?>" id="item_<?php echo $row['id'].':'.$gal->folder;?>">
      <img src="images/delete.png" alt="" title="<?php echo MOD_GA_DEL_IMG;?>" class="tooltip" /></a>
    </span></div>
      <p id="options-<?php echo $row['id'];?>" class="options" title="<?php echo MOD_GA_EDIT_IMG;?>">
      <span style="display:block; margin-bottom:10px"><strong style="float:left; width:200px"><?php echo MOD_GA_IMG_TITLE;?>:</strong>
        <input name="title_<?php echo $row['id'];?>" id="title_<?php echo $row['id'];?>" type="text"  value="<?php echo $row['title'.$core->dblang];?>" class="inputbox" size="50"/>
      </span> 
      <span style="display:block"><strong style="float:left; width:200px"><?php echo MOD_GA_IMG_DESC;?>:</strong>
        <input name="description_<?php echo $row['id'];?>" id="desc_<?php echo $row['id'];?>" type="text"  value="<?php echo $row['description'.$core->dblang];?>" class="inputbox" size="50"/>
      </span><br clear="all"/>
        <span style="display:block"><strong style="float:left; width:200px"><img src="<?php echo SITEURL.'/'.$gal->galpath . $gal->folder.'/thumbs/'.$row['thumb'];?>" alt="<?php echo $row['title'.$core->dblang];?>" style="border: 1px solid #CFCFCF; background-color: #FFF; padding:5px;-moz-border-radius:5px;-khtml-border-radius:5px;-webkit-border-radius:5px"/></strong>
        <input type="button" value="<?php echo _SUBMIT;?>" class="button" onclick="updateOptions(<?php echo $row['id'];?>);"/>
        <span class="msgDisplay"></span></span> </p>
    </li>
    <?php endforeach;?>
  </ul>
  <div class="clear"></div>
</div>
<div id="dialog-confirm" style="display:none;" title="<?php echo _DELETE.' '._IMAGE;?>">
  <p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span><?php echo _DEL_CONFIRM;?></p>
</div>
<?php endif;?>
<script type="text/javascript" src="assets/upload.js"></script>
<script type="text/javascript"> 
// <![CDATA[
$(function () {
    var btnUpload = $('#upload');
    var status = $('#status');
	status.hide();
    new AjaxUpload(btnUpload, {
        action: 'modules/gallery/controller.php',
        name: 'image',
        data: {
            id: <?php echo $gal->galid;?>,
			uploadimage:1
        },
        onSubmit: function (file, ext) {
            if (!(ext && /^(jpg|png|jpeg|gif|JPG|PNG|JPEG|GIF)$/.test(ext))) {
                status.text('<?php echo _CG_LOGO_R;?>');
                return false;
            }
            status.show();
        },

        onComplete: function (file, response) {
            status.hide();
			var arr = response.split('|')
            if (arr[0] == "OK") {
                $('<li></li>').appendTo('#img-list').html('<img src="<?php echo SITEURL.'/'.$gal->galpath . $gal->folder.'/thumbs/';?>' + arr[1] + '" alt="" />');
            } else {
                $('<li></li>').appendTo('#img-list').text('<?php echo MOD_GA_IMG_ERR;?>');
            }
        }
    });
});

var galHelper = function (e, li) {
    li.children().each(function () {
        $(this).width($(this).width());
    });
    return li;
};
$(document).ready(function () {
	$("#gallery").dialog({
	  bgiframe: true, autoOpen: false, width:<?php echo $gal->thumb_w * 5 + 55;?>, height:"auto",  zindex:9998, modal: false
	});
	
    $("#galleryrow").sortable({
        opacity: 0.6,
        helper: galHelper,
        update: function() {
            var order = $('#galleryrow').sortable('serialize');
                $.ajax({
                    type: 'post',
                    url: "modules/gallery/controller.php?sortgallery=1",
                    data: order,

                    success: function (msg) {
						$("#msgholder").html(msg);
                    }
                });
			$("#galleryrow").disableSelection();
        }
    });

    $("ul#galleryrow li").hover(function () {
        $(this).find("span.control").fadeIn(400);
    }, function () {
        $(this).find("span.control").fadeOut(600);
    });

    $(".options").dialog({
        bgiframe: true,
        autoOpen: false,
        width: "auto",
        height: "auto",
        zindex: 9998,
        modal: false

    });
	
    $('a.delete').live('click', function () {
        var id = $(this).attr('id').replace('item_', '')
        var parent = $(this).parent().parent();
		var title = $(this).attr('rel');
        $("#dialog-confirm").data({
            'delid': id,
            'parent': parent,
			'title': title
        }).dialog('open');
        return false;
    });

    $("#dialog-confirm").dialog({
        resizable: false,
        bgiframe: true,
        autoOpen: false,
        width: 400,
        height: "auto",
        zindex: 9998,
        modal: false,
        buttons: {
            '<?php echo _DELETE;?>': function () {
                var parent = $(this).data('parent');
                var id = $(this).data('delid');
				var title = $(this).data('title');

                $.ajax({
                    type: 'post',
                    url: "modules/gallery/controller.php",
                    data: 'deleteImage=' + id + '&imgtitle=' + title,
                    beforeSend: function () {
                        parent.animate({
                            'backgroundColor': '#FFBFBF'
                        }, 400);
                    },
                    success: function (msg) {
                        parent.fadeOut(400, function () {
                            parent.remove();
                        });
						$("html, body").animate({scrollTop:0}, 600);
						$("#msgholder").html(msg);
                    }
                });

                $(this).dialog('close');
            },
            '<?php echo _CANCEL;?>': function () {
                $(this).dialog('close');
            }
        }
    });
	
});
function updateOptions(id) {
    var desc = $('#desc_' + id).attr('value');
    var title = $('#title_' + id).attr('value');
    var pars = 'desc=' + desc + '&title=' + title + '&imgid=' + id;
    $.ajax({
        type: "POST",
        url: "modules/gallery/controller.php",
        data: pars,
        success: function (msg) {
            $("#msgholder").ajaxComplete(function (event, request, settings) {
					$(this).html(msg);
                    $(".options").dialog("close");
            });
        }
    });
}
// ]]>
</script>
<?php break;?>
<?php default: ?>
<h1><img src="images/mod-sml.png" alt="" /><?php echo MOD_GA_TITLE4;?></h1>
<p class="info"><span><?php echo $core->langIcon();?></span><?php echo MOD_GA_INFO4;?></p>
<h2><span><a href="index.php?do=modules&amp;action=config&amp;mod=gallery&amp;mod_action=add" class="button-sml"><?php echo MOD_GA_SUBTITLE4;?></a></span><?php echo MOD_GA_SUBTITLE3 . $content->getModuleName(get("mod"));?></h2>
<table cellpadding="0" cellspacing="0" class="display">
  <thead>
    <tr>
      <th width="20" class="left">#</th>
      <th class="left"><?php echo MOD_GA_NAME;?></th>
      <th><?php echo MOD_GA_TOTAL_IMG;?></th>
      <th><?php echo _CREATED;?></th>
      <th><?php echo MOD_GA_EDITMOD_GAL;?></th>
      <th><?php echo MOD_GA_VIEW_IMGS;?></th>
      <th><?php echo _DELETE;?></th>
    </tr>
  </thead>
  <tbody>
    <?php if(!$gal->getGalleries()):?>
    <tr>
      <td colspan="7"><?php echo $core->msgAlert(MOD_GA_NOMOD_GAL,false);?></td>
    </tr>
    <?php else:?>
    <?php foreach ($gal->getGalleries() as $row):?>
    <tr>
      <td><?php echo $row['id'];?>.</td>
      <td><?php echo $row['title'.$core->dblang];?></td>
      <td align="center"><?php echo $row['totalpics'];?></td>
      <td align="center"><?php echo $row['date'];?></td>
      <td align="center"><a href="index.php?do=modules&amp;action=config&amp;mod=gallery&amp;mod_action=edit&amp;galid=<?php echo $row['id'];?>"><img src="images/edit.png" class="tooltip"  alt="" title="<?php echo MOD_GA_EDITMOD_GAL;?>"/></a></td>
      <td align="center"><a href="index.php?do=modules&amp;action=config&amp;mod=gallery&amp;mod_action=images&amp;galid=<?php echo $row['id'];?>"><img src="images/search.png" class="tooltip"  alt="" title="<?php echo MOD_GA_VIEW_IMGS;?>"/></a></td>
      <td align="center"><a href="javascript:void(0);" class="delete" rel="<?php echo $row['title'.$core->dblang];?>" id="item_<?php echo $row['id'];?>"><img src="images/delete.png" class="tooltip"  alt="" title="<?php echo _DELETE;?>"/></a></td>
    </tr>
    <?php endforeach;?>
    <?php unset($row);?>
    <?php endif;?>
  </tbody>
</table>
<div id="dialog-confirm" style="display:none;" title="<?php echo _DELETE.' '._GALLERY;?>">
  <p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span><?php echo _DEL_CONFIRM;?></p>
</div>
<script type="text/javascript"> 
// <![CDATA[
$(document).ready(function () {
    $('a.delete').live('click', function () {
        var id = $(this).attr('id').replace('item_', '')
        var parent = $(this).parent().parent();
		var title = $(this).attr('rel');
        $("#dialog-confirm").data({
            'delid': id,
            'parent': parent,
			'title': title
        }).dialog('open');
        return false;
    });

    $("#dialog-confirm").dialog({
        resizable: false,
        bgiframe: true,
        autoOpen: false,
        width: 400,
        height: "auto",
        zindex: 9998,
        modal: false,
        buttons: {
            '<?php echo _DELETE;?>': function () {
                var parent = $(this).data('parent');
                var id = $(this).data('delid');
				var title = $(this).data('title');

                $.ajax({
                    type: 'post',
                    url: "modules/gallery/controller.php",
                    data: 'deleteGallery=' + id + '&galtitle=' + title,
                    beforeSend: function () {
                        parent.animate({
                            'backgroundColor': '#FFBFBF'
                        }, 400);
                    },
                    success: function (msg) {
                        parent.fadeOut(400, function () {
                            parent.remove();
                        });
						$("html, body").animate({scrollTop:0}, 600);
						$("#msgholder").html(msg);
                    }
                });

                $(this).dialog('close');
            },
            '<?php echo _CANCEL;?>': function () {
                $(this).dialog('close');
            }
        }
    });
});
// ]]>
</script>
<?php break;?>
<?php endswitch;?>