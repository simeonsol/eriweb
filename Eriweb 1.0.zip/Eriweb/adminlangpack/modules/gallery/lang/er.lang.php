﻿<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('ናብዚ ቦታ ብቐጥታ ምምጻእ ኣይፍቀድን ኢዩ');
?>
<?php
  define('MOD_GA_TITLE1', 'ጋለሪታት ኣመሓድሩ &rsaquo; ጋለሪ ኣሰናድኡ');
  define('MOD_GA_INFO1', 'ኣብዚ ናይ ጋለሪ ኣሰራርዓኹም ከተመዓራርዩ ትኽእሉ');
  define('MOD_GA_SUBTITLE1', 'ጋለሪ ይሰናዳእ ኣሎ');
  define('MOD_GA_NAME', 'ኣርእስቲ ጋለሪ');
  define('MOD_GA_NAME_R', 'ብኽብረትኩም ኣርእስቲ ጋለሪ ኣእትዉ');
  define('MOD_GA_IPR', 'ቁጽሪ ኣሳእል ኣብ መስርዕ');
  define('MOD_GA_IPR_R', 'ብኽብረትኩም ቁጽሪ ኣሳእል ኣብ መስርዕ ኣእትዉ');
  define('MOD_GA_IPR_T', 'ክንደይ ኣሳእል ኣብ መስርዕ ይሃሉ?');
  define('MOD_GA_THUMB_W', 'ጎድኒ ስእሊ');
  define('MOD_GA_THUMB_W_R', 'ብኽብረትኩም ጎድኒ ስእሊ ኣእትዉ');
  define('MOD_GA_THUMB_W_T', 'ጎድኒ ስእሊ ብፒክሰል(px)');
  define('MOD_GA_THUMB_H', 'ቁመት ስእሊ');
  define('MOD_GA_THUMB_H_R', 'ብኽብረትኩም ቁመት ስእሊ ኣእትዉ');
  define('MOD_GA_THUMB_H_T', 'ቁመት ስእሊ ብፒክሰል(px)');
  define('MOD_GA_IMG_W', 'ጎድኒ ስእሊ');
  define('MOD_GA_IMG_W_R', 'ብኽብረትኩም ጎድኒ ስእሊ ኣእትዉ');
  define('MOD_GA_IMG_W_T', 'ጎድኒ ዓቢ ስእሊ ብፒክሰል(px)');
  define('MOD_GA_IMG_H', 'ቁመት ስእሊ');
  define('MOD_GA_IMG_H_R', 'ብኽብረትኩም ቁመት ስእሊ ኣእትዉ');
  define('MOD_GA_IMG_H_T', 'ቁመት ዓቢ ስእሊ ብፒክሰል(px)');
  define('MOD_GA_RESIZE', 'ኣገባብ ኣተዓባብያ/ኣነኣእሳ ስእሊ');
  define('MOD_GA_RESIZE_T', 'ልክዕ ኣገባብ - ንኣሳእል ናብ ዝተረቝሐ ጎድኒ/ስፍሓት ይቕይር<br />ምጡን ኣገባብ - ንኣሳእል ብመጠን ጎድኒ/ስፍሓት ይቕይር<br>
  ልክዕ ኣገባብ ዝያዳ ይምረጽ');
  define('MOD_GA_METHOD_1', 'ልክዕ');
  define('MOD_GA_METHOD_0', 'መጠናዊ');
  define('MOD_GA_WATERMARK', 'Enable Watermark');
  define('MOD_GA_WATERMARK_T', 'Yes to enable watermark feature.<br />Upload your watermark.png file in upload directory using File manager');
  define('MOD_GA_UPDATE', 'ጋለሪ ኣመዓራሪ');
  define('MOD_GA_TITLE2', 'ጋለሪ ኣመዓራሪ &rsaquo; ጋለሪ ኣመዓራሪ');
  define('MOD_GA_INFO2', 'ኣብዚ ሓድሽ ጋለሪ ክትውስኹ ትኽእሉ');
  define('MOD_GA_SUBTITLE2', 'ጋለሪ ወስኹ');
  define('MOD_GA_FOLDER', 'ናይ ጋለሪ ስም-ፎልደር');
  define('MOD_GA_FOLDER_R', 'ብኽብረትኩም ናይ ጋለሪ ስም-ፎልደር ኣእትዉ');
  define('MOD_GA_FOLDER_T', 'እዚ ስም ናይ ኩሎም ኣሳእል ዝእከቡሉ ፎልደር ኢዩ።<br />ነፍሲወከፍ ጋለሪ ናይ ገዛእ ርእሱ ውልቃዊ ፎልደር ክህልዎ ኣይክእልን<br />ፊደላትን ቁጽርታትን ጥራይ ብዘይ ባዶ ቦታ ተጠቐሙ');
  define('MOD_GA_ADDMOD_GALLERY', 'ጋለሪ ወስኽ');
  define('MOD_GA_TITLE3', 'ጋለሪ ኣመሓድር &rsaquo; ');
  define('MOD_GA_INFO3', 'ኣብዚ ናይ ጋለሪ ኣሳእልኩም ከተመዓራርዩ ትኽእሉ<br /> ኣሳእል ንምስራዕ ጎቲትኩም ኣቐምጡ(Drag and Drop)');
  define('MOD_GA_SUBTITLE3_', '"');
  define('MOD_GA_SUBTITLE31_', ' ኣሳእል"');
  define('MOD_GA_SUBTITLE3', 'ሞድዩል ኣመዓራርዩ &rsaquo; ');
  define('MOD_GA_ADD_IMG', 'ኣሳእል ኣመዓራርዩ');
  define('MOD_GA_IMG_UPLOAD', 'ኣልማማ ኣፕሎድ ኣሳእል');
  define('MOD_GA_NOIMG', '<span>ኣስተውዕሉ!</span>ክሳብ ሕጂ ኣብዚ ጋለሪ\'ዚ ዝኾነ ኣሳእል የለን');
  define('MOD_GA_EDIT_IMG', 'ኣማራጺታት ስእሊ ኣሰናድኡ');
  define('MOD_GA_VIEW_IMG', 'ስእሊ ኣርእይ');
  define('MOD_GA_DEL_IMG', 'ስእሊ ደምስስ');
  define('MOD_GA_IMG_TITLE', 'ኣርእስቲ ስእሊ');
  define('MOD_GA_IMG_DESC', 'መግለጺ ስእሊ');
  define('MOD_GA_IMG_ADD', 'ስእሊ ምረጹ');
  define('MOD_GA_UPDATED', '<span>ኣገናዕ!</span> ኣሰራርዓ ጋለሪ ተመዓራሪዩ!');
  define('MOD_GA_ADDED', '<span>ኣገናዕ!</span>ጋለሪ ተወሲኹ!');
  define('MOD_GA_IMG_ERR', '<span>ጌጋ!</span>ስእሊ ኣፕሎድ(uploaded) ኣይተገብረን!');
  define('MOD_GA_TITLE4', 'ጋለሪ ኣመዓራሪ');
  define('MOD_GA_INFO4', 'ኣብዚ ጋለሪታትኩም ከተመዓራርዩ ትኽእሉ<br /><strong>ምልክታ: ጋለሪ ምድምሳስ ማለት ኣብ ውሽጡ ዘለዎ ኣሳእል ምድምሳስ ማለት\'ዩ</strong>');
  define('MOD_GA_SUBTITLE4', 'ሓድሽ ጋለሪ ወስኹ');
  define('MOD_GA_SUBTITLE4_', 'ጋለሪታት');
  define('MOD_GA_NOMOD_GAL', '<span>ኣስተውዕሉ!</span>ክሳብ ሕጂ ዝኾነ ጋለርታት የለን።');
  define('MOD_GA_TOTAL_IMG', 'ጠቕላላ ኣሳእል');
  define('MOD_GA_EDITMOD_GAL', 'ጋለሪ ኣሰናድኡ');
  define('MOD_GA_VIEW_IMGS', 'ኣሳእል ኣርእይ');
?>