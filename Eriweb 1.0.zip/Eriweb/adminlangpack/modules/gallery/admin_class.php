<?php
  /**
   * Gallery Class
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: class_admin.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
  
  class Gallery
  {
	  
	  private $mTable = "mod_gallery_images";
	  private $cTable = "mod_gallery_config";
	  public $galid = null;
	  public $galpath = "modules/gallery/galleries/";


      /**
       * Gallery::__construct()
       * 
       * @param bool $galid
       * @return
       */
      function __construct($galid = false)
      {
          $this->getGalleryId();
		  $this->getConfig($galid);
      }

	  /**
	   * Gallery::getGalleryId()
	   * 
	   * @return
	   */
	  private function getGalleryId()
	  {
	  	  global $core;
		  if (isset($_GET['galid'])) {
			  $galid = (is_numeric($_GET['galid']) && $_GET['galid'] > -1) ? intval($_GET['galid']) : false;
			  $galid = sanitize($galid);
			  
			  if ($galid == false) {
				  $core->error("You have selected an Invalid CommentId","newsSlider::getCommentId()");
			  } else
				  return $this->galid = $galid;
		  }
	  }
	  
	  /**
	   * Gallery::getConfig()
	   * 
	   * @param bool $galid
	   * @return
	   */
	  private function getConfig($galid = false)
	  {
		  global $db, $core;
		  $id = ($galid) ? $galid : $this->galid;
		  $sql = "SELECT * FROM " . $this->cTable . " WHERE id = '" . $id . "'";
          $row = $db->first($sql);
          
          $this->title = $row['title'.$core->dblang];
		  $this->folder = $row['folder'];
		  $this->rows = $row['rows'];
		  $this->thumb_w = $row['thumb_w'];
		  $this->thumb_h = $row['thumb_h'];
		  $this->image_w = $row['image_w'];
		  $this->image_h = $row['image_h'];
		  $this->watermark = $row['watermark'];
		  $this->method = $row['method'];
		  $this->created = $row['created'];
	  }

	  /**
	   * Gallery::getGalleries()
	   * 
	   * @return
	   */
	  public function getGalleries()
	  {
		  global $db, $core;
		  
		  $sql = "SELECT *, DATE_FORMAT(created, '" . $core->long_date . "') as date,"
		  . "\n (SELECT COUNT(" . $this->mTable . ".gallery_id) FROM " . $this->mTable . " WHERE " . $this->mTable . ".gallery_id = " . $this->cTable . ".id) as totalpics"
		  . "\n FROM " . $this->cTable
		  . "\n ORDER BY title".$core->dblang;
          $row = $db->fetch_all($sql);
          
		  return ($row) ? $row : 0;
	  }	

	  /**
	   * Gallery::updateConfig()
	   * 
	   * @return
	   */
	  public function updateConfig()
	  {
		  global $db, $core, $Eriwebsec;
		  
		  if (empty($_POST['title'.$core->dblang]))
			  $core->msgs['title'] = MOD_GA_NAME_R;

		  if (empty($_POST['rows']))
			  $core->msgs['rows'] = MOD_GA_IPR_R;		  

		  if (empty($_POST['thumb_w']))
			  $core->msgs['thumb_w'] = MOD_GA_THUMB_W_R;

		  if (empty($_POST['thumb_h']))
			  $core->msgs['thumb_h'] = MOD_GA_THUMB_H_R;	

		  if (empty($_POST['image_w']))
			  $core->msgs['image_w'] = MOD_GA_IMG_W_R;

		  if (empty($_POST['image_h']))
			  $core->msgs['image_h'] = MOD_GA_IMG_H_R;	
			  
		  if(!$this->galid) {
			  if (empty($_POST['folder']))
				  $core->msgs['folder'] = MOD_GA_FOLDER_R;
		  }
			  			  			  		  
		  if (empty($core->msgs)) {
			  $data = array(
					  'title'.$core->dblang => sanitize($_POST['title'.$core->dblang]), 
					  'rows' => intval($_POST['rows']), 
					  'thumb_w' => intval($_POST['thumb_w']),
					  'thumb_h' => intval($_POST['thumb_h']),
					  'image_w' => intval($_POST['image_w']),
					  'image_h' => intval($_POST['image_h']),
					  'method' => intval($_POST['method']),
					  'watermark' => intval($_POST['watermark'])
			  );

			  if(!$this->galid) {
				  $data['folder'] = paranoia($_POST['folder']);
				  $data['created'] = "NOW()";
			  }

			  ($this->galid) ? $db->update($this->cTable, $data, "id='" . (int)$this->galid . "'") : $db->insert($this->cTable, $data);
			  $message = ($this->galid) ? MOD_GA_UPDATED : MOD_GA_ADDED;

			  if(!$this->galid) {
				  if(!is_dir(EriwebLITE . $this->galpath . $data['folder'])){
					  mkdir(EriwebLITE . $this->galpath . $data['folder'], 0755);
					  chmod(EriwebLITE . $this->galpath . $data['folder'], 0755);
				  }
				  if(!is_dir(EriwebLITE . $this->galpath . $data['folder'] . "/thumbs")){
					  mkdir(EriwebLITE . $this->galpath . $data['folder'] . "/thumbs", 0755);
					  chmod(EriwebLITE . $this->galpath . $data['folder'] . "/thumbs", 0755);
				  }
			  }
		
			  ($db->affected()) ? $Eriwebsec->writeLog($message, "", "no", "module") . $core->msgOk($message) :  $core->msgAlert(_SYSTEM_PROCCESS);

		  } else
			  print $core->msgStatus();
	  }

	  /**
	   * Gallery::getGalleryImages()
	   * 
	   * @param bool $galid
	   * @return
	   */
	  public function getGalleryImages($galid = false)
	  {
		  global $db;
		  
		  $id = ($galid) ? $galid : $this->galid;
		  
		  $sql = "SELECT * FROM " . $this->mTable
		  . "\n WHERE gallery_id = '".(int)$id."'"
		  . "\n ORDER BY sorting";
          $row = $db->fetch_all($sql);
          
		  return ($row) ? $row : 0;
	  }	
	  	
  }
?>