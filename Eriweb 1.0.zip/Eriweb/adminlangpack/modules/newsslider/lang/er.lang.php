﻿<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('ናብዚ ቦታ ብቐጥታ ምምጻእ ኣይፍቀድን ኢዩ');
?>
<?php
  // Global
  define('MOD_NS_TITLE1', 'ሞድዩላት ኣመሓድሩ  &rsaquo; ዜና ኣሰናድኡ');
  define('MOD_NS_INFO1', 'ኣብዚ ናይ ዜና ዝምልከት ኣሰራርዓኹም ከተመዓራርዩ ትኽእሉ');
  define('MOD_NS_SUBTITLE1', 'ሞድዩል ኣሰናድኡ &rsaquo; ');
  define('MOD_NS_TITLE', 'ኣርእስቲ ዜና');
  define('MOD_NS_TITLE_R', 'ብኽብረትኩም ኣርእስቲ ዜና ኣእትዉ');
  define('MOD_NS_PUB', 'ዜና ተጻሒፉ');
  define('MOD_NS_S_DATE', 'ዕለት ኣርእይ');
  define('MOD_NS_S_TITLE', 'ኣርእስቲ ኣርእይ');
  define('MOD_NS_BODY', 'ትሕዝቶ ዜና');
  define('MOD_NS_BODY_R', 'ብኽብረትኩም ትሕዝቶ ዜና ኣእትዉ');
  define('MOD_NS_UPDATE', 'ዜና ኣመዓራርዩ');
  define('MOD_NS_TITLE2', 'ሞድዩላት ኣመሓድሩ  &rsaquo; ሓድሽ ዜና ወስኹ');
  define('MOD_NS_INFO2', 'ኣብዚ ሓድሽ ዜና ክትውስኹ ትኽእሉ');
  define('MOD_NS_SUBTITLE2', 'ዜና ይውሰኽ ኣሎ');
  define('MOD_NS_ADD', 'ሓድሽ ዜና ወስኹ');
  define('MOD_NS_TITLE3', 'ሞድዩል ኣመሓድሩ &rsaquo; ሞድዩል ኣመዓራርዩ');
  define('MOD_NS_INFO3', 'ኣብዚ ሞድዩላትኩም ከተመዓራርዩ ትኽእሉ');
  define('MOD_NS_INFO3_1', '<br />ተርታ ዜናታት ንምምዕርራይ ብቁጽሪ ዜና(news ID(#)) ጠዊቕኩም ጉተቱ, ብድሕሪኡ ኣብ ዝመረጽኩሞ ቦታ ኣቐሚጥኩም ን<strong>ቦታ ዓቅብ</strong> ዝብል ጠውቑ');
  define('MOD_NS_SUBTITLE3', 'ሞድዩል ኣመዓራርዩ &rsaquo; ');
  define('MOD_NS_POS', 'ቦታ');
  define('MOD_NS_POS_SAVE', 'ቦታ ዓቅብ');
  define('MOD_NS_CONTENT', 'ትሕዝቶ');
  define('MOD_NS_EDIT', 'ኣሰናድኡ');
  define('MOD_NS_ITEM', 'ውልቀ ዜና');
  define('MOD_NS_SUPDATED', '<span>ኣገናዕ!</span>ተርታ ዜና ተማዓራርዩ ኣሎ!');
  define('MOD_NS_NONEWS', '<span>ሓበሬታ!</span>ክሳብ ሕጂ ዝኾነ ትሕዝቶ የለን. ብኽብረትኩም ወስኹ!');
  define('MOD_NS_UPDATED', '<span>ኣገናዕ!</span>ጽሑፍ ዜና ተመዓራርዩ ኣሎ!');
  define('MOD_NS_ADDED', '<span>ኣገናዕ!</span>ጽሑፍ ዜና ተወሲኹ ኣሎ!');
?>