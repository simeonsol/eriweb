<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<?php
  // Global
  define('MOD_PL_TITLE1', 'Manage CMS Modules &rsaquo; Edit Poll Question');
  define('MOD_PL_INFO1', 'Note: adding or removing Poll Options will reset the poll votes.');
  define('MOD_PL_SUBTITLE1', 'Edit Content Module &rsaquo; ');
  define('MOD_PL_QUESTION', 'Poll Question');
  define('MOD_PL_QUESTION_R', 'Please Enter Poll Question');
  define('MOD_PL_OPTIONS', 'Poll Options');
  define('MOD_PL_ACTIVE', 'Make poll active');
  define('MOD_PL_ADD_Q', 'Add Poll Option');
  define('MOD_PL_DEL_Q', 'Delete Poll Option');
  define('MOD_PL_UPDATE', 'Update Poll');
  define('MOD_PL_TITLE2', 'Manage CMS Modules &rsaquo; Add New Poll');
  define('MOD_PL_INFO2', 'Here you can add new poll.');
  define('MOD_PL_SUBTITLE2', 'Adding Poll');
  define('MOD_PL_ADD', 'Add Poll');
  define('MOD_PL_TITLE3', 'Manage CMS Module &rsaquo; Configure Module');
  define('MOD_PL_INFO3', 'Here you can configure your content modules.');
  define('MOD_PL_SUBTITLE3', 'Configure Module &rsaquo; ');
  define('MOD_PL_ADD1', 'Add New Poll');
  define('MOD_PL_DATE', 'Poll Created');
  define('MOD_PL_VIEW', 'View');
  define('MOD_PL_EDIT', 'Edit');
  define('MOD_PL_POLL', 'Poll');
  define('MOD_PL_NOPOLL', '<span>Info!</span>You don\'t have any polls yet. Please add');
  define('MOD_PL_UPDATED', '<span>Success!</span>Poll Question updated successfully!');
  define('MOD_PL_ADDED', '<span>Success!</span>Poll Question added successfully!');
  
  // Class
  define('MOD_NS_TOTAL', 'Total votes: ');
  define('MOD_NS_VOTES', ' votes');
  define('MOD_NS_NOW', ' Vote Now');
  define('MOD_NS_RESULT', ' View result');
  define('MOD_NS_THANKS', 'Thanks for voting');
?>