﻿<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('ናብዚ ቦታ ብቐጥታ ምምጻእ ኣይፍቀድን ኢዩ');
?>
<?php
  // Global
  define('MOD_PL_TITLE1', 'ሞድዩላት ኣመሓድሩ &rsaquo; ሕቶ ድምጺ ኣሰናድኡ');
  define('MOD_PL_INFO1', 'ምልክታ: ምርጫታት ናይ ድምጺ ምውሳኽ ኮነ ምድምሳስ ንዝተመርጹ ድምጽታት ሪሰት(ድግም ይሰርዕ) ይግብር');
  define('MOD_PL_SUBTITLE1', 'ሞድዩል ኣሰናድኡ &rsaquo; ');
  define('MOD_PL_QUESTION', 'ሕቶ ድምጺ');
  define('MOD_PL_QUESTION_R', 'ብኽብረትኩም ሕቶ ድምጺ ኣእትዉ');
  define('MOD_PL_OPTIONS', 'ምርጫታት ድምጺ');
  define('MOD_PL_ACTIVE', 'ንድምጺ ንጡፍ ግበሩ');
  define('MOD_PL_ADD_Q', 'ናይ ድምጺ ምርጫ ወስኹ');
  define('MOD_PL_DEL_Q', 'ናይ ድምጺ ምርጫ ደምስሱ');
  define('MOD_PL_UPDATE', 'ድምጺ ኣመዓርርዩ');
  define('MOD_PL_TITLE2', 'ሞድዩላት ኣመሓድሩ  &rsaquo; ሓድሽ ድምጺ ወስኹ');
  define('MOD_PL_INFO2', 'ኣብዚ ሓድሽ ድምጺ ክትውስኹ ትኽእሉ');
  define('MOD_PL_SUBTITLE2', 'ድምጺ ይውሰኽ ኣሎ');
  define('MOD_PL_ADD', 'ድምጺ ወስኽ');
  define('MOD_PL_TITLE3', 'ሞድዩል ኣመሓድሩ &rsaquo; ሞድዩል ኣመዓራርዩ');
  define('MOD_PL_INFO3', 'ኣብዚ ናይ  ኣሰራርዓኹም ከተመዓራርዩ ትኽእሉ');
  define('MOD_PL_SUBTITLE3', 'ሞድዩል ኣመዓራርዩ &rsaquo; ');
  define('MOD_PL_ADD1', 'ሓድሽ ድምጺ ወስኹ');
  define('MOD_PL_DATE', 'ድምጺ ተሰሪሑ');
  define('MOD_PL_VIEW', 'ኣርእይ');
  define('MOD_PL_EDIT', 'ኣሰናድኡ');
  define('MOD_PL_POLL', 'ድምጺ');
  define('MOD_PL_NOPOLL', '<span>ሓበሬታ!</span>ዝኾነ ናይ ድምጺ ሕቶታት የብልኩምን። ብኽብረትኩም ድምጽታት ወስኹ');
  define('MOD_PL_UPDATED', '<span>ኣገናዕ!</span>ሕቶ ድምጺ ተመዓራርዩ ኣሎ!');
  define('MOD_PL_ADDED', '<span>ኣገናዕ!</span>ሕቶ ድምጺ ተወሲኹ ኣሎ!');
  
  // Class
  define('MOD_NS_TOTAL', 'ጠቕላላ ድምጽታት: ');
  define('MOD_NS_VOTES', ' ድምጽታት');
  define('MOD_NS_NOW', ' ሕጂ ኣድምጹ');
  define('MOD_NS_RESULT', ' ውጽኢት ኣርእይ');
  define('MOD_NS_THANKS', 'ብምድማጽኩም ነመስግን');
?>