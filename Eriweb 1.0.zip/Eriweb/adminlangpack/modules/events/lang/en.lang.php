<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<?php
  // Global
  define('MOD_EM_TITLE1', 'Manage  Modules &rsaquo; Edit Event Item');
  define('MOD_EM_INFO1', 'Here you can update your event item.');
  define('MOD_EM_SUBTITLE1', 'Edit Event Item &rsaquo; ');
  define('MOD_EM_TITLE', 'Event Title');
  define('MOD_EM_TITLE_R', 'Please Enter Event Title');
  define('MOD_EM_VENUE', 'Venue Title');
  define('MOD_EM_CONTACT', 'Contact Person');
  define('MOD_EM_EMAIL', 'Contact Email');
  define('MOD_EM_PHONE', 'Contact Phone');
  define('MOD_EM_DATE_S', 'Date/Time Start');
  define('MOD_EM_DATE_S_R', 'Please select valid Date/Time Start');
  define('MOD_EM_TIME_S', 'Date/Time End');
  define('MOD_EM_TIME_S_R', 'Please select valid Date/Time End');
  define('MOD_EM_PUB', 'Event Published');
  define('MOD_EM_BODY', 'Event Content');
  define('MOD_EM_BODY_R', 'Please enter Event Content');
  define('MOD_EM_UPDATE', 'Update Event');
  define('MOD_EM_TITLE2', 'Manage  Modules &rsaquo; Add Event Item');
  define('MOD_EM_INFO2', 'Here you can add your event item.');
  define('MOD_EM_SUBTITLE2', 'Adding Event Item');
  define('MOD_EM_ADD', 'Add Event Item');
  define('MOD_EM_TITLE3', 'Manage  Module &rsaquo; Configure Module');
  define('MOD_EM_INFO3', 'Here you can configure your content modules.');
  define('MOD_EM_SUBTITLE3', 'Configure Module &rsaquo; ');

  define('MOD_EM_TITLE4', 'Manage  Modules &rsaquo; Calendar View');
  define('MOD_EM_INFO4', 'Here you can view your events in calendar mode.');
  
  define('MOD_EM_EVENT', 'Event');
  define('MOD_EM_EDIT', 'Edit');
  define('MOD_EM_VIEWCAL', 'View Calendar');
  define('MOD_EM_DSTART', 'Date Start');
  define('MOD_EM_TSTART', 'Time Start');
  define('MOD_EM_NOEVENT', '<span>Info!</span>You don\'t have any events yet. Please add!');
  define('MOD_EM_UPDATED', '<span>Success!</span>Event Post updated successfully!');
  define('MOD_EM_ADDED', '<span>Success!</span>Event Post added successfully!');
  
  // Calendar
  define('MOD_EM_PREV', 'Earlier');
  define('MOD_EM_NEXT', 'Later');
  define('MOD_EM_TIME', 'Time');
  define('MOD_EM_HOUR', 'Hour');
  define('MOD_EM_MIN', 'minute');
  define('MOD_EM_SEC', 'second');
  
  define('MOD_EM_TSE', 'Time Start/End');
  define('MOD_EM_EVENTS', 'event(s)');
  define('MOD_EM_EVENT_FOR', 'Viewing events for &rsaquo;');
?>