﻿<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('ናብዚ ቦታ ብቐጥታ ምምጻእ ኣይፍቀድን ኢዩ');
?>
<?php
  // Global
  define('MOD_EM_TITLE1', 'ሞድዩላት ኣመሓድሩ  &rsaquo; ፍጻመ ኣሰናድኡ');
  define('MOD_EM_INFO1', 'ኣብዚ ናይ ፍጻመታት ኣሰራርዓኹም ከተመዓራርዩ ትኽእሉ');
  define('MOD_EM_SUBTITLE1', 'ፍጻመ ኣሰናድኡ &rsaquo; ');
  define('MOD_EM_TITLE', 'ኣርእስቲ ፍጻመ');
  define('MOD_EM_TITLE_R', 'ብኽብረትኩም ኣርእስቲ ፍጻመ ኣእትዉ');
  define('MOD_EM_VENUE', 'ቦታ ቆጸራ');
  define('MOD_EM_CONTACT', 'ወኸሳ');
  define('MOD_EM_EMAIL', 'ናይ ወኸሳ ኢ-መይል');
  define('MOD_EM_PHONE', 'ናይ ወኸሳ ቁ.ስልኪ');
  define('MOD_EM_DATE_S', 'ዝጅምረሉ ዕለት/ሰዓት');
  define('MOD_EM_DATE_S_R', 'ብኽብረትኩም ብቑዕ ዝጅምረሉ ዕለት/ሰዓት ምረጹ');
  define('MOD_EM_TIME_S', 'ዘብቅዓሉ ዕለት/ሰዓት');
  define('MOD_EM_TIME_S_R', 'ብኽብረትኩም ዘብቅዓሉ ዕለት/ሰዓት ምረጹ');
  define('MOD_EM_PUB', 'ፍጻመ ተጻሒፉ');
  define('MOD_EM_BODY', 'ትሕዝቶ ፍጻመ');
  define('MOD_EM_BODY_R', 'ብኽብረትኩም ትሕዝቶ ፍጻመ ኣእትዉ');
  define('MOD_EM_UPDATE', 'ፍጻመ ኣመዓራርዩ');
  define('MOD_EM_TITLE2', 'ሞድዩላት ኣመሓድሩ  &rsaquo; ፍጻመ ወስኹ');
  define('MOD_EM_INFO2', 'ኣብዚ ሓድሽ ፍጻመ ክትውስኹ ትኽእሉ');
  define('MOD_EM_SUBTITLE2', 'ፍጻመ ይውሰኽ ኣሎ');
  define('MOD_EM_ADD', 'ፍጻመ ወስኽ');
  define('MOD_EM_TITLE3', 'ሞድዩል ኣመሓድር &rsaquo; ሞድዩል ኣመዓራርዩ');
  define('MOD_EM_INFO3', 'ኣብዚ ሞድዩላትኩም ከተመዓራርዩ ትኽእሉ');
  define('MOD_EM_SUBTITLE3', 'ሞድዩል ኣመዓራርዩ &rsaquo; ');

  define('MOD_EM_TITLE4', 'ሞድዩላት ኣመሓድሩ  &rsaquo; ዓውደ-ኣዋርሕ');
  define('MOD_EM_INFO4', 'ኣብዚ ፍጻሜታት ብቅዲ ዓውደ-ኣዋርሕ ከተርእዩ ትኽእሉ');
  
  define('MOD_EM_EVENT', 'ፍጻመ');
  define('MOD_EM_EDIT', 'ኣሰናድኡ');
  define('MOD_EM_VIEWCAL', 'ዓውደ-ኣዋርሕ ኣርእይ');
  define('MOD_EM_DSTART', 'ዝጅምረሉ ዕለት');
  define('MOD_EM_TSTART', 'ዝጅምረሉ ሰዓት');
  define('MOD_EM_NOEVENT', '<span>ሓበሬታ!</span>ክሳብ ሕጂ ዝኾነ ፍጻሜታት የለን። ብኽብረትኩም ፍጻሜታት ኣእትዉ!');
  define('MOD_EM_UPDATED', '<span>ኣገናዕ!</span>ጽሑፍ ፍጻመ ተመዓራርዩ!');
  define('MOD_EM_ADDED', '<span>ኣገናዕ!</span>ጽሑፍ ፍጻመ ተወሲኹ!');
  
  // Calendar
  define('MOD_EM_PREV', 'ኣቐዲሙ');
  define('MOD_EM_NEXT', 'ድሒሩ');
  define('MOD_EM_TIME', 'ግዜ');
  define('MOD_EM_HOUR', 'ሰዓት');
  define('MOD_EM_MIN', 'ደቒቕ');
  define('MOD_EM_SEC', 'ካልኢት');
  
  define('MOD_EM_TSE', 'ዝጅምረሉ/ዘብቅዓሉ ግዜ');
  define('MOD_EM_EVENTS', 'ፍጻመ');
  define('MOD_EM_EVENT_FOR', 'ፍጻሜታት ን &rsaquo;');
?>