<?php
  /**
   * Calendar
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: calendar.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  define("_VALID_PHP", true);
  
  require_once("../../init.php");
  if (!$user->is_Admin())
      redirect_to("../../login.php");
  
  require_once("lang/" . $core->language . ".lang.php");
  require_once("admin_class.php");
  $eventcal = new eventManager();
  $data = $eventcal->getCalendarData("long");
?>
<table class="calendar">
  <thead>    
    <tr>
      <td><a href="javascript:void(0);" id="item_<?php echo $data['previous_year'];?>" class="tooltip changedate" title="<?php echo $data['previous_year_text'];?>">&laquo;&laquo;</a></td>
      <td><a href="javascript:void(0);" id="item_<?php echo $data['previous_month'];?>" class="tooltip changedate" title="<?php echo $data['previous_month_text'];?>">&laquo;</a></td>
      <td colspan="3"><?php echo $data['current_month_text'];?></td>
      <td><a href="javascript:void(0);" id="item_<?php echo $data['next_month'];?>" class="tooltip changedate" title="<?php echo $data['next_month_text'];?>">&raquo;</a></td>
      <td><a href="javascript:void(0);" id="item_<?php echo $data['next_year'];?>" class="tooltip changedate" title="<?php echo $data['next_year_text'];?>">&raquo;&raquo;</a></td>
    </tr>
  <tr>
    <th width="14%"><?php echo _SUNDAY;?></th>
    <th width="14%"><?php echo _MONDAY;?></th>
    <th width="14%"><?php echo _TUESDAY;?></th>
    <th width="14%"><?php echo _WEDNESDAY;?></th>
    <th width="14%"><?php echo _THURSDAY;?></th>
    <th width="14%"><?php echo _FRIDAY;?></th>
    <th width="14%"><?php echo _SATURDAY;?></th>
  </tr>
  </thead>
<?php
  for ($i = 0; $i < $data['total_rows']; $i++) {
      print "<tr>";
      for ($j = 0; $j < 7; $j++) {
          $data['day']++;
          
          if ($data['day'] > 0 && $data['day'] <= $data['total_days_of_current_month']) {
              $date_form = $data['current_year']. '/' . $data['current_month'] . '/' . $data['day'];
              
              print '<td';
              if ($date_form == $data['today'])
                  print ' class="today"';
              
              if (array_key_exists($data['day'], $data['events'])) {
                  print ' class="event"><div id="event-wrap"><a href="javascript:void(0);" onclick="$(\'#viewevent-' . $data['day'] . '\').dialog(\'open\'); return false">' . $data['day'] . '</a>';
                  print '<div id="viewevent-' . $data['day'] . '" style="display:none" class="viewevent" title="' . MOD_EM_EVENT_FOR . ' ' . $date_form . '">';
                  print '<ul id="event-list">';
                  $x = 0; $class1 = "event-even"; $class2 = "event-odd";
                  foreach ($data['events'] as $key => $event) {
					  
                      if ($key == $data['day']) {
                          foreach ($event as $k => $val) {
							  $x++;
                              print '<li class="'.(($x % 2 == 0) ? $class1 : $class2).'">';
                              print '<h3 class="event-title"><span>' . MOD_EM_TSE . ': ' . $val['stime'] . '/' . $val['etime'] . '</span>' . $val['title'.$core->dblang] . '</h3>';
							  if ($val['venue']) print '<h6 class="event-venue">' . $val['venue'.$core->dblang] . '</h6>';
							  print '<div class="event-desc">' . cleanOut($val['body'.$core->dblang]) . '</div>';
							  
							  print '<span class="contact-info-toggle" onclick="$(\'#eventid-' . $val['id'] . '\').toggle(\'normal\')" >' . MOD_EM_CONTACT . '</span>';
							  print '<div class="event-contact" id="eventid-' . $val['id'] . '">';
							  print '<ul>';
								if ($val['venue']) print '<li>' . $val['contact_person'] . '</li>';
								if ($val['venue']) print '<li>' . $val['contact_email'] . '</li>';
								if ($val['venue']) print '<li>' . $val['contact_phone'] . '</li>';
							  print '</ul>';
							  print '</div>';
                              print '</li>';
                          }
                      }
                  }
                  
                  print '</ul>';
                  print '</div>';
				  print '<span class="event-counter">'.count($event).' '.MOD_EM_EVENTS.'</span></div>';
              } else
                  print '> ' . $data['day'];
              
              print "</td>";
          } else
              print '<td>&nbsp;</td>';
      }
      print "</tr>";
  }
?>
</table>
<script type="text/javascript">
$(document).ready(function () {
    $(".viewevent").dialog({
        bgiframe: true,
        autoOpen: false,
        width: 450,
        height: "auto",
        zindex: 9998,
        modal: false
    });
});
</script>