<?php
  /**
   * NewsSlider Class
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: class_admin.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
  
  class eventManager
  {

	  private $mTable = "mod_events";
	  public $eventid = null;
	  public $time;


      /**
       * eventManager::__construct()
       * 
       * @return
       */
      function __construct()
      {
          $this->getEventId();
		  $this->time = (isset($_POST['eventdate'])) ? intval($_POST['eventdate']) : time();
      }
	  
	  /**
	   * eventManager::getSliderId()
	   * 
	   * @return
	   */
	  private function getEventId()
	  {
	  	  global $core;
		  if (isset($_GET['eventid'])) {
			  $eventid = (is_numeric($_GET['eventid']) && $_GET['eventid'] > -1) ? intval($_GET['eventid']) : false;
			  $eventid = sanitize($eventid);
			  
			  if ($eventid == false) {
				  $core->error("You have selected an Invalid EventId","eventManager::getEventId()");
			  } else
				  return $this->eventid = $eventid;
		  }
	  }
	  
	  /**
	   * eventManager::getEventData()
	   * 
	   * @return
	   */
	  public function getEventData()
	  {
		  global $db, $core;
		  
		  $today = date("Y/n/j", time());
		  $current_month = date("n", $this->time);
		  $current_year = date("Y", $this->time);
		  $current_month_text = date("F Y", $this->time);
		  $total_days_of_current_month = date("t", $this->time);
		  
		  $events = array();
		  
		  $sql = "SELECT *, DATE_FORMAT(date_start,'%d') AS day," 
		  . " \n DATE_FORMAT(date_start,'".$core->short_date."') AS sdate," 
		  . " \n DATE_FORMAT(time_start,'%H:%i') AS stime," 
		  . " \n DATE_FORMAT(date_end,'".$core->short_date."') AS edate," 
		  . " \n DATE_FORMAT(time_end,'%H:%i') AS etime" 
		  . " \n FROM " . $this->mTable . ""
		  . " \n WHERE date_start BETWEEN  '$current_year/$current_month/01'" 
		  . " \n AND '$current_year/$current_month/$total_days_of_current_month'"
		  . " \n AND active = 1";
		  
		  $eventrow = $db->fetch_all($sql);
		  
		  foreach ($eventrow as $row_event)
			  $events[intval($row_event['day'])][] = $row_event;
		  
		  unset($row_event);
		  return $events;
	  }

	  /**
	   * eventManager::getCalendarData()
	   * 
	   * @return
	   */
	  function getCalendarData($month_type = 'long')
	  {
		  $data['events'] = $this->getEventData();
		  
		  $today = date("Y/n/j", time());
		  $data['today'] = $today;
		  
		  $current_month = date("n", $this->time);
		  $data['current_month'] = $current_month;
		  
		  $current_year = date("Y", $this->time);
		  $data['current_year'] = $current_year;
		  
		  $current_month_text = date("F", $this->time);
		  $data['current_month_text'] = ($month_type == 'long') ? $this->getLongMonths($current_month_text) . ' ' .$data['current_year'] : $this->getShortMonths($current_month_text) . ' ' .$data['current_year'];
		  
		  $total_days_of_current_month = date("t", $this->time);
		  $data['total_days_of_current_month'] = $total_days_of_current_month;
		  
		  $first_day_of_month = mktime(0, 0, 0, $current_month, 1, $current_year);
		  $data['first_day_of_month'] = $first_day_of_month;
		  
		  $first_w_of_month = date("w", $first_day_of_month);
		  $data['first_w_of_month'] = $first_w_of_month;
		  
		  $total_rows = ceil(($total_days_of_current_month + $first_w_of_month) / 7);
		  $data['total_rows'] = $total_rows;
		  
		  $day = -$first_w_of_month;
		  $data['day'] = $day;
		  
		  $next_month = mktime(0, 0, 0, $current_month + 1, 1, $current_year);
		  $data['next_month'] = $next_month;
		  
		  $next_month_text = date("F", $next_month);
		  $data['next_month_text'] = ($month_type == 'long') ? $this->getLongMonths($next_month_text) . ' \'' .$data['current_year'] : $this->getShortMonths($current_month_text) . ' \'' .$data['current_year'];
		  
		  $previous_month = mktime(0, 0, 0, $current_month - 1, 1, $current_year);
		  $data['previous_month'] = $previous_month;
		  
		  $previous_month_text = date("F", $previous_month);
		  $data['previous_month_text'] = ($month_type == 'long') ? $this->getLongMonths($previous_month_text) . ' \'' .$data['current_year'] : $this->getShortMonths($current_month_text) . ' \'' .$data['current_year'];
		  
		  $next_year = mktime(0, 0, 0, $current_month, 1, $current_year + 1);
		  $data['next_year'] = $next_year;
		  
		  $next_year_text = date("F", $next_year);
		  $data['next_year_text'] = ($month_type == 'long') ? $this->getLongMonths($next_year_text) . ' \'' .$data['current_year'] : $this->getShortMonths($current_month_text) . ' \'' .$data['current_year'];
		  
		  $previous_year = mktime(0, 0, 0, $current_month, 1, $current_year - 1);
		  $data['previous_year'] = $previous_year;
		  
		  $previous_year_text = date("F", $previous_year);
		  $data['previous_year_text'] = ($month_type == 'long') ? $this->getLongMonths($previous_year_text) . ' \'' .$data['current_year'] : $this->getShortMonths($current_month_text) . ' \'' .$data['current_year'];
		  
		  return $data;
	  }
  
	  /**
	   * eventManager::getEvents()
	   * 
	   * @return
	   */
	  public function getEvents()
	  {
		  global $db, $core;
		  
		  $sql = "SELECT *, DATE_FORMAT(date_start, '" . $core->short_date . "') as dstart"
		  . "\n FROM " . $this->mTable . ""
		  . "\n ORDER BY date_start ASC";
		  $row = $db->fetch_all($sql);
		  
		  return ($row) ? $row : 0;
	  }

	  /**
	   * eventManager::getCalData()
	   *
	   * @return
	   */
	  public function getCalData()
	  {
		  $caldata = "dateFormat: 'yy-mm-dd',timeFormat: 'hh:mm:ss',";
		  $caldata .= "dayNames: ['"._MONDAY."', '"._TUESDAY."', '"._WEDNESDAY."', '"._THURSDAY."', '"._FRIDAY."', '"._SATURDAY."', '"._SUNDAY."'],";
		  $caldata .= "dayNamesMin: ['"._MO."', '"._TU."', '"._WE."', '"._TH."', '"._FR."', '"._SA."', '"._SU."'],";
		  $caldata .= "dayNamesShort: ['"._MON."', '"._TUE."', '"._WED."', '"._THU."', '"._FRI."', '"._SAT."', '"._SUN."'],";
		  $caldata .= "monthNames: ['"._JAN."', '"._FEB."', '"._MAR."', '"._APR."', '"._MAY."', '"._JUN."', '"._JUL."', '"._AUG."', '"._SEP."', '"._OCT."', '"._NOV."', '"._DEC."'],";
		  $caldata .= "monthNamesShort: ['"._JA_."', '"._FE_."', '"._MA_."', '"._AP_."', '"._MY_."', '"._JU_."', '"._JL_."', '"._AU_."', '"._SE_."', '"._OC_."', '"._NO_."', '"._DE_."'],";
		  $caldata .= "prevText: '".MOD_EM_PREV."',";
		  $caldata .= "nextText: '".MOD_EM_NEXT."',";
		  $caldata .= "timeText: '".MOD_EM_TIME."',";
		  $caldata .= "hourText: '".MOD_EM_HOUR."',";
		  $caldata .= "minuteText: '".MOD_EM_MIN."',";
		  $caldata .= "secondText: '".MOD_EM_SEC."',";
		  $caldata .= "firstDay: 0,";
		  $caldata .= "hourGrid: 4,";
		  $caldata .= "minuteGrid: 10,";
		  $caldata .= "secondGrid: 10";
		  
		  return $caldata;
	  }

	  /**
	   * eventManager::getLongMonths()
	   * @param mixed $month
	   * @return
	   */
	  public function getLongMonths($month)
	  {
		  switch ($month) {
			  case "January":
				  $data = _JAN;
				  break;
			  case "February":
				  $data = _FEB;
				  break;
			  case "March":
				  $data = _MAR;
				  break;
			  case "April":
				  $data = _APR;
				  break;
			  case "May":
				  $data = _MAY;
				  break;
			  case "June":
				  $data = _JUN;
				  break;
			  case "July":
				  $data = _JUL;
				  break;
			  case "August":
				  $data = _AUG;
				  break;
			  case "September":
				  $data = _SEP;
				  break;
			  case "October":
				  $data = _OCT;
				  break;
			  case "November":
				  $data = _NOV;
				  break;
			  case "December":
				 $data = _DEC;
				  break;
		  }
		  return $data;
	  }


	  /**
	   * eventManager::getShortMonths()
	   * @param mixed $month
	   * @return
	   */
	  public function getShortMonths($month)
	  {
		  switch ($month) {
			  case "January":
				  $data = _JA_;
				  break;
			  case "February":
				  $data = _FE_;
				  break;
			  case "March":
				  $data = _MA_;
				  break;
			  case "April":
				  $data = _AP_;
				  break;
			  case "May":
				  $data = _MY_;
				  break;
			  case "June":
				  $data = _JU_;
				  break;
			  case "July":
				  $data = _JL_;
				  break;
			  case "August":
				  $data = _AU_;
				  break;
			  case "September":
				  $data = _SE_;
				  break;
			  case "October":
				  $data = _OC_;
				  break;
			  case "November":
				  $data = _NO_;
				  break;
			  case "December":
				 $data = _DE_;
				  break;
		  }
		  return $data;
	  }
	  	  	  	  
	  /**
	   * eventManager::processEvent()
	   * 
	   * @return
	   */
	  function processEvent()
	  {
		  global $db, $core, $Eriwebsec;
		  
		  if ($_POST['title'.$core->dblang] == "")
			  $core->msgs['title'] = MOD_EM_TITLE_R;
		  
		  if ($_POST['date_start'] == "")
			  $core->msgs['date_start'] = MOD_EM_DATE_S_R;
		  
		  if ($_POST['date_end'] == "")
			  $core->msgs['date_end'] = MOD_EM_TIME_S_R;
		  
		  if ($_POST['body'.$core->dblang] == "")
			  $core->msgs['body'] = MOD_EM_BODY_R;
			  
		  if (empty($core->msgs)) {
			  
			  list($date_start, $time_start) = explode(" ", $_POST['date_start']);
			  list($date_end, $time_end) = explode(" ", $_POST['date_end']);
			  $data = array(
					'title'.$core->dblang => sanitize($_POST['title'.$core->dblang]), 
					'venue'.$core->dblang => sanitize($_POST['venue'.$core->dblang]),
					'date_start' => sanitize($date_start),
					'date_end' => sanitize($date_end),
					'time_start' => sanitize($time_start),
					'time_end' => sanitize($time_end),
					'contact_person' => sanitize($_POST['contact_person']),
					'contact_email' => sanitize($_POST['contact_email']),
					'contact_phone' => sanitize($_POST['contact_phone']),
					'body'.$core->dblang => $_POST['body'.$core->dblang],
					'active' => intval($_POST['active'])
			  );
			  
			  ($this->eventid) ? $db->update($this->mTable, $data, "id='" . (int)$this->eventid . "'") : $db->insert($this->mTable, $data);
			  $message = ($this->eventid) ? MOD_EM_UPDATED : MOD_EM_ADDED;

			  ($db->affected()) ? $Eriwebsec->writeLog($message, "", "no", "module") . $core->msgOk($message) :  $core->msgAlert(_SYSTEM_PROCCESS);
		  } else
			  print $core->msgStatus();
	  }
  }
?>