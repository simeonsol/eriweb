<?php
  /**
   * News Slider
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: admin.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');

  if(!$user->getAcl("Event-Manager")): print $core->msgAlert(_CG_ONLYADMIN, false); return; endif;
  
  require_once("lang/" . $core->language . ".lang.php");
  require_once("admin_class.php");
  
  $event = new eventManager();
  $eventrow = $event->getEvents();
?>
<?php switch($core->maction): case "edit": ?>
<?php $row = $core->getRowById("mod_events", $event->eventid);?>
<h1><img src="images/mod-sml.png" alt="" /><?php echo MOD_EM_TITLE1;?></h1>
<p class="info"><span><?php echo $core->langIcon();?></span><?php echo MOD_EM_INFO1 . _REQ1. required() . _REQ2;?></p>
<h2><?php echo MOD_EM_SUBTITLE1 . $row['title'.$core->dblang];?></h2>
<form action="" method="post" id="admin_form" name="admin_form">
  <table cellspacing="0" cellpadding="0" class="formtable">
    <tr>
      <td width="200"><?php echo MOD_EM_TITLE;?>: <?php echo required();?></td>
      <td><input name="title<?php echo $core->dblang;?>" type="text" class="inputbox required" value="<?php echo $row['title'.$core->dblang];?>" size="55" title="<?php echo MOD_EM_TITLE_R;?>"/></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_VENUE;?>:</td>
      <td><input name="venue<?php echo $core->dblang;?>" type="text" class="inputbox" value="<?php echo $row['venue'.$core->dblang];?>" size="55" /></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_CONTACT;?>:</td>
      <td><input name="contact_person" type="text" class="inputbox" value="<?php echo $row['contact_person'];?>" size="55" /></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_EMAIL;?>:</td>
      <td><input name="contact_email" type="text" class="inputbox" value="<?php echo $row['contact_email'];?>" size="55" /></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_PHONE;?>:</td>
      <td><input name="contact_phone" type="text" class="inputbox" value="<?php echo $row['contact_phone'];?>" size="55" /></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_DATE_S;?>: <?php echo required();?></td>
      <td><input name="date_start" type="text" class="inputbox required" id="date_start" value="<?php echo $row['date_start'].' '.$row['time_start'];?>" size="25" title="<?php echo MOD_EM_DATE_S_R;?>"/></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_TIME_S;?>: <?php echo required();?></td>
      <td><input name="date_end" type="text" class="inputbox required" id="date_end" value="<?php echo $row['date_end'].' '.$row['time_end'];?>" size="25" title="<?php echo MOD_EM_TIME_S_R;?>" /></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_PUB;?>:</td>
      <td><span class="input-out">
        <label for="active-1"><?php echo _YES;?></label>
        <input name="active" type="radio" id="active-1" value="1" <?php getChecked($row['active'], 1); ?> />
        <label for="active-2"><?php echo _NO;?></label>
        <input name="active" type="radio" id="active-2" value="0" <?php getChecked($row['active'], 0); ?> />
        </span></td>
    </tr>
    <tr>
      <td colspan="2" class="editor">
      <textarea id="bodycontent" name="body<?php echo $core->dblang;?>" rows="4" cols="30"><?php echo $row['body'.$core->dblang];?></textarea>
      <?php loadEditor("bodycontent"); ?></td>
    </tr>
    <tr>
      <td><input type="submit" name="submit" class="button" value="<?php echo MOD_EM_UPDATE;?>" /></td>
      <td><a href="index.php?do=modules&amp;action=config&amp;mod=events" class="button-alt"><?php echo _CANCEL;?></a></td>
    </tr>
  </table>
  <input name="eventid" type="hidden" value="<?php echo $event->eventid;?>" />
</form>
<?php echo $core->doForm("processEvent","modules/events/controller.php");?>
<script type="text/javascript">
$(document).ready(function() {
  $('#date_start').dateplustimepicker({
      <?php echo $event->getCalData();?>
  });
  $('#date_end').dateplustimepicker({
	<?php echo $event->getCalData();?>
  });
});
</script>
<?php break;?>
<?php case"add": ?>
<h1><img src="images/mod-sml.png" alt="" /><?php echo MOD_EM_TITLE2;?></h1>
<p class="info"><span><?php echo $core->langIcon();?></span><?php echo MOD_EM_INFO2 . _REQ1. required() . _REQ2;?></p>
<h2><?php echo MOD_EM_SUBTITLE2;?></h2>
<form action="" method="post" id="admin_form" name="admin_form">
  <table cellspacing="0" cellpadding="0" class="formtable">
    <tr>
      <td width="200"><?php echo MOD_EM_TITLE;?>: <?php echo required();?></td>
      <td><input name="title<?php echo $core->dblang;?>" type="text" class="inputbox required" size="55" title="<?php echo MOD_EM_TITLE_R;?>"/></td>
    </tr>
    <tr>
      <td"><?php echo MOD_EM_VENUE;?>:</td>
      <td><input name="venue<?php echo $core->dblang;?>" type="text" class="inputbox"  size="55" /></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_CONTACT;?>:</td>
      <td><input name="contact_person" type="text" class="inputbox" size="55" /></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_EMAIL;?>:</td>
      <td><input name="contact_email" type="text" class="inputbox" size="55" /></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_PHONE;?>:</td>
      <td><input name="contact_phone" type="text" class="inputbox" size="55" /></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_DATE_S;?>: <?php echo required();?></td>
      <td><input name="date_start" type="text" class="inputbox required" id="date_start" size="25" title="<?php echo MOD_EM_DATE_S_R;?>"/></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_TIME_S;?>: <?php echo required();?></td>
      <td><input name="date_end" type="text" class="inputbox required" id="date_end"  size="25" title="<?php echo MOD_EM_TIME_S_R;?>" /></td>
    </tr>
    <tr>
      <td><?php echo MOD_EM_PUB;?>:</td>
      <td><span class="input-out">
        <label for="active-1"><?php echo _YES;?></label>
        <input name="active" type="radio" id="active-1" value="1" checked="checked" />
        <label for="active-2"><?php echo _NO;?></label>
        <input name="active" type="radio" id="active-2" value="0" />
        </span></td>
    </tr>
    <tr>
      <td colspan="2" class="editor">
      <textarea id="bodycontent" name="body<?php echo $core->dblang;?>" rows="4" cols="30"></textarea>
      <?php loadEditor("bodycontent"); ?></td>
    </tr>
    <tr>
      <td><input type="submit" name="submit" class="button" value="<?php echo MOD_EM_ADD;?>" /></td>
      <td><a href="index.php?do=modules&amp;action=config&amp;mod=events" class="button-alt"><?php echo _CANCEL;?></a></td>
    </tr>
  </table>
</form>
<?php echo $core->doForm("processEvent","modules/events/controller.php");?>
<script type="text/javascript">
$(document).ready(function() {
  $('#date_start').dateplustimepicker({
      <?php echo $event->getCalData();?>
  });
  $('#date_end').dateplustimepicker({
	<?php echo $event->getCalData();?>
  });
});
</script>
<?php break;?>
<?php case"view": ?>
<h1><img src="images/mod-sml.png" alt="" /><?php echo MOD_EM_TITLE4;?></h1>
<p class="info"><?php echo MOD_EM_INFO4;?></p>
<div id="cal-wrap"></div>
<script type="text/javascript">
$(document).ready(function () {
    function loadList() {
        $.ajax({
            url: "modules/events/calendar.php",
            cache: false,
            success: function (html) {
                $("#cal-wrap").html(html);
            }
        });
    }
    loadList();

    $("a.changedate").live("click", function () {
        var parent = $(this);
        $.ajax({
            type: "POST",
            url: "modules/events/calendar.php",
            data: 'eventdate=' + $(this).attr('id').replace('item_', ''),
            success: function (data, status) {
                $("#cal-wrap").fadeIn("fast", function () {
                    $(this).html(data);
                });
            }
        });
        return false;
    });
});
</script>
<?php break;?>
<?php default: ?>
<h1><img src="images/mod-sml.png" alt="" /><?php echo MOD_EM_TITLE3;?></h1>
<p class="info"><span><?php echo $core->langIcon();?></span><?php echo MOD_EM_INFO3;?></p>
<h2><span><a href="index.php?do=modules&amp;action=config&amp;mod=events&amp;mod_action=view" class="button-sml"><?php echo MOD_EM_VIEWCAL;?></a>
<a href="index.php?do=modules&amp;action=config&amp;mod=events&amp;mod_action=add" class="button-sml"><?php echo MOD_EM_ADD;?></a></span><?php echo MOD_EM_SUBTITLE3 . $content->getModuleName(get("mod"));?></h2>
  <table cellpadding="0" cellspacing="0" class="display">
    <thead>
      <tr>
        <th width="15">#</th>
        <th class="left"><?php echo MOD_EM_TITLE;?></th>
        <th class="left"><?php echo MOD_EM_DSTART;?></th>
        <th class="left"><?php echo MOD_EM_TSTART;?></th>
        <th><?php echo MOD_EM_EDIT;?></th>
        <th><?php echo _DELETE;?></th>
      </tr>
    </thead>
    <tbody>
      <?php if($eventrow == 0):?>
      <tr>
        <td colspan="6"><div class="msgInfo"><?php echo MOD_EM_NOEVENT;?></div></td>
      </tr>
      <?php else:?>
      <?php foreach ($eventrow as $emrow):?>
      <tr>
        <td><?php echo $emrow['id'];?>.</td>
        <td><?php echo $emrow['title'.$core->dblang];?></td>
        <td><?php echo $emrow['dstart'];?></td>
        <td><?php echo $emrow['time_start'];?></td>
        <td align="center"><a href="index.php?do=modules&amp;action=config&amp;mod=events&amp;mod_action=edit&amp;eventid=<?php echo $emrow['id'];?>"><img src="images/edit.png" class="tooltip"  alt="" title="<?php echo MOD_EM_EDIT.': '.$emrow['title'.$core->dblang];?>"/></a></td>
        <td align="center"><a href="javascript:void(0);" class="delete" rel="<?php echo $emrow['title'.$core->dblang];?>" id="item_<?php echo $emrow['id'];?>"><img src="images/delete.png" alt="" class="tooltip" title="<?php echo _DELETE.': '.$emrow['title'.$core->dblang];?>" /></a></td>
      </tr>
      <?php endforeach;?>
      <?php unset($slrow);?>
      <?php endif;?>
    </tbody>
  </table>
<div id="dialog-confirm" style="display:none;" title="<?php echo _DELETE.' '.MOD_EM_EVENT;?>">
  <p><span class="ui-icon ui-icon-alert" style="float:left; margin:0 7px 20px 0;"></span><?php echo _DEL_CONFIRM;?></p>
</div>
<script type="text/javascript"> 
// <![CDATA[
$(document).ready(function () {
    $('a.delete').live('click', function () {
        var id = $(this).attr('id').replace('item_', '')
        var parent = $(this).parent().parent();
		var title = $(this).attr('rel');
        $("#dialog-confirm").data({
            'delid': id,
            'parent': parent,
			'title': title
        }).dialog('open');
        return false;
    });

    $("#dialog-confirm").dialog({
        resizable: false,
        bgiframe: true,
        autoOpen: false,
        width: 400,
        height: "auto",
        zindex: 9998,
        modal: false,
        buttons: {
            '<?php echo _DELETE;?>': function () {
                var parent = $(this).data('parent');
                var id = $(this).data('delid');
				var title = $(this).data('title');

                $.ajax({
                    type: 'post',
                    url: "modules/events/controller.php",
                    data: 'deleteEvent=' + id + '&eventtitle=' + title,
                    beforeSend: function () {
                        parent.animate({
                            'backgroundColor': '#FFBFBF'
                        }, 400);
                    },
                    success: function (msg) {
                        parent.fadeOut(400, function () {
                            parent.remove();
                        });
						$("html, body").animate({scrollTop:0}, 600);
						$("#msgholder").html(msg);
                    }
                });

                $(this).dialog('close');
            },
            '<?php echo _CANCEL;?>': function () {
                $(this).dialog('close');
            }
        }
    });
});
// ]]>
</script>
<?php break;?>
<?php endswitch;?>