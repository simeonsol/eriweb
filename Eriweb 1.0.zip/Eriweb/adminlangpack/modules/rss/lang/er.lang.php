﻿<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('ናብዚ ቦታ ብቐጥታ ምምጻእ ኣይፍቀድን ኢዩ');
?>
<?php
  // Global
  define('MOD_RS_TITLE1', 'ሞድዩላት ኣመሓድሩ  &rsaquo; ኣር.ኤስ.ኤስ ፓርሰር ኣመዓራርዩ');
  define('MOD_RS_INFO1', 'ኣብዚ ናይ ኣር.ኤስ.ኤስ ኣሰራርዓኹም ከተመዓራርዩ ትኽእሉ');
  define('MOD_RS_SUBTITLE1', 'ሞድዩል ኣሰናድኡ &rsaquo; ኣር.ኤስ.ኤስ ፓርሰር(Rss Parser)');
  
  define('MOD_RS_URL', 'ፓርስ ዝግበር ዩ.ኣር.ኤል(Url)');
  define('MOD_RS_URL_T', 'ብhttp:// ዝጅምር ሙሉእ ዩ.ኣር.ኤል(Url) ኣእትዉ');
  define('MOD_RS_URL_R', 'ብኽብረትኩም ብቑዕ ዩ.ኣር.ኤል(Url) ኣእትዉ');
  define('MOD_RS_TITLETRIM', 'ቁመት ኣርእስቲ ኣሕጽር');
  define('MOD_RS_TITLETRIM_T', 'ቁመት ኣርእስቲ ድሕሪ ክንደይ ፊደላት ይሕጸር?<br /> ምሕጻር እንተዘይደሊኹም 0 ኣእትዉ');
  define('MOD_RS_SHOW_BODY', 'ጽማቝ ትሕዝቶ ኣርእይ');
  define('MOD_RS_BODYTRIM', 'ቁመት ጽማቝ ትሕዝቶ ኣሕጽር');
  define('MOD_RS_BODYTRIM_T', 'ቁመት ጽማቝ ትሕዝቶ ድሕሪ ክንደይ ፊደላት ይሕጸር?<br /> ምሕጻር እንተዘይደሊኹም 0 ኣእትዉ');
  define('MOD_RS_SHOW_DATE', 'ዕለት ኣርእይ');
  define('MOD_RS_DATEFORMAT', 'ዓይነት ዕለት');
  define('MOD_RS_DATE_T', '--- ዓይነት ዕለት ምረጹ ---');
  define('MOD_RS_DATE_R', 'ብኽብረትኩም ብቑዕ ዓይነት ዕለት ኣእትዉ');
  define('MOD_RS_PP_R', 'ብኽብረትኩም ቁጽሪ ናይ ዝረኣዩ ነገራት ኣእትዉ');
  define('MOD_RS_ITEMS', 'ጠቕላላ ነገራት');
  define('MOD_RS_ITEMS_T', 'ጠቕላላ ቁጽሪ ናይ ዝረኣዩ ነገራት');

  define('MOD_RS_UPDATE', 'ምምዕርራያት ግበሩ');
  define('MOD_RS_UPDATED', '<span>ኣገናዕ!</span>ናይ ኣር.ኤስ.ኤስ ኣሰራርዓ ተመዓራርዩ!');
?>