<?php
  /**
   * Language File
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: language.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
<?php
  // Global
  define('MOD_RS_TITLE1', 'Manage CMS Modules &rsaquo; Configure Rss Parser');
  define('MOD_RS_INFO1', 'Here you can update your rss configuration.');
  define('MOD_RS_SUBTITLE1', 'Edit Content Module &rsaquo; Rss Parser');
  
  define('MOD_RS_URL', 'Url To Parse');
  define('MOD_RS_URL_T', 'Enter full url starting with: http://');
  define('MOD_RS_URL_R', 'Please enter Valid Url.');
  define('MOD_RS_TITLETRIM', 'Trim Title Lenght');
  define('MOD_RS_TITLETRIM_T', 'After how many characters to trim title lenght.<br /> Enter 0 (zero) for no trim');
  define('MOD_RS_SHOW_BODY', 'Show Summary');
  define('MOD_RS_BODYTRIM', 'Trim Summary Lenght');
  define('MOD_RS_BODYTRIM_T', 'After how many characters to trim summary lenght.<br /> Enter 0 (zero) for no trim');
  define('MOD_RS_SHOW_DATE', 'Show Date');
  define('MOD_RS_DATEFORMAT', 'Date Format');
  define('MOD_RS_DATE_T', '--- Select Date Format ---');
  define('MOD_RS_DATE_R', 'Please enter Valid Date Format.');
  define('MOD_RS_PP_R', 'Please enter Number of Items to show.');
  define('MOD_RS_ITEMS', 'Total Items.');
  define('MOD_RS_ITEMS_T', 'Number of items to show.');

  define('MOD_RS_UPDATE', 'Update Settings');
  define('MOD_RS_UPDATED', '<span>Success!</span>Rss settings updated successfully!');
?>