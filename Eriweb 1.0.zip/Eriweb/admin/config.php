<?php
  /**
   * Configuration
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: config.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
	  
  if(!$user->getAcl("Configuration")): print $core->msgAlert(_CG_ONLYADMIN, false); return; endif;
?>
<h1><img src="images/settings-sml.png" alt="" /><?php echo _CG_TITLE1;?></h1>
<p class="info"><span><?php echo $core->langIcon();?></span><?php echo _CG_INFO1 . _REQ1 . required() . _REQ2;?></p>
<h2><?php echo _CG_SUBTITLE1;?></h2>
<form action="" method="post" id="admin_form" name="admin_form" enctype="multipart/form-data">
  <table cellspacing="0" cellpadding="0" class="formtable">
    <tr>
      <td width="200"><?php echo _CG_SITENAME;?>: <?php echo required();?></td>
      <td><input name="site_name" type="text" class="inputbox required" value="<?php echo $core->site_name;?>" size="55" title="<?php echo _CG_SITENAME_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(_CG_SITENAME_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_COMPANY;?>:</td>
      <td><input name="company" type="text" class="inputbox" value="<?php echo $core->company;?>" size="55"/>
        &nbsp;&nbsp; <?php echo tooltip(_CG_COMPANY_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_WEBURL;?>: <?php echo required();?></td>
      <td><input name="site_url" type="text" class="inputbox required" value="<?php echo $core->site_url;?>" size="55" title="<?php echo _CG_WEBURL_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(_CG_WEBURL_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_WEBEMAIL;?>: <?php echo required();?></td>
      <td><input name="site_email" type="text" class="inputbox required" value="<?php echo $core->site_email;?>" size="55" title="<?php echo _CG_WEBEMAIL_R;?>"/>
        &nbsp;&nbsp; <?php echo tooltip(_CG_WEBEMAIL_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_THEME;?>:</td>
      <td><select name="theme" class="select" style="width:150px">
          <?php getTemplates(EriwebLITE."/theme/", $core->theme)?>
        </select></td>
    </tr>
    <tr>
      <td><?php echo _CG_LOGO;?>:</td>
      <td><a href="javascript:void(0)" id="upload_file" class="button-alt-sml" title="<?php echo _CG_LOGO_B;?>"><?php echo _CG_LOGO_B;?></a> <span id="preview_file"></span> <span id="file_temp" style="margin-left:20px"></span> <span id="remlogo"><?php echo _CG_LOGO_DEL;?>
        <input name="dellogo" type="checkbox" value="1" id="dellogo"/>
        &nbsp;&nbsp; <?php echo tooltip(_CG_LOGO_T);?></span></td>
    </tr>
    <tr>
      <td><?php echo _CG_OFFLINE;?>:</td>
      <td><span class="input-out">
        <label for="offline-1"><?php echo _YES;?></label>
        <input type="radio" name="offline" id="offline-1" value="1" <?php getChecked($core->offline, 1); ?> />
        <label for="offline-2"><?php echo _NO;?></label>
        <input type="radio" name="offline" id="offline-2" value="0" <?php getChecked($core->offline, 0); ?> />
        <?php echo tooltip(_CG_OFFLINE_T);?></span></td>
    </tr>
    <tr>
      <td><?php echo _CG_SEO;?>:</td>
      <td><span class="input-out">
        <label for="seo-1"><?php echo _YES;?></label>
        <input name="seo" type="radio" id="seo-1"  value="1" <?php getChecked($core->seo, 1); ?> />
        <label for="seo-2"><?php echo _NO;?></label>
        <input name="seo" type="radio" id="seo-2" value="0" <?php getChecked($core->seo, 0); ?> />
        <?php echo tooltip(_CG_SEO_T);?></span></td>
    </tr>
    <tr>
      <td><?php echo _CG_PERPAGE;?>:</td>
      <td><input name="perpage" type="text" class="inputbox" value="<?php echo $core->perpage;?>" size="5" />
        &nbsp;&nbsp; <?php echo tooltip(_CG_PERPAGE_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_SHORTDATE;?>:</td>
      <td><select class="select" name="short_date">
          <?php echo $core->getShortDate();?>
        </select></td>
    </tr>
    <tr>
      <td><?php echo _CG_LONGDATE;?>:</td>
      <td><select class="select" name="long_date" id="long_date">
          <?php echo $core->getLongDate();?>
        </select></td>
    </tr>
    <tr>
      <td><?php echo _CG_DTZ;?>:</td>
      <td><?php echo $core->getTimezones();?></td>
    </tr>
    <tr>
      <td><?php echo _CG_LANG;?>:</td>
      <td><select name="lang" class="select" style="width:150px">
          <?php foreach($core->langList() as $lang):?>
          <?php $sel = ($core->lang == $lang['flag']) ? ' selected="selected"' : '';?>
          <option value="<?php echo $lang['flag'];?>"<?php echo $sel;?> style="background:url(<?php echo SITEURL . "/lang/" . $lang['flag'];?>.png) 98% center no-repeat"><?php echo $lang['name'];?></option>
          <?php endforeach;?>
        </select></td>
    </tr>
    <tr>
      <td><?php echo _CG_LANG_SHOW;?>:</td>
      <td><span class="input-out">
        <label for="show_lang-1"><?php echo _YES;?></label>
        <input type="radio" name="show_lang" id="show_lang-1" value="1" <?php getChecked($core->show_lang, 1); ?> />
        <label for="show_lang-2"><?php echo _NO;?></label>
        <input type="radio" name="show_lang" id="show_lang-2" value="0" <?php getChecked($core->show_lang, 0); ?> />
        <?php echo tooltip(_CG_LANG_SHOW_T);?></span></td>
    </tr>
    <tr>
      <td><?php echo _CG_THUMB_WH;?>: <?php echo required();?></td>
      <td><input name="thumb_w" type="text" class="inputbox" value="<?php echo $core->thumb_w;?>" size="5"/>
        /
        <input name="thumb_h" type="text" class="inputbox" value="<?php echo $core->thumb_h;?>" size="5"/>
        &nbsp;&nbsp; <?php echo tooltip(_CG_THUMB_WH_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_IMG_WH;?>: <?php echo required();?></td>
      <td><input name="img_w" type="text" class="inputbox" value="<?php echo $core->img_w;?>" size="5"/>
        /
        <input name="img_h" type="text" class="inputbox" value="<?php echo $core->img_h;?>" size="5"/>
        &nbsp;&nbsp; <?php echo tooltip(_CG_IMG_WH_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_CURRENCY;?>: <?php echo required();?></td>
      <td><input name="currency" type="text" class="inputbox required" value="<?php echo $core->currency;?>" title="<?php echo _CG_CURRENCY_R;?>" size="5"/>
        &nbsp;&nbsp; <?php echo tooltip(_CG_CURRENCY_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_CUR_SYMBOL;?>:</td>
      <td><input name="cur_symbol" type="text" class="inputbox" value="<?php echo $core->cur_symbol;?>" size="5"/>
        &nbsp;&nbsp; <?php echo tooltip(_CG_CUR_SYMBOL_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_REGVERIFY;?>:</td>
      <td><span class="input-out">
        <label for="reg_verify-1"><?php echo _YES;?></label>
        <input name="reg_verify" type="radio" id="reg_verify-1"  value="1" <?php getChecked($core->reg_verify, 1); ?> />
        <label for="reg_verify-2"><?php echo _NO;?></label>
        <input name="reg_verify" type="radio" id="reg_verify-2" value="0" <?php getChecked($core->reg_verify, 0); ?> />
        <?php echo tooltip(_CG_REGVERIFY_T);?></span></td>
    </tr>
    <tr>
      <td><?php echo _CG_AUTOVERIFY;?>:</td>
      <td><span class="input-out">
        <label for="auto_verify-1"><?php echo _YES;?></label>
        <input name="auto_verify" type="radio" id="auto_verify-1"  value="1" <?php getChecked($core->auto_verify, 1); ?> />
        <label for="auto_verify-2"><?php echo _NO;?></label>
        <input name="auto_verify" type="radio" id="auto_verify-2" value="0" <?php getChecked($core->auto_verify, 0); ?> />
        <?php echo tooltip(_CG_AUTOVERIFY_T);?></span></td>
    </tr>
    <tr>
      <td><?php echo _CG_REGALOWED;?>:</td>
      <td><span class="input-out">
        <label for="reg_allowed-1"><?php echo _YES;?></label>
        <input name="reg_allowed" type="radio" id="reg_allowed-1"  value="1" <?php getChecked($core->reg_allowed, 1); ?> />
        <label for="reg_allowed-2"><?php echo _NO;?></label>
        <input name="reg_allowed" type="radio" id="reg_allowed-2" value="0" <?php getChecked($core->reg_allowed, 0); ?> />
        <?php echo tooltip(_CG_REGALOWED_T);?></span></td>
    </tr>
    <tr>
      <td><?php echo _CG_NOTIFY_ADMIN;?>:</td>
      <td><span class="input-out">
        <label for="notify_admin-1"><?php echo _YES;?></label>
        <input name="notify_admin" type="radio" id="notify_admin-1"  value="1" <?php getChecked($core->notify_admin, 1); ?> />
        <label for="notify_admin-2"><?php echo _NO;?></label>
        <input name="notify_admin" type="radio" id="notify_admin-2" value="0" <?php getChecked($core->notify_admin, 0); ?> />
        <?php echo tooltip(_CG_NOTIFY_ADMIN_T);?></span></td>
    </tr>
    <tr>
      <td><?php echo _CG_USERLIMIT;?>:</td>
      <td><input name="user_limit" type="text" size="5" value="<?php echo $core->user_limit;?>" class="inputbox" />
        &nbsp;&nbsp; <?php echo tooltip(_CG_USERLIMIT_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_LOGIN_ATTEMPT;?>:</td>
      <td><input name="flood" type="text" class="inputbox" value="<?php echo $core->flood;?>" size="5"/>
      <input name="attempt" type="text" class="inputbox" value="<?php echo $core->attempt;?>" size="5"/>
      &nbsp;&nbsp; <?php echo tooltip(_CG_LOGIN_ATTEMPT_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_LOG_ON;?>:</td>
      <td><span class="input-out">
        <label for="logging-1"><?php echo _YES;?></label>
        <input name="logging" type="radio" id="logging-1"  value="1" <?php getChecked($core->logging, 1); ?> />
        <label for="logging-2"><?php echo _NO;?></label>
        <input name="logging" type="radio" id="logging-2" value="0" <?php getChecked($core->logging, 0); ?> />
        <?php echo tooltip(_CG_LOG_ON_T);?></span></td>
    </tr>
    <tr>
      <td><?php echo _CG_MAILER;?>:</td>
      <td><select class="select" name="mailer" id="mailerchange" style="width:150px">
          <option value="PHP"<?php if ($core->mailer == "PHP") echo "selected=\"selected\"";?>>PHP Mailer</option>
          <option value="SMTP"<?php if ($core->mailer == "SMTP") echo "selected=\"selected\"";?>>SMTP Mailer</option>
        </select>
        &nbsp;&nbsp; <?php echo tooltip(_CG_MAILER_T);?></td>
    </tr>
    <tr class="showsmtp">
      <td><?php echo _CG_SMTP_HOST;?>:</td>
      <td><input name="smtp_host" type="text" class="inputbox" value="<?php echo $core->smtp_host;?>" size="55" />
        &nbsp;&nbsp; <?php echo tooltip(_CG_SMTP_HOST_T);?></td>
    </tr>
    <tr class="showsmtp">
      <td><?php echo _CG_SMTP_USER;?>:</td>
      <td><input name="smtp_user" type="text" class="inputbox" value="<?php echo $core->smtp_user;?>" size="55" /></td>
    </tr>
    <tr class="showsmtp">
      <td><?php echo _CG_SMTP_PASS;?>:</td>
      <td><input name="smtp_pass" type="text" class="inputbox" value="<?php echo $core->smtp_pass;?>" size="55"/></td>
    </tr>
    <tr class="showsmtp">
      <td><?php echo _CG_SMTP_PORT;?>:</td>
      <td><input name="smtp_port" type="text" class="inputbox" value="<?php echo $core->smtp_port;?>" size="5" />
        &nbsp;&nbsp; <?php echo tooltip(_CG_SMTP_PORT_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_GA;?>:</td>
      <td><textarea name="analytics" cols="50" rows="6"><?php echo $core->analytics;?></textarea>
        &nbsp;&nbsp; <?php echo tooltip(_CG_GA_T);?><br />
        <small><?php echo _CG_GA_I;?></small></td>
    </tr>
    <tr>
      <td><?php echo _CG_METAKEY;?>:</td>
      <td><input name="metakeys" type="text" class="inputbox" value="<?php echo $core->metakeys;?>" size="55" />
        &nbsp;&nbsp; <?php echo tooltip(_CG_METAKEY_T);?></td>
    </tr>
    <tr>
      <td><?php echo _CG_METADESC;?>:</td>
      <td><textarea name="metadesc" cols="50" rows="6"><?php echo $core->metadesc;?></textarea>
        &nbsp;&nbsp; <?php echo tooltip(_CG_METADESC_T);?></td>
    </tr>
    <tr>
      <td colspan="2"><input type="submit" name="update" class="button" value="<?php echo _CG_UPDATE;?>" /></td>
    </tr>
  </table>
  <input name="doconfig" type="hidden" value="1" />
</form>
<?php echo $core->doForm("processConfig");?> 
<script type="text/javascript" src="assets/upload.js"></script> 
<script type="text/javascript">
// <![CDATA[
$(function () {
    new AjaxUpload('upload_file', {
        action: 'controller.php',
        name: 'logo',
        data: {
            processLogo: 1,
            processConfig: 1
        },
        autoSubmit: true,
        onChange: function (file, extension) {},
        onSubmit: function (file, extension) {
            if (!(extension && /^(jpg|JPG|png|PNG|gif|GIF)$/.test(extension))) {
                alert('<?php echo _CG_LOGO_R;?>');
                return false;
            }
        },
        onComplete: function (file, response) {
            $('#file_temp').remove();
            $('#remlogo').remove();
            var list_item = '';
            list_item += file;
            list_item += '<input type="hidden" name="logo" value="' + response + '" \/>';
            $('#preview_file').append(list_item);
        }
    });
});
$(document).ready(function () {
	var res2 = '<?php echo $core->mailer;?>';
		(res2 == "SMTP" ) ? $('.showsmtp').fadeIn().show() : $('.showsmtp').hide();
    $('#mailerchange').change(function () {
		var res = $("#mailerchange option:selected").val();
		(res == "SMTP" ) ? $('.showsmtp').fadeIn().show() : $('.showsmtp').hide();
    });
});
// ]]>
</script>