-- --------------------------------------------------------------------------------
-- 
-- @version: zazavipro.sql Feb 20, 2011 00:57 gewa
-- @package Zazavi
-- @author zazavi.com.
-- @copyright 2010
-- 
-- --------------------------------------------------------------------------------
-- Host: localhost
-- Database: zazavipro
-- Time: Feb 20, 2011-00:57
-- MySQL version: 5.1.36-community-log
-- PHP version: 5.3.0
-- --------------------------------------------------------------------------------

#
# Database: `zazavipro`
#


-- --------------------------------------------------
# -- Table structure for table `gallery`
-- --------------------------------------------------
DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `folder` varchar(30) DEFAULT NULL,
  `rows` int(4) NOT NULL DEFAULT '0',
  `thumb_w` int(4) NOT NULL DEFAULT '0',
  `thumb_h` int(4) NOT NULL DEFAULT '0',
  `image_w` int(4) NOT NULL DEFAULT '0',
  `image_h` int(4) NOT NULL DEFAULT '0',
  `watermark` tinyint(1) NOT NULL DEFAULT '0',
  `method` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `gallery`
-- --------------------------------------------------

INSERT INTO `gallery` (`id`, `title`, `folder`, `rows`, `thumb_w`, `thumb_h`, `image_w`, `image_h`, `watermark`, `method`, `created`) VALUES ('1', 'Demo Gallery', 'demo', '5', '150', '150', '600', '600', '1', '1', '2010-12-10 12:10:10');


-- --------------------------------------------------
# -- Table structure for table `gallery_images`
-- --------------------------------------------------
DROP TABLE IF EXISTS `gallery_images`;
CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_id` int(6) NOT NULL DEFAULT '0',
  `title` varchar(100) DEFAULT NULL,
  `desc` varchar(250) DEFAULT NULL,
  `thumb` varchar(100) DEFAULT NULL,
  `sorting` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `gallery_images`
-- --------------------------------------------------

INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('1', '1', 'Demo Flower 1', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_318C0B-0F1A63-7096C7-45B182-87004D-FDF0AE.jpg', '3');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('2', '1', 'Demo Flower 2', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_D45A84-11B3CB-E2E617-8CE590-EB95CB-4C40CF.jpg', '1');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('3', '1', 'Demo Flower 3', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_07264C-30F255-F8E444-C90DC8-093AE6-C83DF4.jpg', '8');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('4', '1', 'Demo Flower 4', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_2822AC-941D16-C5ECEB-4C2787-015575-77FEE8.jpg', '5');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('5', '1', 'Demo Flower 5', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_260FA3-1C8BE1-890AFD-8F20ED-47EB05-EBDFF7.jpg', '2');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('6', '1', 'Demo Flower 6', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_755459-EC4B6C-58E134-2907AA-36BFEC-2604A5.jpg', '6');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('7', '1', 'Demo Flower 7', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_7810C6-0B129B-B97C0D-902867-748A5F-854706.jpg', '7');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('10', '1', 'Demo Flower 10', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_0D08C0-3FFF26-A5D741-BA76C6-F3C61F-D67093.jpg', '12');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('11', '1', 'Demo Flower 11', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_807CA0-B0AB7C-FF9BB6-E4E678-B9A38A-7A81FB.jpg', '9');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('12', '1', 'Demo Flower 12', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_7CF0A7-55F94C-0B0AE0-A4BF0C-476BF7-82CCE0.jpg', '11');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('13', '1', 'Demo Flower 13', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_E1A872-9BDEED-5CA577-3CA6F1-E2545B-DBCF15.jpg', '10');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('15', '1', 'Demo Flower 15', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_886FAF-5199A3-9758FB-406A40-59CDF0-C5C3C9.jpg', '4');


-- --------------------------------------------------
# -- Table structure for table `layout`
-- --------------------------------------------------
DROP TABLE IF EXISTS `layout`;
CREATE TABLE `layout` (
  `module_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL,
  `place` varchar(20) NOT NULL,
  `position` int(11) NOT NULL,
  KEY `idx_layout_id` (`page_id`),
  KEY `idx_plugin_id` (`module_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `layout`
-- --------------------------------------------------

INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '6', 'left', '5');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('9', '1', 'bottom', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('10', '1', 'bottom', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '2', 'right', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('1', '2', 'right', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '3', 'left', '13');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('14', '3', 'left', '12');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('8', '6', 'right', '8');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('9', '6', 'left', '7');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('11', '6', 'bottom', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('10', '6', 'bottom', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('3', '7', 'left', '7');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('5', '7', 'bottom', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('9', '7', 'left', '5');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('8', '7', 'right', '8');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('4', '7', 'left', '6');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('10', '7', 'bottom', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('1', '7', 'top', '3');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('11', '7', 'top', '4');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('6', '1', 'top', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('4', '6', 'left', '6');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('11', '1', 'bottom', '8');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('1', '8', 'right', '8');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('4', '8', 'right', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '8', 'right', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('13', '2', 'right', '11');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('7', '6', 'top', '6');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('12', '3', 'left', '14');


-- --------------------------------------------------
# -- Table structure for table `menus`
-- --------------------------------------------------
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `content_type` varchar(20) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT '0',
  `home_page` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `content_id` (`active`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `menus`
-- --------------------------------------------------

INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `position`, `home_page`, `active`) VALUES ('1', '0', '3', 'Contact Us', 'Contact-Us', 'page', '', '9', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `position`, `home_page`, `active`) VALUES ('2', '0', '1', 'Home', 'Home', 'page', '', '1', '1', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `position`, `home_page`, `active`) VALUES ('3', '0', '7', 'All Modules', 'All-Modules', 'page', '', '2', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `position`, `home_page`, `active`) VALUES ('4', '0', '6', 'Three Columns', 'Three-Columns', 'page', '', '3', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `position`, `home_page`, `active`) VALUES ('5', '0', '5', 'Full Width Page', 'Full-Width-Page', 'page', '', '5', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `position`, `home_page`, `active`) VALUES ('6', '0', '0', 'External Link', 'External-Link', 'web', 'http://www.google.com', '7', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `position`, `home_page`, `active`) VALUES ('7', '0', '8', 'Sample Submenus', 'Sample-Submenus', 'page', '', '4', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `position`, `home_page`, `active`) VALUES ('8', '7', '6', 'New Submenu 1', 'New-Submenu-1', 'page', '', '1', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `position`, `home_page`, `active`) VALUES ('9', '7', '7', 'New Submenu 2', 'New-Submenu-2', 'page', '', '2', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `position`, `home_page`, `active`) VALUES ('10', '9', '3', 'New Submenu 3', 'New-Submenu-3', 'page', '', '1', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `position`, `home_page`, `active`) VALUES ('11', '0', '2', 'About Us', 'About-Us', 'page', '', '8', '0', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_chat_canned`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_chat_canned`;
CREATE TABLE `mod_chat_canned` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cvalue` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_chat_canned`
-- --------------------------------------------------

INSERT INTO `mod_chat_canned` (`id`, `cvalue`) VALUES ('1', 'Hello, how may I help you?');
INSERT INTO `mod_chat_canned` (`id`, `cvalue`) VALUES ('2', 'Hello! Welcome to our support. How may I help you?');


-- --------------------------------------------------
# -- Table structure for table `mod_chat_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_chat_config`;
CREATE TABLE `mod_chat_config` (
  `updatefrequency_user` int(6) NOT NULL DEFAULT '0',
  `updatefrequency_operator` int(6) NOT NULL DEFAULT '0',
  `updatefrequency_chat` int(6) NOT NULL DEFAULT '0',
  `inactive_msg` int(6) NOT NULL DEFAULT '0',
  `conversation_end` int(6) NOT NULL DEFAULT '0',
  `remove_after` int(6) NOT NULL DEFAULT '0',
  `operator_available` tinyint(1) NOT NULL DEFAULT '0',
  `keep_alive` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_chat_config`
-- --------------------------------------------------

INSERT INTO `mod_chat_config` (`updatefrequency_user`, `updatefrequency_operator`, `updatefrequency_chat`, `inactive_msg`, `conversation_end`, `remove_after`, `operator_available`, `keep_alive`) VALUES ('2000', '2000', '3500', '500', '300', '3000', '0', '0');


-- --------------------------------------------------
# -- Table structure for table `mod_chat_msgs`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_chat_msgs`;
CREATE TABLE `mod_chat_msgs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `threadid` int(11) NOT NULL,
  `ikind` int(11) NOT NULL,
  `agentId` int(11) NOT NULL DEFAULT '0',
  `tmessage` text NOT NULL,
  `dtmcreated` datetime DEFAULT '0000-00-00 00:00:00',
  `tname` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=146 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_chat_msgs`
-- --------------------------------------------------

INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('1', '1', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 11:48:41', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('2', '1', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 11:48:41', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('3', '1', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 11:49:25', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('5', '1', '3', '0', 'Visitor closed chat window', '2011-01-04 11:49:36', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('6', '1', '6', '0', 'Operator Administrator left the chat', '2011-01-04 11:52:24', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('7', '2', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 11:55:12', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('8', '2', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 11:55:13', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('9', '2', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 11:55:49', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('11', '2', '2', '1', 'Hello! Welcome to our support. How may I help you?', '2011-01-04 11:55:55', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('12', '2', '1', '0', 'Dobro sam kako si ti', '2011-01-04 11:56:52', 'Mikan');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('13', '2', '1', '0', 'ima problem', '2011-01-04 11:57:47', 'Mikan');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('14', '2', '6', '0', 'Visitor Mikan left the chat', '2011-01-04 11:58:00', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('15', '3', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 11:58:39', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('16', '3', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 11:58:39', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('17', '3', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 11:58:50', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('19', '3', '2', '1', 'Hello, how may I help you?', '2011-01-04 11:58:54', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('20', '3', '6', '0', 'Visitor trta left the chat', '2011-01-04 12:03:06', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('21', '4', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 12:03:21', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('22', '4', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 12:03:21', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('23', '3', '3', '0', 'Visitor closed chat window', '2011-01-04 12:03:36', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('24', '4', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 12:03:43', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('26', '4', '2', '1', 'Hello, how may I help you?', '2011-01-04 12:03:48', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('27', '4', '1', '0', 'problem', '2011-01-04 12:04:12', 'trtavac');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('28', '4', '2', '1', 'Hello! Welcome to our support. How may I help you?', '2011-01-04 12:04:21', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('29', '4', '2', '1', 'Hello, how may I help you?', '2011-01-04 12:07:45', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('30', '4', '6', '0', 'Visitor trtavac left the chat', '2011-01-04 12:08:03', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('31', '4', '6', '0', 'Operator Administrator left the chat', '2011-01-04 12:08:12', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('32', '5', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 12:08:56', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('33', '5', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 12:08:56', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('34', '5', '6', '0', 'Visitor trtavac left the chat', '2011-01-04 12:10:49', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('35', '6', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 17:59:41', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('36', '6', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 17:59:41', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('37', '6', '6', '0', 'Visitor Gewa left the chat', '2011-01-04 17:59:47', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('38', '7', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 18:37:49', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('39', '7', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 18:37:49', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('40', '8', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 18:38:28', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('41', '8', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 18:38:28', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('43', '8', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 18:44:19', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('46', '7', '3', '0', 'Visitor navigated to http://agda-graph/livechat/chat.php', '2011-01-04 18:45:10', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('47', '7', '6', '0', 'Visitor joined chat again', '2011-01-04 18:45:11', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('49', '7', '6', '0', 'Operator Administrator is back', '2011-01-04 18:45:17', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('51', '7', '3', '0', 'Visitor navigated to http://agda-graph/livechat/chat.php', '2011-01-04 18:50:17', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('52', '8', '6', '0', 'Operator Administrator left the chat', '2011-01-04 18:50:23', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('54', '7', '6', '0', 'Operator Administrator left the chat', '2011-01-04 18:50:30', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('55', '9', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 18:50:41', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('56', '9', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 18:50:41', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('57', '9', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 18:50:45', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('59', '9', '6', '0', 'Operator Administrator left the chat', '2011-01-04 18:50:56', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('60', '9', '6', '0', 'Visitor Gewa left the chat', '2011-01-04 18:51:02', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('61', '10', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 18:55:59', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('62', '10', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 18:55:59', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('63', '10', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 18:56:03', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('65', '10', '6', '0', 'Operator Administrator left the chat', '2011-01-04 18:56:37', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('66', '11', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 19:02:17', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('67', '11', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 19:02:17', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('68', '11', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 19:02:21', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('70', '11', '2', '1', 'Hello! Welcome to our support. How may I help you?', '2011-01-04 19:02:26', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('71', '11', '1', '0', 'problem', '2011-01-04 19:02:34', 'aLEXA');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('72', '11', '5', '0', 'Visitor aLEXA left the chat', '2011-01-04 19:02:37', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('73', '12', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 19:17:40', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('74', '12', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 19:17:40', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('75', '12', '5', '0', 'Operator Administrator joined the chat', '2011-01-04 19:17:45', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('77', '12', '2', '1', 'Hello, how may I help you?', '2011-01-04 19:17:49', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('78', '12', '1', '0', '123456', '2011-01-04 19:17:56', 'aLEXA');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('79', '12', '5', '0', 'Visitor aLEXA left the chat', '2011-01-04 19:18:01', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('80', '13', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 19:40:37', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('81', '13', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 19:40:37', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('82', '13', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 19:40:40', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('84', '13', '2', '1', 'Hello! Welcome to our support. How may I help you?', '2011-01-04 19:40:46', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('85', '13', '6', '0', 'Visitor aLEXA left the chat', '2011-01-04 19:40:50', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('86', '14', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 21:39:10', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('87', '14', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 21:39:10', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('88', '14', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 21:39:14', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('90', '14', '2', '1', 'Hello! Welcome to our support. How may I help you?', '2011-01-04 21:39:23', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('91', '14', '1', '0', 'problem', '2011-01-04 21:40:12', 'aLEXA');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('92', '14', '6', '0', 'Visitor aLEXA left the chat', '2011-01-04 21:40:23', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('93', '15', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 21:47:19', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('94', '15', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 21:47:19', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('95', '15', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 21:47:22', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('97', '15', '2', '1', 'Hello! Welcome to our support. How may I help you?', '2011-01-04 21:47:30', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('98', '15', '6', '0', 'Visitor aLEXA left the chat', '2011-01-04 21:47:33', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('99', '16', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 22:00:23', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('100', '16', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 22:00:23', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('101', '16', '2', '1', 'Hello! Welcome to our support. How may I help you?', '2011-01-04 22:01:13', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('102', '16', '1', '0', 'test', '2011-01-04 22:01:26', 'aLEXA');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('103', '17', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 22:03:43', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('104', '17', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 22:03:43', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('106', '17', '2', '1', 'Hello! Welcome to our support. How may I help you?', '2011-01-04 23:26:46', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('107', '17', '6', '0', 'Operator Administrator left the chat', '2011-01-04 23:26:57', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('108', '18', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 23:27:38', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('109', '18', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 23:27:38', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('110', '18', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 23:28:32', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('112', '18', '2', '1', 'Hello, how may I help you?', '2011-01-04 23:29:17', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('113', '18', '1', '0', 'problem', '2011-01-04 23:29:26', 'aLEXA');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('114', '18', '6', '0', 'Visitor aLEXA left the chat', '2011-01-04 23:29:30', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('115', '18', '6', '0', 'Visitor aLEXA left the chat', '2011-01-04 23:29:38', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('116', '18', '6', '0', 'Operator Administrator left the chat', '2011-01-04 23:29:45', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('117', '18', '6', '0', 'Operator Administrator left the chat', '2011-01-04 23:29:57', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('119', '18', '6', '0', 'Operator Administrator left the chat', '2011-01-04 23:32:19', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('120', '18', '6', '0', 'Operator Administrator left the chat', '2011-01-04 23:32:30', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('121', '18', '6', '0', 'Operator Administrator left the chat', '2011-01-04 23:32:49', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('122', '18', '6', '0', 'Operator Administrator left the chat', '2011-01-04 23:34:33', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('123', '19', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 23:34:49', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('124', '19', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 23:34:49', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('125', '19', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 23:34:54', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('127', '19', '2', '1', 'Hello! Welcome to our support. How may I help you?', '2011-01-04 23:34:58', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('128', '19', '6', '0', 'Visitor aLEXA left the chat', '2011-01-04 23:35:02', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('129', '19', '6', '0', 'Operator Administrator left the chat', '2011-01-04 23:35:06', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('130', '20', '3', '0', 'Vistor came from page http://agda-graph/livechat/chat.php', '2011-01-04 23:51:22', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('131', '20', '4', '0', 'Thank you for contacting us. An operator will be with you shortly...', '2011-01-04 23:51:22', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('132', '20', '6', '0', 'Operator Administrator joined the chat', '2011-01-04 23:51:25', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('134', '20', '2', '1', 'Hello! Welcome to our support. How may I help you?', '2011-01-04 23:51:28', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('135', '20', '6', '0', 'Visitor aLEXA left the chat', '2011-01-04 23:51:32', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('136', '20', '6', '0', 'Operator Administrator left the chat', '2011-01-04 23:51:36', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('137', '21', '6', '0', 'Visitor joined chat again', '2011-01-05 02:51:07', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('138', '21', '6', '0', 'Operator Administrator joined the chat', '2011-01-05 02:53:02', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('140', '21', '2', '1', 'Hello! Welcome to our support. How may I help you?', '2011-01-05 02:53:08', 'Administrator');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('141', '21', '1', '0', 'gooding', '2011-01-05 02:53:20', 'aLEXA');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('142', '21', '6', '0', 'Visitor aLEXA left the chat', '2011-01-05 02:56:28', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('143', '21', '6', '0', 'Operator Administrator left the chat', '2011-01-05 02:56:35', '');
INSERT INTO `mod_chat_msgs` (`id`, `threadid`, `ikind`, `agentId`, `tmessage`, `dtmcreated`, `tname`) VALUES ('144', '22', '6', '0', 'Operator Administrator joined the chat', '2011-01-06 01:43:40', '');


-- --------------------------------------------------
# -- Table structure for table `mod_chat_thread`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_chat_thread`;
CREATE TABLE `mod_chat_thread` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(64) NOT NULL,
  `userid` varchar(255) DEFAULT NULL,
  `agentName` varchar(64) DEFAULT NULL,
  `agentId` int(11) NOT NULL DEFAULT '0',
  `dtmcreated` datetime DEFAULT '0000-00-00 00:00:00',
  `dtmmodified` datetime DEFAULT '0000-00-00 00:00:00',
  `lrevision` int(11) NOT NULL DEFAULT '0',
  `istate` int(11) NOT NULL DEFAULT '0',
  `ltoken` int(11) NOT NULL,
  `remote` varchar(255) DEFAULT NULL,
  `referer` text,
  `lastpinguser` datetime DEFAULT '0000-00-00 00:00:00',
  `lastpingagent` datetime DEFAULT '0000-00-00 00:00:00',
  `shownmessageid` int(11) NOT NULL DEFAULT '0',
  `userAgent` varchar(255) DEFAULT NULL,
  `messageCount` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_chat_thread`
-- --------------------------------------------------

INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('1', 'Gewa', '1294031460.25249945678', 'Administrator', '1', '2011-01-04 11:48:41', '2011-01-04 11:52:24', '5', '3', '65781322', '127.0.0.1', 'http://agda-graph/livechat/chat.php', '0000-00-00 00:00:00', '2011-01-04 11:52:24', '0', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('2', 'Mikan', '1294160102.81067257080', 'Administrator', '1', '2011-01-04 11:55:12', '2011-01-04 11:58:00', '10', '3', '26428624', '192.168.230.185', 'http://agda-graph/livechat/chat.php', '2011-01-04 11:58:02', '2011-01-04 11:58:14', '12', 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.224 Safari/534.10', '2');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('3', 'trta', '1294160313.58781235961', 'Administrator', '1', '2011-01-04 11:58:38', '2011-01-04 12:03:06', '14', '3', '52129217', '192.168.230.185', 'http://agda-graph/livechat/chat.php', '0000-00-00 00:00:00', '2011-01-04 12:05:24', '0', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('4', 'trtavac', '1294160313.58781235961', 'Administrator', '1', '2011-01-04 12:03:21', '2011-01-04 12:08:03', '19', '3', '73936611', '192.168.230.185', 'http://agda-graph/livechat/chat.php', '2011-01-04 12:08:05', '2011-01-04 12:08:12', '27', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)', '1');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('5', 'trtavac', '1294160313.58781235961', '', '0', '2011-01-04 12:08:56', '2011-01-04 12:10:49', '22', '3', '41663009', '192.168.230.185', 'http://agda-graph/livechat/chat.php', '2011-01-04 12:10:50', '0000-00-00 00:00:00', '0', 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('6', 'Gewa', '1294031460.25249945678', '', '0', '2011-01-04 17:59:41', '2011-01-04 17:59:47', '25', '3', '87579571', '127.0.0.1', 'http://agda-graph/livechat/chat.php', '2011-01-04 17:59:48', '0000-00-00 00:00:00', '0', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('7', 'Gewa', '1294031460.25249945678', 'Administrator', '1', '2011-01-04 18:37:49', '2011-01-04 18:50:30', '35', '3', '7380309', '127.0.0.1', 'http://agda-graph/livechat/chat.php', '0000-00-00 00:00:00', '2011-01-04 18:50:31', '0', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('8', 'Visitor', '1294110848.631979769897', 'Administrator', '1', '2011-01-04 18:38:28', '2011-01-04 18:50:23', '34', '3', '33580889', '127.0.0.1', 'http://agda-graph/livechat/chat.php', '0000-00-00 00:00:00', '2011-01-04 18:50:24', '0', 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.13) Gecko/20101203 Firefox/3.6.13', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('9', 'Gewa', '1294031460.25249945678', 'Administrator', '1', '2011-01-04 18:50:41', '2011-01-04 18:50:56', '39', '3', '96140338', '127.0.0.1', 'http://agda-graph/livechat/chat.php', '2011-01-04 18:51:04', '2011-01-04 18:51:05', '0', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('10', 'aLEXA', '1294031460.25249945678', 'Administrator', '1', '2011-01-04 18:55:59', '2011-01-04 18:56:37', '43', '3', '39294164', '127.0.0.1', 'http://agda-graph/livechat/chat.php', '2011-01-04 18:56:41', '2011-01-04 18:56:38', '0', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('11', 'aLEXA', '1294031460.25249945678', 'Administrator', '1', '2011-01-04 19:02:17', '2011-01-04 19:02:37', '48', '3', '26687764', '127.0.0.1', 'http://agda-graph/livechat/chat.php', '2011-01-04 19:02:39', '2011-01-04 19:02:41', '71', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '1');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('12', 'aLEXA', '1294031460.25249945678', 'Administrator', '1', '2011-01-04 19:17:40', '2011-01-04 19:18:01', '53', '3', '25303652', '127.0.0.1', 'http://agda-graph/livechat/chat.php', '2011-01-04 19:18:02', '2011-01-04 19:18:04', '78', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '1');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('13', 'aLEXA', '1294031460.25249945678', 'Administrator', '1', '2011-01-04 19:40:37', '2011-01-04 19:40:50', '57', '3', '74604278', '173.35.198.119', 'http://agda-graph/livechat/chat.php', '2011-01-04 19:40:50', '2011-01-04 19:40:53', '0', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('14', 'aLEXA', '1294031460.25249945678', 'Administrator', '1', '2011-01-04 21:39:10', '2011-01-04 21:40:23', '62', '3', '57976635', '127.0.0.1', 'http://agda-graph/livechat/chat.php', '2011-01-04 21:40:24', '2011-01-04 21:40:25', '91', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '1');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('15', 'aLEXA', '1294031460.25249945678', 'Administrator', '1', '2011-01-04 21:47:19', '2011-01-04 21:47:33', '66', '3', '69705007', '127.0.0.1', 'http://agda-graph/livechat/chat.php', '2011-01-04 21:47:33', '2011-01-04 21:47:34', '0', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('16', 'aLEXA', '1294031460', 'Administrator', '1', '2011-01-04 22:00:23', '2011-01-04 22:01:30', '71', '3', '23193947', '127', 'http://agda-graph/livechat/chat.php', '2011-01-04 22:02:50', '0000-00-00 00:00:00', '102', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '1');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('17', 'aLEXA', '1294031460', 'Administrator', '1', '2011-01-04 22:03:43', '2011-01-04 23:26:57', '75', '3', '6462648', '127', 'http://agda-graph/livechat/chat.php', '0000-00-00 00:00:00', '2011-01-04 23:27:00', '0', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('18', 'aLEXA', '1294031460', 'Administrator', '1', '2011-01-04 23:27:38', '2011-01-04 23:29:30', '80', '3', '97780541', '127', 'http://agda-graph/livechat/chat.php', '0000-00-00 00:00:00', '2011-01-04 23:34:33', '113', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '1');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('19', 'aLEXA', '1294031460', 'Administrator', '1', '2011-01-04 23:34:49', '2011-01-04 23:35:02', '84', '3', '15907540', '127', 'http://agda-graph/livechat/chat.php', '2011-01-04 23:35:04', '2011-01-04 23:35:06', '0', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('20', 'aLEXA', '1294031460', 'Administrator', '1', '2011-01-04 23:51:22', '2011-01-04 23:51:32', '88', '3', '92466647', '127', 'http://agda-graph/livechat/chat.php', '2011-01-04 23:51:34', '2011-01-04 23:51:36', '0', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '0');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('21', 'aLEXA', '1294031460', 'Administrator', '1', '2011-01-05 02:50:31', '2011-01-05 02:56:28', '93', '3', '31873613', '127', 'http://agda-graph/livechat/chat.php', '2011-01-05 02:56:29', '2011-01-05 02:56:35', '141', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '1');
INSERT INTO `mod_chat_thread` (`id`, `userName`, `userid`, `agentName`, `agentId`, `dtmcreated`, `dtmmodified`, `lrevision`, `istate`, `ltoken`, `remote`, `referer`, `lastpinguser`, `lastpingagent`, `shownmessageid`, `userAgent`, `messageCount`) VALUES ('22', 'aLEXA', '1294031460', 'Administrator', '1', '2011-01-06 01:43:32', '2011-01-06 01:43:40', '95', '2', '30693764', '127', 'http://agda-graph/livechat/chat.php', '0000-00-00 00:00:00', '2011-01-06 01:44:36', '0', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.1; Trident/4.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; .NET4.0C)', '');


-- --------------------------------------------------
# -- Table structure for table `mod_comments`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_comments`;
CREATE TABLE `mod_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `username` varchar(24) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `body` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `www` varchar(220) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip` varchar(16) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent` (`parent_id`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_comments`
-- --------------------------------------------------

INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('1', '0', '2', 'Webmaster', 'webmaster@zazavi.com', 'First comment is on me.', 'http://www.zazavi.com', '2011-01-30 16:34:55', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('2', '3', '2', 'Admin', 'admin@mail.com', '<pre>Cum sociis natoque penatibus et <strong>magnis dis parturient</strong> montes, </pre>nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio auctor quis.', '', '2011-01-31 08:40:42', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('3', '5', '2', 'User1', 'user1@mail.com', 'Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed risus in est cursus ornare.', '', '2011-01-31 08:45:54', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('4', '0', '2', 'User2', 'user2@mail.com', 'Etiam non lacus ac velit <em>lobortis rutrum sed</em> id turpis. <code>Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris,</code>sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit commodo.', '', '2011-01-31 08:48:26', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('5', '0', '2', 'User3', 'user3@mail.com', 'In hac habit***e platea dictumst.ivamus leo diam, dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus sit amet bibendum faucibus, nisi ligula ultricies purus', '', '2011-01-31 08:51:25', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('6', '0', '2', 'User4', 'user4@mail.com', 'Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam, dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus sit amet bibendum faucibus, nisi ligula ultricies purus, in malesuada arcu sem ut mauris. Proin lobortis rutrum ultrices.', '', '2011-01-31 08:53:51', '127.0.0.1', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_comments_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_comments_config`;
CREATE TABLE `mod_comments_config` (
  `username_req` tinyint(1) NOT NULL DEFAULT '0',
  `email_req` tinyint(1) NOT NULL DEFAULT '0',
  `show_captcha` tinyint(1) NOT NULL DEFAULT '1',
  `show_www` tinyint(1) NOT NULL DEFAULT '0',
  `show_username` tinyint(1) DEFAULT '1',
  `show_email` tinyint(1) DEFAULT '1',
  `auto_approve` tinyint(1) NOT NULL DEFAULT '0',
  `notify_new` tinyint(1) NOT NULL DEFAULT '0',
  `sorting` varchar(4) NOT NULL DEFAULT 'DESC',
  `blacklist_words` text,
  `char_limit` varchar(6) NOT NULL DEFAULT '400',
  `perpage` varchar(3) NOT NULL DEFAULT '10',
  `dateformat` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_comments_config`
-- --------------------------------------------------

INSERT INTO `mod_comments_config` (`username_req`, `email_req`, `show_captcha`, `show_www`, `show_username`, `show_email`, `auto_approve`, `notify_new`, `sorting`, `blacklist_words`, `char_limit`, `perpage`, `dateformat`) VALUES ('1', '1', '1', '1', '1', '0', '0', '0', 'DESC', 'arse\r\narses\r\nass\r\nasses\r\nbollocks\r\ncrap', '400', '5', '%d %M %Y %H:%i');


-- --------------------------------------------------
# -- Table structure for table `mod_events`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_events`;
CREATE TABLE `mod_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `venue` varchar(150) NOT NULL,
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00',
  `time_start` time NOT NULL DEFAULT '00:00:00',
  `time_end` time NOT NULL DEFAULT '00:00:00',
  `body` text NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `contact_email` varchar(80) NOT NULL,
  `contact_phone` varchar(16) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_events`
-- --------------------------------------------------

INSERT INTO `mod_events` (`id`, `title`, `venue`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('1', 'Free Coffee for Each Monday', 'Office Rental Showroom', '2010-12-08', '2010-12-31', '11:18:00', '21:00:00', 'Vestibulum dictum elit eu risus porta egestas. Sed quis enim neque, sed  fringilla erat. Nunc feugiat tortor eu sem consequat aliquam. Cras non  nibh at lorem auctor interdum. Donec ut lacinia massa.', 'John Doe', 'john@gmail.com', '555-555-5555', '1');
INSERT INTO `mod_events` (`id`, `title`, `venue`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('2', 'Lucky Draw', 'Office Rental Showroom', '2010-12-21', '2010-12-31', '13:30:00', '11:00:00', '&lt;p&gt;&lt;img width=&quot;150&quot; height=&quot;98&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/thumbs/thumb_demo_1.jpg&quot; alt=&quot;thumb_demo_1.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Pellentesque habitant morbi tristique senectus et netus et malesuada  fames ac turpis egestas. Nulla posuere nibh auctor urna tincidunt  fringilla. &lt;br /&gt;\r\nDonec imperdiet, orci quis aliquet laoreet, magna purus semper ligula,  sit amet aliquam sapien enim in orci. Pellentesque at iaculis nibh.&lt;/p&gt;', 'John Doe', 'john@gmail.com', '555-555-5555', '1');
INSERT INTO `mod_events` (`id`, `title`, `venue`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('3', 'E-Commerce Seminar', 'Office Rental Showroom', '2011-01-19', '2011-01-19', '09:30:00', '13:30:00', 'Proin nec nisl est, id ornare lacus. Etiam mauris neque, scelerisque ut  ultrices vel, blandit et nisi. Nam commodo fermentum lectus vulputate  auctor. Maecenas hendrerit sapien sit amet erat mollis venenatis nec sit', 'John Doe', 'john@gmail.com', '555-555-5555', '1');
INSERT INTO `mod_events` (`id`, `title`, `venue`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('4', 'E-Commerce Seminar II', 'Office Rental Showroom', '2011-01-19', '2011-01-19', '17:00:00', '19:00:00', 'Aliquam auctor molestie ipsum ultricies tincidunt. Suspendisse potenti.  Nulla volutpat urna et mi consectetur placerat iaculis lacus lacinia.  Integer a nisi id diam tempus commodo eget a tellus. In consequat augue  nec tortor bibendum vel semper metus sodales. Donec ut dui nisi, id  posuere augue.', 'John Doe', 'john@gmail.com', '555-555-5555', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_newsslider`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_newsslider`;
CREATE TABLE `mod_newsslider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) DEFAULT NULL,
  `body` text,
  `show_title` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  `show_created` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_newsslider`
-- --------------------------------------------------

INSERT INTO `mod_newsslider` (`id`, `title`, `body`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('1', 'Etiam non lacus', 'Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam, dignissim  eu convallis in, posuere quis magna. Curabitur mollis, lectus sit amet  bibendum faucibus, nisi ligula ultricies purus', '1', '2010-10-28 04:14:11', '1', '1', '1');
INSERT INTO `mod_newsslider` (`id`, `title`, `body`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('2', 'Cras ullamcorper', 'Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros  eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna  sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed  risus in est cursus ornare.', '1', '2010-10-28 04:14:33', '1', '2', '1');
INSERT INTO `mod_newsslider` (`id`, `title`, `body`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('3', 'Vivamus vitae', 'Lusce pulvinar velit sit amet ligula ornare tempus vulputate ipsum  semper. Praesent non lorem odio. Fusce sed dui massa, eu viverra erat.  Proin posuere nulla in lectus malesuada volutpat. Cras tristique blandit  tellus, eu consequat ante', '1', '2010-10-28 04:21:34', '1', '3', '1');
INSERT INTO `mod_newsslider` (`id`, `title`, `body`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('4', 'Another News', 'Vivamus vitae augue sed lacus placerat sollicitudin quis vel arcu. Vestibulum auctor, magna sit amet pulvinar tristique, nunc felis viverra tortor, venenatis convallis leo mauris eu massa. Intege', '1', '2010-10-28 04:43:36', '1', '4', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_poll_options`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_poll_options`;
CREATE TABLE `mod_poll_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `value` varchar(300) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `position` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_poll_options`
-- --------------------------------------------------

INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `position`) VALUES ('5', '1', 'Very Hard', '5');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `position`) VALUES ('4', '1', 'Hard', '4');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `position`) VALUES ('3', '1', 'Easy', '3');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `position`) VALUES ('2', '1', 'Very Easy', '2');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `position`) VALUES ('1', '1', 'Piece of cake', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_poll_questions`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_poll_questions`;
CREATE TABLE `mod_poll_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_poll_questions`
-- --------------------------------------------------

INSERT INTO `mod_poll_questions` (`id`, `question`, `created`, `status`) VALUES ('1', 'How do you find Zazavi Installation?', '2010-10-13 07:42:18', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_poll_votes`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_poll_votes`;
CREATE TABLE `mod_poll_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_id` int(11) NOT NULL,
  `voted_on` datetime NOT NULL,
  `ip` varchar(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_poll_votes`
-- --------------------------------------------------

INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('1', '2', '2010-10-14 14:00:55', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('2', '1', '2010-10-14 14:01:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('3', '1', '2010-10-14 14:02:04', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('4', '1', '2010-10-14 14:02:13', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('5', '3', '2010-10-14 14:02:16', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('6', '4', '2010-10-14 14:02:21', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('7', '3', '2010-10-14 14:02:24', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('8', '1', '2010-10-14 14:02:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('9', '2', '2010-10-14 14:02:31', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('10', '5', '2010-10-14 14:02:35', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('11', '1', '2010-10-14 14:02:38', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('12', '2', '2010-10-14 14:02:43', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('13', '1', '2010-10-14 14:02:46', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('14', '1', '2010-10-14 14:02:50', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('15', '1', '2010-10-14 14:05:26', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('16', '1', '2010-10-14 14:05:29', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('17', '4', '2010-10-14 14:05:33', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('18', '2', '2010-10-14 14:05:36', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('19', '1', '2010-10-14 14:05:40', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('20', '3', '2010-10-14 14:05:46', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('21', '2', '2010-10-14 14:05:49', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('22', '2', '2010-10-14 14:21:37', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('23', '1', '2010-10-14 14:21:53', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('24', '5', '2010-10-14 14:21:59', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('25', '1', '2010-10-14 14:35:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('26', '1', '2010-10-15 00:42:05', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('27', '3', '2010-10-15 00:49:42', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('28', '2', '2010-10-15 01:22:00', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('29', '2', '2010-10-15 01:24:51', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('30', '1', '2010-10-15 01:37:21', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('31', '1', '2010-10-15 01:38:48', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('32', '1', '2010-10-15 01:41:30', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('33', '1', '2010-10-15 01:42:21', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('34', '1', '2010-10-15 04:53:42', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('35', '3', '2010-10-15 05:09:14', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('36', '3', '2010-11-24 21:00:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('37', '3', '2010-11-28 00:56:07', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('38', '1', '2011-02-14 17:13:57', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('39', '1', '2011-02-14 17:15:37', '127.0.0.1');


-- --------------------------------------------------
# -- Table structure for table `mod_slider`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_slider`;
CREATE TABLE `mod_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL DEFAULT '',
  `filename` varchar(150) NOT NULL DEFAULT '',
  `url` varchar(150) NOT NULL DEFAULT '',
  `page_id` int(6) DEFAULT '0',
  `urltype` enum('int','ext') DEFAULT NULL,
  `position` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_slider`
-- --------------------------------------------------

INSERT INTO `mod_slider` (`id`, `title`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('9', 'Demo Image 4', 'sports_4.jpg', '#', '0', 'ext', '1');
INSERT INTO `mod_slider` (`id`, `title`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('7', 'Demo Image 3', 'sports_2.jpg', '#', '0', 'ext', '2');
INSERT INTO `mod_slider` (`id`, `title`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('8', 'Demo Image 2', 'sports_3.jpg', '#', '0', '', '3');
INSERT INTO `mod_slider` (`id`, `title`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('6', 'Demo Image 1', 'sports_1.jpg', '#', '0', '', '4');


-- --------------------------------------------------
# -- Table structure for table `mod_slider_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_slider_config`;
CREATE TABLE `mod_slider_config` (
  `animation` varchar(30) NOT NULL,
  `anispeed` varchar(6) NOT NULL DEFAULT '0',
  `anitime` varchar(10) NOT NULL DEFAULT '0',
  `shownav` tinyint(1) NOT NULL DEFAULT '0',
  `shownavhide` tinyint(1) NOT NULL DEFAULT '0',
  `controllnav` tinyint(1) NOT NULL DEFAULT '0',
  `hoverpause` tinyint(1) NOT NULL DEFAULT '0',
  `showcaption` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_slider_config`
-- --------------------------------------------------

INSERT INTO `mod_slider_config` (`animation`, `anispeed`, `anitime`, `shownav`, `shownavhide`, `controllnav`, `hoverpause`, `showcaption`) VALUES ('fade', '500', '3000', '1', '1', '1', '1', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_tabs`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_tabs`;
CREATE TABLE `mod_tabs` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `body` text,
  `position` int(6) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_tabs`
-- --------------------------------------------------

INSERT INTO `mod_tabs` (`id`, `title`, `body`, `position`, `active`) VALUES ('1', 'Website Design', '&lt;img width=&quot;305&quot; height=&quot;220&quot; style=&quot;margin-left: 15px; float: right;&quot; alt=&quot;webdesign.png&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/webdesign.png&quot; /&gt;\r\n&lt;h1&gt;Website Design&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;\r\n&lt;br class=&quot;clear&quot; /&gt;', '1', '1');
INSERT INTO `mod_tabs` (`id`, `title`, `body`, `position`, `active`) VALUES ('2', 'Content Management', '&lt;img width=&quot;305&quot; height=&quot;220&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/cms.png&quot; alt=&quot;cms.png&quot; style=&quot;margin-left: 15px; float: right;&quot; /&gt;\r\n&lt;h1&gt;Content Management&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;&lt;br class=&quot;clear&quot; /&gt;', '2', '1');
INSERT INTO `mod_tabs` (`id`, `title`, `body`, `position`, `active`) VALUES ('3', 'E-Commerce', '&lt;img width=&quot;305&quot; height=&quot;220&quot; style=&quot;margin-left: 15px; float: right;&quot; alt=&quot;ecommerce.png&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/ecommerce.png&quot; /&gt;\r\n&lt;h1&gt;E-Commerce&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;\r\n&lt;br class=&quot;clear&quot; /&gt;', '3', '1');
INSERT INTO `mod_tabs` (`id`, `title`, `body`, `position`, `active`) VALUES ('4', 'Search Engines', '&lt;img width=&quot;305&quot; height=&quot;220&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/seo.png&quot; alt=&quot;seo.png&quot; style=&quot;margin-left: 15px; float: right;&quot; /&gt;\r\n&lt;h1&gt;Search Engines&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;<br />\r\n&lt;p&gt;&lt;a href=&quot;#&quot; class=&quot;button shadow&quot;&gt;Read More&lt;/a&gt;&lt;/p&gt;&lt;br class=&quot;clear&quot; /&gt;', '4', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_twitter`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_twitter`;
CREATE TABLE `mod_twitter` (
  `username` varchar(150) DEFAULT NULL,
  `counter` int(1) NOT NULL DEFAULT '5',
  `speed` varchar(6) NOT NULL,
  `timeout` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_twitter`
-- --------------------------------------------------

INSERT INTO `mod_twitter` (`username`, `counter`, `speed`, `timeout`) VALUES ('ZazaviDotCom', '5', '300', '10000');


-- --------------------------------------------------
# -- Table structure for table `modules`
-- --------------------------------------------------
DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL,
  `body` text,
  `show_title` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0',
  `info` text,
  `modalias` varchar(50) NOT NULL,
  `hasconfig` tinyint(1) NOT NULL DEFAULT '0',
  `sidebar` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `modules`
-- --------------------------------------------------

INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('1', 'Testimonials', '&lt;p class=&quot;testimonial&quot;&gt;&lt;em&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi.&lt;/em&gt;&lt;/p&gt;\r\n&lt;em&gt;John Smith&lt;/em&gt;, &lt;strong&gt;www.somesite.com&lt;/strong&gt;', '1', '1', '0', '', '', '0', '1', '2011-04-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('2', 'News Slider', '', '1', '2', '1', 'Displays latest news items', 'newsslider', '1', '1', '2011-04-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('8', 'More Pages', '&lt;ul class=&quot;lists&quot;&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Home&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Page Types&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Templates&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;About Us&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Services &lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Projects&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Blog&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Contact Us&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '0', '0', '', '', '0', '1', '2010-07-22 11:38:51', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('3', 'An unordered list', 'This modul contains a dummy list of items\r\n&lt;ul&gt;\r\n    &lt;li&gt;List item 1&lt;/li&gt;\r\n    &lt;li&gt;List item 2&lt;/li&gt;\r\n    &lt;li&gt;List item 3&lt;/li&gt;\r\n    &lt;li&gt;List item 4&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '1', '0', '', '', '0', '1', '2011-04-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('4', 'Info Point', '&lt;ul id=&quot;infopoint-list&quot;&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/iphone.png&quot; /&gt; Cum sociis natoque penatibus et magnis dis parturient montes&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/green.png&quot; /&gt; Curabitur mollis, lectus sit amet bibendum faucibus ligula&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/installer_box.png&quot; /&gt; Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/headphone.png&quot; /&gt; Cras ullamcorper suscipit  justo, at mattis odio auctor quis alteno&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/coins.png&quot; /&gt; Vestibulum  auctor, magna sit amet pulvinar tristique, nunc felis viverra&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/color_wheel.png&quot; /&gt; Integer aliquet libero sed lorem consequat ut tempus faucibus&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '1', '0', '', '', '0', '1', '2011-04-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('5', 'Our Contact Numbers', '&lt;strong&gt;Office&lt;/strong&gt; +1-416-123456789&lt;br /&gt;\r\n&lt;strong&gt;helpdesk&lt;/strong&gt; +1-416-123456789&lt;br /&gt;', '1', '2', '0', '', '', '0', '1', '2011-04-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('6', 'jQuery Slider', '', '0', '3', '1', 'jQuery Slider is one great way to display portfolio pieces, eCommerce product images, or even as an image gallery.', 'jqueryslider', '1', '1', '2011-04-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('11', 'Contact Information', '&lt;ul&gt;\r\n    &lt;li&gt;&lt;b&gt;E-mail:&lt;/b&gt; &lt;a href=&quot;mailto:info@mywebsite.com&quot;&gt;info@mywebsite.com&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;b&gt;Telephone:&lt;/b&gt; 0080 000 000&lt;/li&gt;\r\n    &lt;li&gt;&lt;b&gt;Fax:&lt;/b&gt; 0080 000 000&lt;/li&gt;\r\n    &lt;li&gt;&lt;b&gt;Address:&lt;/b&gt;     1600 Amphitheatre Parkway                 Toronto, ON M2K 1Z7&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '0', '0', '', '', '0', '1', '2010-07-22 11:44:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('9', 'Even More Pages', '&lt;ul class=&quot;lists&quot;&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Updates&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;News&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Press Releases&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;New Offers&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Our Staff &lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Policy&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Events&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '0', '0', '', '', '0', '1', '2010-07-22 11:39:22', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('10', 'Latest Twitts', '', '1', '4', '1', 'Shows your latest twitts', 'twitts', '1', '1', '2010-07-22 11:42:08', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('13', 'Ajax Poll', '', '1', '5', '1', 'jQuery Ajax poll module.', 'poll', '1', '1', '2010-10-25 14:12:20', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('7', 'jQuery Tabs', '', '0', '7', '1', 'jQuery Dynamic Tabs', 'jtabs', '1', '1', '2010-12-20 12:12:20', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('12', 'Event Manager', '', '1', '8', '1', 'Easily publish and manage your company events.', 'events', '1', '1', '2010-12-28 10:12:14', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('14', 'Vertical Navigation', '', '1', '9', '1', 'Vertical flyout menu module', 'vmenu', '0', '1', '2010-12-27 08:12:14', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('15', 'Commenting System', '', '0', '10', '1', 'Encourage your readers to join in the discussion and leave comments and respond promptly to the comments left by your readers to make them feel valued', 'comments', '1', '0', '2011-01-10 06:19:32', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('16', 'Live Support', '', '1', '12', '1', 'With Live Support online chat, you have the ability to offer immediate service to your customers.', 'chat', '1', '1', '2011-01-10 06:19:32', '1');


-- --------------------------------------------------
# -- Table structure for table `pages`
-- --------------------------------------------------
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `contact_form` tinyint(1) NOT NULL DEFAULT '0',
  `gallery_id` int(4) NOT NULL DEFAULT '0',
  `comments` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  `keywords` text NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `pages`
-- --------------------------------------------------

INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `position`, `keywords`, `description`, `created`, `active`) VALUES ('1', 'Home', 'Home', '0', '0', '0', '1', 'zazaviliteCMS, Zazavi CMS, Content Menagement System, Lightweight CMS', 'Zazavi CMS is a web content management system made for the peoples who don&#39;t have much technical knowledge of HTML or PHP but know how to use a simple notepad with computer keyboard.', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `position`, `keywords`, `description`, `created`, `active`) VALUES ('2', 'What is Zazavi', 'What-is-Zazavi', '0', '0', '1', '2', 'Zazavi, Content Management System, Lightweight CMS', 'Zazavi is a php based database dependent CMS which require one database and obviously php language support on your web hosting server.', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `position`, `keywords`, `description`, `created`, `active`) VALUES ('3', 'Contact Info', 'Contact-Info', '1', '0', '0', '3', '', '', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `position`, `keywords`, `description`, `created`, `active`) VALUES ('5', 'Demo Gallery', 'Demo-Gallery', '0', '1', '0', '0', '', '', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `position`, `keywords`, `description`, `created`, `active`) VALUES ('6', 'Three Column Page', 'Tree-Column-Page', '0', '0', '0', '0', '', '', '2010-07-22 20:26:17', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `position`, `keywords`, `description`, `created`, `active`) VALUES ('7', 'All Modules', 'All-Modules', '0', '0', '0', '0', '', '', '2010-07-22 20:40:19', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `position`, `keywords`, `description`, `created`, `active`) VALUES ('8', 'More Pages', 'More-Pages', '0', '0', '0', '0', '', '', '2010-08-09 22:06:58', '1');


-- --------------------------------------------------
# -- Table structure for table `posts`
-- --------------------------------------------------
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `show_title` tinyint(1) NOT NULL DEFAULT '1',
  `body` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `posts`
-- --------------------------------------------------

INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('1', '1', 'Welcome to Zazavi', '1', 'Welcome to Zazavi. The Lightweight CMS.&lt;br /&gt;\r\n&lt;br /&gt;\r\nCongratulation !! your installation of Zazavi&amp;nbsp; was successful.&lt;br /&gt;\r\n&lt;br /&gt;\r\nThis is the home page of your default installation of Zazavi.&lt;br /&gt;\r\nYou can edit or add content to your  Web site  from the administration panel of Zazavi by clicking the link below.&lt;br /&gt;\r\n&lt;a href=&quot;admin/index.php&quot; class=&quot;but&quot;&gt;&lt;span&gt;Administration panel&lt;/span&gt;&lt;/a&gt; &lt;hr /&gt;\r\n&lt;div class=&quot;col-31&quot;&gt;\r\n&lt;h3&gt;Who we are?&lt;/h3&gt;\r\n&lt;img width=&quot;290&quot; height=&quot;190&quot; alt=&quot;Who Are We?&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/demo_1.jpg&quot; class=&quot;image&quot; style=&quot;border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238); margin: 1px; padding: 5px; -moz-border-radius: 5px 5px 5px 5px;&quot; /&gt;\r\n&lt;p&gt;Nulla sollicitudin nulla mauris. Donec congue facilisis lorem, ornare tincidunt orci ullamcorper nec.&lt;/p&gt;\r\n&lt;p&gt;Nam pellentesque auctor turpis nec &lt;strong&gt;dapibus&lt;/strong&gt;. Vivamus interdum dignissim tincidunt. Vestibulum dapibus laoreet arcu, et pharetra augue ultricies quis.&lt;/p&gt;\r\n&lt;p&gt;Sed luctus condimentum mollis. Etiam lacus turpis, hendrerit vitae &lt;em&gt;feugiat&lt;/em&gt; sit amet, cursus ac quam. Curabitur metus mi.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;col-32&quot;&gt;\r\n&lt;h3&gt;What we do?&lt;/h3&gt;\r\n&lt;img width=&quot;290&quot; height=&quot;190&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/demo_2.jpg&quot; alt=&quot;What we do?&quot; style=&quot;border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238); margin: 1px; padding: 5px; -moz-border-radius: 5px 5px 5px 5px;&quot; /&gt;\r\n&lt;p&gt;Nulla sollicitudin nulla mauris. Donec congue facilisis lorem, ornare tincidunt orci ullamcorper nec.&lt;/p&gt;\r\n&lt;p&gt;Nam pellentesque auctor turpis nec &lt;strong&gt;dapibus&lt;/strong&gt;. Vivamus interdum dignissim tincidunt. Vestibulum dapibus laoreet arcu, et pharetra augue ultricies quis.&lt;/p&gt;\r\n&lt;p&gt;Sed luctus condimentum mollis. Etiam lacus turpis, hendrerit vitae &lt;em&gt;feugiat&lt;/em&gt; sit amet, cursus ac quam. Curabitur metus mi.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;col-33&quot;&gt;\r\n&lt;h3&gt;What is this?&lt;/h3&gt;\r\n&lt;img width=&quot;290&quot; height=&quot;190&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/demo_3.jpg&quot; alt=&quot;What Is This?&quot; style=&quot;border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238); margin: 1px; padding: 5px; -moz-border-radius: 5px 5px 5px 5px;&quot; /&gt;\r\n&lt;p&gt;Nulla sollicitudin nulla mauris. Donec congue facilisis lorem, ornare tincidunt orci ullamcorper nec.&lt;/p&gt;\r\n&lt;p&gt;Nam pellentesque auctor turpis nec &lt;strong&gt;dapibus&lt;/strong&gt;. Vivamus interdum dignissim tincidunt. Vestibulum dapibus laoreet arcu, et pharetra augue ultricies quis.&lt;/p&gt;\r\n&lt;p&gt;Sed luctus condimentum mollis. Etiam lacus turpis, hendrerit vitae &lt;em&gt;feugiat&lt;/em&gt; sit amet, cursus ac quam. Curabitur metus mi.&lt;/p&gt;\r\n&lt;/div&gt;\r\n&lt;div class=&quot;clear&quot;&gt;&amp;nbsp;&lt;/div&gt;', '1', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('2', '2', 'What is Zazavi', '1', '&lt;div style=&quot;text-align: center;&quot;&gt;&lt;img width=&quot;585&quot; height=&quot;230&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/sampleimage_4.jpg&quot; alt=&quot;sampleimage_4.jpg&quot; class=&quot;image&quot; /&gt;&lt;/div&gt;\r\n&lt;p&gt;Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam,  dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus  sit amet bibendum faucibus, nisi ligula ultricies purus, in malesuada  arcu sem ut mauris. Proin lobortis rutrum ultrices.&lt;/p&gt;\r\n&lt;h3&gt;Company Background&lt;/h3&gt;\r\n&lt;p&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut  dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed  feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla  facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit  commodo. Cum sociis natoque penatibus et magnis dis parturient montes,  nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit  justo, at mattis odio auctor quis. In hac habitasse platea dictumst.  Morbi ut turpis vitae risus egestas feugiat quis eget quam. Vivamus  vitae augue sed lacus placerat sollicitudin quis vel arcu. Vestibulum  auctor, magna sit amet pulvinar tristique, nunc felis viverra tortor,  venenatis convallis leo mauris eu massa. Integer aliquet libero sed  lorem consequat ut tempus libero viverra. Donec ut ipsum vitae leo  volutpat commodo.&lt;/p&gt;\r\n&lt;h3&gt;John Smith, CEO&lt;/h3&gt;\r\n&lt;a rel=&quot;prettyPhoto&quot; href=&quot;http://agda-graph/zazavipro/uploads/images/gallery/mygallery/MIL05006.JPG&quot;&gt;&lt;img width=&quot;116&quot; height=&quot;150&quot; class=&quot;/&quot; alt=&quot;Sample Image&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/blank_profile_image.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;&lt;/a&gt;\r\n&lt;p&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit commodo.&lt;/p&gt;\r\n&lt;p&gt;Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio auctor quis.&lt;/p&gt;\r\n&lt;p&gt;In hac habitasse platea dictumst.ivamus leo diam,  dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus  sit amet bibendum faucibus, nisi ligula ultricies purus&lt;/p&gt;', '1', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('3', '3', 'Contact Information', '1', '&lt;h3&gt;Where to Find Us&lt;/h3&gt;\r\n&lt;img width=&quot;150&quot; height=&quot;150&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/thumbs/thumb_contact-us.jpg&quot; alt=&quot;thumb_contact-us.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros  eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna  sit amet nibh. &lt;br /&gt;\r\n&lt;br /&gt;\r\nSuspendisse sed tortor nisi. Nulla facilisi. In sed  risus in est cursus ornare. Fusce tempor hendrerit commodo. Cum sociis  natoque penatibus et magnis dis parturient montes, nascetur ridiculus  mus. &lt;br /&gt;\r\n&lt;br /&gt;\r\nNam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio  auctor quis. In hac habitasse platea dictumst. Morbi ut turpis vitae  risus egestas feugiat quis eget quam. Vivamus vitae augue sed lacus  placerat sollicitudin quis vel arcu. &lt;br /&gt;\r\n&lt;br /&gt;\r\nVestibulum auctor, magna sit amet  pulvinar tristique, nunc felis viverra tortor, venenatis convallis leo  mauris eu massa. Integer aliquet libero sed lorem consequat ut tempus  libero viverra. Donec ut ipsum vitae leo volutpat commodo.', '1', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('4', '5', 'Gallery Demo', '1', '&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut  tempor eros. Proin bibendum, lacus vitae venenatis convallis, libero  ipsum imperdiet sem, ac consequat massa risus vel sem. Nunc nec ante non  arcu mattis viverra. Morbi accumsan, augue ac dignissim tempus, lacus  libero molestie est, in eleifend lorem purus eu mauris. Nulla at metus a  enim faucibus placerat vitae a justo. Maecenas rhoncus ante libero.&lt;/p&gt;', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('5', '6', 'Three Column Page', '1', '&lt;p&gt;&lt;img width=&quot;150&quot; height=&quot;58&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/thumbs/thumb_sampleimage_4.jpg&quot; alt=&quot;thumb_sampleimage_4.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed  ut tempor eros. Proin bibendum, lacus vitae venenatis convallis, libero  ipsum imperdiet sem, ac consequat massa risus vel sem. Nunc nec ante non  arcu mattis viverra. Morbi accumsan, augue ac dignissim tempus, lacus  libero molestie est, in eleifend lorem purus eu mauris. Nulla at metus a  enim faucibus placerat vitae a justo. Maecenas rhoncus ante libero.  Phasellus vitae porta nunc.&lt;/p&gt;\r\n&lt;form method=&quot;post&quot; action=&quot;https://www.paypal.com/cgi-bin/webscr&quot; target=&quot;_paypal&quot;&gt;\r\n    &lt;input type=&quot;hidden&quot; name=&quot;cmd&quot; value=&quot;_xclick&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;business&quot; value=&quot;asdfaf@sAZF.com&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;item_name&quot; value=&quot;Item Desc&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;item_number&quot; value=&quot;1&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;amount&quot; value=&quot;25&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;shipping&quot; value=&quot;0.00&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;tax_rate&quot; value=&quot;0.000&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;no_note&quot; value=&quot;1&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;currency_code&quot; value=&quot;CAD&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;lc&quot; value=&quot;US&quot; /&gt;&lt;input  type=&quot;image&quot; name=&quot;submit&quot; src=&quot;https://www.paypal.com/en_US/i/btn/x-click-but23.gif&quot; alt=&quot;Buy Now&quot; /&gt;\r\n&lt;/form&gt;', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('6', '7', 'All Module Positions', '1', '&lt;p&gt;&lt;img width=&quot;120&quot; height=&quot;150&quot; style=&quot;padding: 5px; margin-left: 15px; float: right; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; alt=&quot;thumb_TAH02017.JPG&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/thumbs/thumb_TAH02017.JPG&quot; /&gt;Aliquam vitae metus non elit laoreet varius. Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a.&lt;/p&gt;\r\n&lt;p&gt;Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere  cubilia Curae; Etiam a justo libero, aliquam auctor felis. Nulla a odio  ut magna ultrices vestibulum.&lt;/p&gt;\r\n&lt;p&gt;Integer urna magna, euismod sed pharetra  eget, ornare in dolor. Etiam bibendum mi ut nisi facilisis lobortis.  Phasellus turpis orci, interdum adipiscing aliquam ut, convallis  volutpat tellus. Nunc massa nunc, dapibus eget scelerisque ac, eleifend  eget ligula. Maecenas accumsan tortor in quam adipiscing hendrerit.  Donec ac risus nec est molestie malesuada ac id risus. In hac habitasse  platea dictumst. In quam dui, blandit id interdum id, facilisis a leo.&lt;/p&gt;\r\nNullam fringilla quam pharetra enim interdum accumsan. Phasellus nec  euismod quam. Donec tempor accumsan posuere. Phasellus ac metus orci, ac  venenatis magna. Suspendisse sit amet odio at enim ultricies  pellentesque eget ac risus. Vestibulum eleifend odio ut tellus faucibus  malesuada feugiat nisi rhoncus. Proin nec sem ut augue placerat blandit  ut ut orci. Cras aliquet venenatis enim, quis rutrum urna sollicitudin  vel.\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n&lt;hr /&gt;\r\n&lt;img width=&quot;150&quot; height=&quot;58&quot; alt=&quot;thumb_sampleimage_4.jpg&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/thumbs/thumb_sampleimage_4.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Aliquam vitae metus non elit laoreet varius. Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a. Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('9', '8', 'More Sample Pages', '1', '&lt;p&gt;Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere  cubilia Curae; Etiam a justo libero, aliquam auctor felis. Nulla a odio  ut magna ultrices vestibulum. Integer urna magna, euismod sed pharetra  eget, ornare in dolor. Etiam bibendum mi ut nisi facilisis lobortis.  Phasellus turpis orci, interdum adipiscing aliquam ut, convallis  volutpat tellus.&lt;/p&gt;\r\n&lt;div style=&quot;text-align: center;&quot;&gt;&lt;object width=&quot;640&quot; height=&quot;505&quot;&gt;\r\n&lt;param name=&quot;movie&quot; value=&quot;http://www.youtube.com/v/BYm_Mn7Hxag?fs=1&amp;amp;hl=en_US&amp;amp;color1=0x006699&amp;amp;color2=0x54abd6&quot; /&gt;\r\n&lt;param name=&quot;allowFullScreen&quot; value=&quot;true&quot; /&gt;\r\n&lt;param name=&quot;allowscriptaccess&quot; value=&quot;always&quot; /&gt;&lt;embed width=&quot;640&quot; height=&quot;505&quot; src=&quot;http://www.youtube.com/v/BYm_Mn7Hxag?fs=1&amp;amp;hl=en_US&amp;amp;color1=0x006699&amp;amp;color2=0x54abd6&quot; type=&quot;application/x-shockwave-flash&quot; allowscriptaccess=&quot;always&quot; allowfullscreen=&quot;true&quot;&gt;&lt;/embed&gt;&lt;/object&gt;&lt;/div&gt;\r\n&lt;hr /&gt;\r\n&lt;p&gt;Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a. Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.&lt;/p&gt;', '0', '1');


-- --------------------------------------------------
# -- Table structure for table `settings`
-- --------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `site_name` varchar(100) NOT NULL DEFAULT '',
  `company` varchar(100) NOT NULL DEFAULT '',
  `site_url` varchar(150) NOT NULL DEFAULT '',
  `site_email` varchar(50) NOT NULL DEFAULT '',
  `theme` varchar(32) NOT NULL DEFAULT '',
  `seo` tinyint(1) NOT NULL DEFAULT '0',
  `perpage` tinyint(4) NOT NULL DEFAULT '10',
  `backup` varchar(64) NOT NULL DEFAULT '',
  `thumb_w` varchar(5) NOT NULL DEFAULT '',
  `thumb_h` varchar(5) NOT NULL DEFAULT '',
  `short_date` varchar(50) NOT NULL,
  `long_date` varchar(50) NOT NULL,
  `offline` tinyint(1) NOT NULL DEFAULT '0',
  `logo` varchar(100) DEFAULT NULL,
  `metakeys` text,
  `metadesc` text,
  `analytics` text,
  `version` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `settings`
-- --------------------------------------------------

INSERT INTO `settings` (`site_name`, `company`, `site_url`, `site_email`, `theme`, `seo`, `perpage`, `backup`, `thumb_w`, `thumb_h`, `short_date`, `long_date`, `offline`, `logo`, `metakeys`, `metadesc`, `analytics`, `version`) VALUES ('Zazavi', 'Company Name', 'http://agda-graph/zazavipro', 'gewa@rogers.com', 'master', '1', '10', '16-Dec-2010_13-23-54.sql', '150', '150', '%d %b %Y', '%a %d, %M %Y', '0', 'logo.png', 'metakeys, separated,by coma', 'Your website description goes here', '', '1.50');


-- --------------------------------------------------
# -- Table structure for table `stats`
-- --------------------------------------------------
DROP TABLE IF EXISTS `stats`;
CREATE TABLE `stats` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `day` date NOT NULL DEFAULT '0000-00-00',
  `pageviews` int(10) NOT NULL DEFAULT '0',
  `uniquevisitors` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `stats`
-- --------------------------------------------------



-- --------------------------------------------------
# -- Table structure for table `users`
-- --------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(32) NOT NULL,
  `fname` varchar(32) NOT NULL,
  `lname` varchar(32) NOT NULL,
  `userlevel` tinyint(1) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `users`
-- --------------------------------------------------

INSERT INTO `users` (`id`, `username`, `password`, `email`, `fname`, `lname`, `userlevel`, `active`) VALUES ('1', 'admin', '42b7b504b2753b71f41780d5e86f1139a2ab5647', 'webmaster@mysite.com', 'Web', 'Master', '1', '1');


