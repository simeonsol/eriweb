-- --------------------------------------------------------------------------------
-- 
-- @version: zazavipro.sql May 27, 2011 22:00 gewa
-- @package Zazavi
-- @author zazavi.com.
-- @copyright 2010
-- 
-- --------------------------------------------------------------------------------
-- Host: localhost
-- Database: zazavipro
-- Time: May 27, 2011-22:00
-- MySQL version: 5.1.36-community-log
-- PHP version: 5.3.0
-- --------------------------------------------------------------------------------

#
# Database: `zazavipro`
#


-- --------------------------------------------------
# -- Table structure for table `email_templates`
-- --------------------------------------------------
DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE `email_templates` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `help` text,
  `body` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `email_templates`
-- --------------------------------------------------

INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('1', 'Registration Email', 'Please verify your email', 'This template is used to send Registration Verification Email, when Configuration->Registration Verification is set to YES', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;         &lt;hr /&gt;\n            The administrator of this site has requested all new accounts&lt;br /&gt;\n            to be activated by the users who created them thus your account&lt;br /&gt;\n            is currently inactive. To activate your account,&lt;br /&gt;\n            please visit the link below and enter the following:&lt;hr /&gt;\n            Token: &lt;strong&gt;[TOKEN]&lt;/strong&gt;&lt;br /&gt;\n            Email: &lt;strong&gt;[EMAIL]&lt;/strong&gt;         &lt;hr /&gt;\n            &lt;a href=&quot;[LINK]&quot;&gt;Click here to activate tour account&lt;/a&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('2', 'Forgot Password Email', 'Password Reset', 'This template is used for retrieving lost user password', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;New password reset from [SITE_NAME]!&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello, &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            It seems that you or someone requested a new password for you.&lt;br /&gt;\n            We have generated a new password, as requested:&lt;br /&gt;\n            &lt;br /&gt;\n            Your new password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            To use the new password you need to activate it. To do this click the link provided below and login with your new password.&lt;br /&gt;\n            &lt;a href=&quot;[LINK]&quot;&gt;[LINK]&lt;/a&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            You can change your password after you sign in.&lt;hr /&gt;\n            Password requested from IP: [IP]&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('3', 'Welcome Mail From Admin', 'You have been registered', 'This template is used to send welcome email, when user is added by administrator', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! You have been Registered.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('4', 'Default Newsletter', 'Newsletter', 'This is a default newsletter template', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello [NAME]!&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You are receiving this email as a part of your newsletter subscription.         &lt;hr /&gt;\n            Here goes your newsletter content         &lt;hr /&gt;\n            &lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;         &lt;hr /&gt;\n            &lt;span style=&quot;font-size: 11px;&quot;&gt;&lt;em&gt;To stop receiving future newsletters please login into your account         and uncheck newsletter subscription box.&lt;/em&gt;&lt;/span&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('5', 'Transaction Completed', 'Payment Completed', 'This template is used to notify administrator on successful payment transaction', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have received new payment following:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Membership: &lt;strong&gt;[ITEMNAME]&lt;/strong&gt;&lt;br /&gt;\n            Price: &lt;strong&gt;[PRICE]&lt;/strong&gt;&lt;br /&gt;\n            Status: &lt;strong&gt;[STATUS] &lt;/strong&gt;&lt;br /&gt;\r\n            Processor: &lt;strong&gt;[PP] &lt;/strong&gt;&lt;br /&gt;\n            IP: &lt;strong&gt;[IP] &lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;&lt;em&gt;You can view this transaction from your admin panel&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('6', 'Transaction Suspicious', 'Suspicious Transaction', 'This template is used to notify administrator on failed/suspicious payment transaction', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color:#ccc&quot;&gt;Hello, Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align:left&quot;&gt;The following transaction has been disabled due to suspicious activity:&lt;br /&gt;\n            &lt;br /&gt;\n            Buyer: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Item: &lt;strong&gt;[ITEM]&lt;/strong&gt;&lt;br /&gt;\n            Price: &lt;strong&gt;[PRICE]&lt;/strong&gt;&lt;br /&gt;\n            Status: &lt;strong&gt;[STATUS]&lt;/strong&gt;&lt;/td&gt;\r\n            Processor: &lt;strong&gt;[PP] &lt;/strong&gt;&lt;br /&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align:left&quot;&gt;&lt;em&gt;Please verify this transaction is correct. If it is, please activate it in the transaction section of your site&#039;s &lt;br /&gt;\n            administration control panel. If not, it appears that someone tried to fraudulently obtain products from your site.&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('7', 'Welcome Email', 'Welcome', 'This template is used to welcome newly registered user when Configuration->Registration Verification and Configuration->Auto Registration are both set to YES', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('8', 'Membership Expire 7 days', 'Your membership will expire in 7 days', 'This template is used to remind user that membership will expire in 7 days', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, [NAME]&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;\n            &lt;h2 style=&quot;color: rgb(255, 0, 0);&quot;&gt;Your current membership will expire in 7 days&lt;/h2&gt;\n            Please login to your user panel to extend or upgrade your membership.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('9', 'Membership expired today', 'Your membership has expired', 'This template is used to remind user that membership had expired', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, [NAME]&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;\n            &lt;h2 style=&quot;color: rgb(255, 0, 0);&quot;&gt;Your current membership has expired!&lt;/h2&gt;\n            Please login to your user panel to extend or upgrade your membership.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('10', 'Contact Request', 'Contact Inquiry', 'This template is used to send default Contact Request Form', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new contact request:         &lt;hr /&gt;\n            [MESSAGE]         &lt;hr /&gt;\n            From: &lt;strong&gt;[SENDER] - [NAME]&lt;/strong&gt;&lt;br /&gt;\n            Subject: &lt;strong&gt;[MAILSUBJECT]&lt;/strong&gt;&lt;br /&gt;\n            Senders IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('11', 'New Comment', 'New Comment Added', 'This template is used to notify admin when new comment has been added', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new comment post. You can login into your admin panel to view details:         &lt;hr /&gt;\n            [MESSAGE]         &lt;hr /&gt;\n            From: &lt;strong&gt;[SENDER] - [NAME]&lt;/strong&gt;&lt;br /&gt;\n            www: &lt;strong&gt;[WWW]&lt;/strong&gt;&lt;br /&gt;\n            Page Url: &lt;strong&gt;&lt;a href=&quot;[PAGEURL]&quot;&gt;[PAGEURL]&lt;/a&gt;&lt;/strong&gt;&lt;br /&gt;\n            Senders IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('12', 'Single Email', 'Single User Email', 'This template is used to email single user', '&lt;div align=&quot;center&quot;&gt;\n  &lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n      &lt;tr&gt;\n        &lt;th style=&quot;background-color:#ccc&quot;&gt;Hello [NAME]&lt;/th&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td valign=&quot;top&quot; style=&quot;text-align:left&quot;&gt;Your message goes here...&lt;/td&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td style=&quot;text-align:left&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n          [SITE_NAME] Team&lt;br /&gt;\n          &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n      &lt;/tr&gt;\n    &lt;/tbody&gt;\n  &lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('13', 'Notify Admin', 'New User Registration', 'This template is used to notify admin of new registration when Configuration->Registration Notification is set to YES', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new user registration. You can login into your admin panel to view details:&lt;hr /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Name: &lt;strong&gt;[NAME]&lt;/strong&gt;&lt;br /&gt;\n            IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `subject`, `help`, `body`) VALUES ('14', 'Registration Pending', 'Registration Verification Pending', 'This template is used to send Registration Verification Email, when Configuration->Auto Registration is set to NO', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;         &lt;hr /&gt;\n            The administrator of this site has requested all new accounts&lt;br /&gt;\n            to be activated by the users who created them thus your account&lt;br /&gt;\n            is currently pending verification process.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');


-- --------------------------------------------------
# -- Table structure for table `gallery`
-- --------------------------------------------------
DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `folder` varchar(30) DEFAULT NULL,
  `rows` int(4) NOT NULL DEFAULT '0',
  `thumb_w` int(4) NOT NULL DEFAULT '0',
  `thumb_h` int(4) NOT NULL DEFAULT '0',
  `image_w` int(4) NOT NULL DEFAULT '0',
  `image_h` int(4) NOT NULL DEFAULT '0',
  `watermark` tinyint(1) NOT NULL DEFAULT '0',
  `method` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `gallery`
-- --------------------------------------------------

INSERT INTO `gallery` (`id`, `title`, `folder`, `rows`, `thumb_w`, `thumb_h`, `image_w`, `image_h`, `watermark`, `method`, `created`) VALUES ('1', 'Demo Gallery', 'demo', '5', '150', '150', '600', '600', '1', '1', '2010-12-10 12:10:10');


-- --------------------------------------------------
# -- Table structure for table `gallery_images`
-- --------------------------------------------------
DROP TABLE IF EXISTS `gallery_images`;
CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_id` int(6) NOT NULL DEFAULT '0',
  `title` varchar(100) DEFAULT NULL,
  `desc` varchar(250) DEFAULT NULL,
  `thumb` varchar(100) DEFAULT NULL,
  `sorting` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `gallery_images`
-- --------------------------------------------------

INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('1', '1', 'Demo Flower 1', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_318C0B-0F1A63-7096C7-45B182-87004D-FDF0AE.jpg', '1');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('2', '1', 'Demo Flower 2', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_D45A84-11B3CB-E2E617-8CE590-EB95CB-4C40CF.jpg', '2');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('3', '1', 'Demo Flower 3', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_07264C-30F255-F8E444-C90DC8-093AE6-C83DF4.jpg', '3');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('4', '1', 'Demo Flower 4', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_2822AC-941D16-C5ECEB-4C2787-015575-77FEE8.jpg', '4');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('5', '1', 'Demo Flower 5', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_260FA3-1C8BE1-890AFD-8F20ED-47EB05-EBDFF7.jpg', '5');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('6', '1', 'Demo Flower 6', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_755459-EC4B6C-58E134-2907AA-36BFEC-2604A5.jpg', '6');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('7', '1', 'Demo Flower 7', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_7810C6-0B129B-B97C0D-902867-748A5F-854706.jpg', '8');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('8', '1', 'Demo Flower 8', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_901142-405DB2-4B327C-6418D7-B92E53-CC1FA7.jpg', '9');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('9', '1', 'Demo Flower 9', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_F87715-1EAFB8-D4E516-77E233-215B0A-507EBB.jpg', '10');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('10', '1', 'Demo Flower 10', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_0D08C0-3FFF26-A5D741-BA76C6-F3C61F-D67093.jpg', '11');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('11', '1', 'Demo Flower 11', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_807CA0-B0AB7C-FF9BB6-E4E678-B9A38A-7A81FB.jpg', '12');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('12', '1', 'Demo Flower 12', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_7CF0A7-55F94C-0B0AE0-A4BF0C-476BF7-82CCE0.jpg', '13');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('13', '1', 'Demo Flower 13', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_E1A872-9BDEED-5CA577-3CA6F1-E2545B-DBCF15.jpg', '14');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('14', '1', 'Demo Flower 14', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_2D4A9D-9D3E9E-047D5A-49CC85-4B02A6-1F3BB6.jpg', '15');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('15', '1', 'Demo Flower 15', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_886FAF-5199A3-9758FB-406A40-59CDF0-C5C3C9.jpg', '7');


-- --------------------------------------------------
# -- Table structure for table `gateways`
-- --------------------------------------------------
DROP TABLE IF EXISTS `gateways`;
CREATE TABLE `gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `displayname` varchar(255) NOT NULL,
  `dir` varchar(255) NOT NULL,
  `demo` tinyint(1) NOT NULL DEFAULT '1',
  `extra_txt` varchar(255) NOT NULL,
  `extra_txt2` varchar(255) NOT NULL,
  `extra_txt3` varchar(255) DEFAULT NULL,
  `extra` varchar(255) NOT NULL,
  `extra2` varchar(255) NOT NULL,
  `extra3` varchar(255) DEFAULT NULL,
  `is_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `gateways`
-- --------------------------------------------------

INSERT INTO `gateways` (`id`, `name`, `displayname`, `dir`, `demo`, `extra_txt`, `extra_txt2`, `extra_txt3`, `extra`, `extra2`, `extra3`, `is_recurring`, `active`) VALUES ('1', 'paypal', 'PayPal', 'paypal', '0', 'Email Address', 'Currency Code', 'Not in Use', 'paypal@address.com', 'CAD', '', '1', '1');
INSERT INTO `gateways` (`id`, `name`, `displayname`, `dir`, `demo`, `extra_txt`, `extra_txt2`, `extra_txt3`, `extra`, `extra2`, `extra3`, `is_recurring`, `active`) VALUES ('2', 'moneybookers', 'MoneyBookers', 'moneybookers', '1', 'Email Address', 'Currency Code', 'Secret Passphrase', 'moneybookers@address.com', 'EUR', 'mypassphrase', '1', '1');


-- --------------------------------------------------
# -- Table structure for table `language`
-- --------------------------------------------------
DROP TABLE IF EXISTS `language`;
CREATE TABLE `language` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `flag` varchar(2) DEFAULT NULL,
  `author` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `language`
-- --------------------------------------------------

INSERT INTO `language` (`id`, `name`, `flag`, `author`) VALUES ('1', 'English', 'en', 'http://www.zazavi.com');
INSERT INTO `language` (`id`, `name`, `flag`, `author`) VALUES ('2', 'German', 'de', 'http://www.zazavi.com');
INSERT INTO `language` (`id`, `name`, `flag`, `author`) VALUES ('3', 'Serbian', 'rs', 'http://www.zazavi.com');


-- --------------------------------------------------
# -- Table structure for table `layout`
-- --------------------------------------------------
DROP TABLE IF EXISTS `layout`;
CREATE TABLE `layout` (
  `module_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL,
  `place` varchar(20) NOT NULL,
  `position` int(11) NOT NULL,
  KEY `idx_layout_id` (`page_id`),
  KEY `idx_plugin_id` (`module_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `layout`
-- --------------------------------------------------

INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '6', 'left', '5');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('9', '1', 'bottom', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('10', '1', 'bottom', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '2', 'right', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('1', '2', 'right', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '3', 'left', '15');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('14', '3', 'left', '14');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('8', '6', 'right', '8');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('9', '6', 'left', '7');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('11', '6', 'bottom', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('10', '6', 'bottom', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('3', '7', 'left', '7');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('5', '7', 'bottom', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('9', '7', 'left', '5');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('8', '7', 'right', '8');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('4', '7', 'left', '6');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('10', '7', 'bottom', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('1', '7', 'top', '3');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('11', '7', 'top', '4');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('6', '1', 'top', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('4', '6', 'left', '6');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('11', '1', 'bottom', '8');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('1', '8', 'right', '8');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('4', '8', 'right', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '8', 'right', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('13', '2', 'right', '11');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('7', '6', 'top', '6');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('12', '3', 'left', '16');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('16', '5', 'bottom', '15');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('18', '3', 'left', '13');


-- --------------------------------------------------
# -- Table structure for table `log`
-- --------------------------------------------------
DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed` tinyint(5) NOT NULL,
  `failed_last` int(11) NOT NULL,
  `type` enum('system','admin','user') NOT NULL,
  `message` text NOT NULL,
  `info_icon` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `importance` enum('yes','no') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `log`
-- --------------------------------------------------

INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('1', 'admin', '127.0.0.1', '2011-05-07 14:57:19', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('2', 'admin', '127.0.0.1', '2011-05-07 17:15:09', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('3', 'admin', '127.0.0.1', '2011-05-07 17:29:06', '0', '0', 'system', '<span>Success!</span>Comments Configuration updated successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('4', 'admin', '127.0.0.1', '2011-05-07 17:50:09', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('5', 'admin', '127.0.0.1', '2011-05-07 17:55:40', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('6', 'admin', '127.0.0.1', '2011-05-07 21:14:05', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('7', 'admin', '127.0.0.1', '2011-05-07 21:53:25', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('8', 'admin', '127.0.0.1', '2011-05-07 21:53:27', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('9', 'admin', '127.0.0.1', '2011-05-08 10:09:12', '0', '0', 'system', '<span>Success!</span>Email Template Updated Successfuly', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('10', 'admin', '127.0.0.1', '2011-05-08 10:18:31', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('11', 'admin', '127.0.0.1', '2011-05-08 12:09:58', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('12', 'admin', '127.0.0.1', '2011-05-08 12:10:02', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('13', 'admin', '127.0.0.1', '2011-05-08 20:10:43', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('14', 'admin', '127.0.0.1', '2011-05-08 21:19:33', '0', '0', 'system', '<span>Success!</span>Email Template Updated Successfuly', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('15', 'admin', '127.0.0.1', '2011-05-09 13:05:10', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('16', 'admin', '127.0.0.1', '2011-05-09 14:18:57', '0', '0', 'user', 'User  has successfully updated profile.', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('17', 'admin', '127.0.0.1', '2011-05-09 14:20:53', '0', '0', 'user', 'User admin has successfully updated profile.', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('18', 'admin', '127.0.0.1', '2011-05-09 14:21:02', '0', '0', 'user', 'User admin has successfully updated profile.', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('19', 'admin', '127.0.0.1', '2011-05-09 14:21:22', '0', '0', 'user', 'User admin has successfully updated profile.', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('20', 'admin', '127.0.0.1', '2011-05-09 14:21:31', '0', '0', 'user', 'User admin has successfully updated profile.', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('21', 'admin', '127.0.0.1', '2011-05-09 14:24:19', '0', '0', 'user', 'User admin has successfully updated profile.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('22', 'admin', '127.0.0.1', '2011-05-09 14:24:54', '0', '0', 'user', 'User admin has successfully updated profile.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('23', 'admin', '127.0.0.1', '2011-05-09 16:05:27', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('24', 'Guest', '127.0.0.1', '2011-05-09 16:48:11', '0', '0', 'user', 'User admin has has requested password reset.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('25', 'admin', '127.0.0.1', '2011-05-09 17:59:40', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('26', 'admin', '127.0.0.1', '2011-05-09 19:02:19', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('27', 'admin', '127.0.0.1', '2011-05-09 19:02:29', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('28', 'admin', '127.0.0.1', '2011-05-09 19:02:32', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('29', 'admin', '127.0.0.1', '2011-05-09 19:41:03', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('30', 'admin', '127.0.0.1', '2011-05-09 19:44:59', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('31', 'admin', '127.0.0.1', '2011-05-09 19:49:10', '0', '0', 'system', '<span>Success!</span>Email Template Updated Successfuly', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('32', 'admin', '127.0.0.1', '2011-05-09 19:51:55', '0', '0', 'system', '<span>Success!</span>Email Template Updated Successfuly', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('33', 'admin', '127.0.0.1', '2011-05-09 20:05:23', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('34', 'admin', '127.0.0.1', '2011-05-09 22:06:07', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('35', 'admin', '127.0.0.1', '2011-05-09 22:07:00', '0', '0', 'system', '<span>Success!</span>Email Template Updated Successfuly', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('36', 'admin', '127.0.0.1', '2011-05-09 22:07:12', '0', '0', 'system', '<span>Success!</span>Email Template Updated Successfuly', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('37', 'admin', '127.0.0.1', '2011-05-09 22:07:29', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('38', 'Guest', '127.0.0.1', '2011-05-09 22:08:46', '0', '0', 'user', 'User Gregavac has successfully registered.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('39', 'admin', '127.0.0.1', '2011-05-10 11:05:14', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('40', 'admin', '127.0.0.1', '2011-05-10 11:08:39', '0', '0', 'system', '<span>Success!</span>Email Template Updated Successfuly', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('41', 'admin', '127.0.0.1', '2011-05-10 11:12:27', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('42', 'admin', '127.0.0.1', '2011-05-10 12:20:54', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('43', 'admin', '127.0.0.1', '2011-05-10 14:50:41', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('44', 'admin', '127.0.0.1', '2011-05-11 15:57:08', '0', '0', 'system', '<span>Success!</span>Membership updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('45', 'admin', '127.0.0.1', '2011-05-11 15:57:17', '0', '0', 'system', '<span>Success!</span>Membership updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('46', 'admin', '127.0.0.1', '2011-05-11 15:57:24', '0', '0', 'system', '<span>Success!</span>Membership updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('47', 'admin', '127.0.0.1', '2011-05-11 15:59:39', '0', '0', 'system', '<span>Success!</span>Membership updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('48', 'admin', '127.0.0.1', '2011-05-11 15:59:54', '0', '0', 'system', '<span>Success!</span>Membership updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('49', 'admin', '127.0.0.1', '2011-05-11 16:08:09', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('50', 'admin', '127.0.0.1', '2011-05-13 10:42:04', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('51', 'admin', '127.0.0.1', '2011-05-13 10:42:29', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('52', 'admin', '127.0.0.1', '2011-05-13 12:30:22', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('53', 'admin', '127.0.0.1', '2011-05-14 10:20:12', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('54', '', '127.0.0.1', '2011-05-14 23:06:40', '0', '0', 'user', 'User  has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('55', '', '127.0.0.1', '2011-05-14 23:07:03', '0', '0', 'user', 'User  has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('56', 'admin', '127.0.0.1', '2011-05-15 15:11:00', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('57', 'admin', '127.0.0.1', '2011-05-15 21:08:40', '0', '0', 'system', '<span>Success!</span>Membership updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('58', 'admin', '127.0.0.1', '2011-05-15 21:08:48', '0', '0', 'system', '<span>Success!</span>Membership updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('59', 'admin', '127.0.0.1', '2011-05-16 12:25:11', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('60', 'admin', '127.0.0.1', '2011-05-16 12:25:19', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('61', 'admin', '127.0.0.1', '2011-05-16 12:27:26', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('62', 'admin', '127.0.0.1', '2011-05-16 12:56:07', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('63', 'admin', '127.0.0.1', '2011-05-16 13:00:39', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('64', 'admin', '127.0.0.1', '2011-05-16 14:13:24', '0', '0', 'system', '<span>Success!</span>Backup created successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('65', 'admin', '127.0.0.1', '2011-05-16 14:30:50', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('66', 'admin', '127.0.0.1', '2011-05-17 11:15:36', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('67', 'admin', '127.0.0.1', '2011-05-19 15:26:41', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('68', 'admin', '127.0.0.1', '2011-05-19 15:28:29', '0', '0', 'system', '<span>Success!</span>Content Page added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('69', 'admin', '127.0.0.1', '2011-05-19 15:28:48', '0', '0', 'system', '<span>Success!</span>Content Page added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('70', 'admin', '127.0.0.1', '2011-05-19 15:29:39', '0', '0', 'system', '<span>Success!</span>Content Post added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('71', 'admin', '127.0.0.1', '2011-05-19 15:30:06', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('72', 'admin', '127.0.0.1', '2011-05-19 15:31:01', '0', '0', 'system', '<span>Success!</span>Content Post added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('73', 'admin', '127.0.0.1', '2011-05-19 15:31:31', '0', '0', 'system', '<span>Success!</span>Menu added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('74', 'admin', '127.0.0.1', '2011-05-19 15:31:41', '0', '0', 'system', '<span>Success!</span>Menu added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('75', 'admin', '127.0.0.1', '2011-05-19 15:32:41', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('76', 'admin', '127.0.0.1', '2011-05-19 16:49:00', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('77', 'admin', '127.0.0.1', '2011-05-21 00:50:34', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('78', 'admin', '127.0.0.1', '2011-05-25 12:53:05', '0', '0', 'system', 'Image <strong>Img Title</strong> deleted successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('79', 'admin', '127.0.0.1', '2011-05-25 13:07:00', '0', '0', 'system', '<span>Success!</span>Backup deleted successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('80', 'admin', '127.0.0.1', '2011-05-25 13:07:05', '0', '0', 'system', '<span>Success!</span>Backup deleted successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('81', 'admin', '127.0.0.1', '2011-05-25 13:35:17', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('82', 'admin', '127.0.0.1', '2011-05-25 21:40:04', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('83', 'admin', '127.0.0.1', '2011-05-25 21:59:14', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('84', 'admin', '127.0.0.1', '2011-05-25 22:01:48', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('85', 'admin', '127.0.0.1', '2011-05-26 13:52:33', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('86', 'admin', '127.0.0.1', '2011-05-26 13:54:50', '0', '0', 'system', '<span>Success!</span>Twitter settings updated successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('87', 'admin', '127.0.0.1', '2011-05-26 13:54:52', '0', '0', 'system', '<span>Success!</span>Twitter settings updated successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('88', 'admin', '127.0.0.1', '2011-05-26 18:32:14', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('89', 'admin', '127.0.0.1', '2011-05-26 18:32:56', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('90', 'admin', '127.0.0.1', '2011-05-27 11:31:43', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('91', 'admin', '127.0.0.1', '2011-05-27 11:33:01', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');


-- --------------------------------------------------
# -- Table structure for table `memberships`
-- --------------------------------------------------
DROP TABLE IF EXISTS `memberships`;
CREATE TABLE `memberships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` float(10,2) NOT NULL DEFAULT '0.00',
  `days` int(5) NOT NULL DEFAULT '0',
  `period` varchar(1) NOT NULL DEFAULT 'D',
  `trial` tinyint(1) NOT NULL DEFAULT '0',
  `recurring` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `memberships`
-- --------------------------------------------------

INSERT INTO `memberships` (`id`, `title`, `description`, `price`, `days`, `period`, `trial`, `recurring`, `active`) VALUES ('1', 'Trial 7', 'This is 7 days trial membership...', '0.00', '7', 'D', '1', '0', '1');
INSERT INTO `memberships` (`id`, `title`, `description`, `price`, `days`, `period`, `trial`, `recurring`, `active`) VALUES ('2', 'Basic 30', 'This is 30 days basic membership', '2.99', '1', 'M', '0', '0', '1');
INSERT INTO `memberships` (`id`, `title`, `description`, `price`, `days`, `period`, `trial`, `recurring`, `active`) VALUES ('3', 'Basic 90', 'This is 90 days basic membership', '6.99', '90', 'D', '0', '0', '1');
INSERT INTO `memberships` (`id`, `title`, `description`, `price`, `days`, `period`, `trial`, `recurring`, `active`) VALUES ('4', 'Platinum Subscription', 'Platinum Monthly Subscription.', '49.99', '1', 'Y', '0', '1', '1');
INSERT INTO `memberships` (`id`, `title`, `description`, `price`, `days`, `period`, `trial`, `recurring`, `active`) VALUES ('5', 'Weekly Access', 'This is 7 days basic membership', '1.99', '1', 'W', '0', '0', '1');


-- --------------------------------------------------
# -- Table structure for table `menus`
-- --------------------------------------------------
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `content_type` varchar(20) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `target` enum('_self','_blank') NOT NULL DEFAULT '_blank',
  `position` int(11) NOT NULL DEFAULT '0',
  `home_page` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `content_id` (`active`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `menus`
-- --------------------------------------------------

INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('1', '0', '3', 'Contact Us', 'Contact-Us', 'page', '', '_blank', '11', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('2', '0', '1', 'Home', 'Home', 'page', '', '', '1', '1', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('3', '0', '7', 'All Modules', 'All-Modules', 'page', '', '_blank', '2', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('4', '0', '6', 'Three Columns', 'Three-Columns', 'page', '', '_blank', '3', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('5', '0', '5', 'Full Width Page', 'Full-Width-Page', 'page', '', '_blank', '8', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('6', '0', '0', 'External Link', 'External-Link', 'web', 'http://www.google.com', '_blank', '9', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('7', '0', '8', 'Sample Submenus', 'Sample-Submenus', 'page', '', '_blank', '4', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('8', '7', '6', 'New Submenu 1', 'New-Submenu-1', 'page', '', '_blank', '5', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('9', '7', '7', 'New Submenu 2', 'New-Submenu-2', 'page', '', '_blank', '6', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('10', '9', '3', 'New Submenu 3', 'New-Submenu-3', 'page', '', '_blank', '7', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('11', '0', '2', 'About Us', 'About-Us', 'page', '', '_blank', '10', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('17', '11', '9', 'Members Only', 'Members-Only', 'page', '', '', '0', '0', '1');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('18', '11', '10', 'Membership Only', 'Membership-Only', 'page', '', '', '0', '0', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_comments`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_comments`;
CREATE TABLE `mod_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `username` varchar(24) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `body` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `www` varchar(220) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip` varchar(16) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent` (`parent_id`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_comments`
-- --------------------------------------------------

INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('1', '0', '2', 'Webmaster', 'webmaster@zazavi.com', 'First comment is on me.', 'http://www.zazavi.com', '2011-01-30 16:34:55', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('2', '3', '2', 'Admin', 'admin@mail.com', '<pre>Cum sociis natoque penatibus et <strong>magnis dis parturient</strong> montes, </pre>nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio auctor quis.', '', '2011-01-31 08:40:42', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('3', '5', '2', 'User1', 'user1@mail.com', 'Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed risus in est cursus ornare.', '', '2011-01-31 08:45:54', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('4', '0', '2', 'User2', 'user2@mail.com', 'Etiam non lacus ac velit <em>lobortis rutrum sed</em> id turpis. <code>Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris,</code>sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit commodo.', '', '2011-01-31 08:48:26', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('5', '0', '2', 'User3', 'user3@mail.com', 'In hac habit***e platea dictumst.ivamus leo diam, dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus sit amet bibendum faucibus, nisi ligula ultricies purus', '', '2011-01-31 08:51:25', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('6', '0', '2', 'User4', 'user4@mail.com', 'Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam, dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus sit amet bibendum faucibus, nisi ligula ultricies purus, in malesuada arcu sem ut mauris. Proin lobortis rutrum ultrices.', '', '2011-01-31 08:53:51', '127.0.0.1', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_comments_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_comments_config`;
CREATE TABLE `mod_comments_config` (
  `username_req` tinyint(1) NOT NULL DEFAULT '0',
  `email_req` tinyint(1) NOT NULL DEFAULT '0',
  `show_captcha` tinyint(1) NOT NULL DEFAULT '1',
  `show_www` tinyint(1) NOT NULL DEFAULT '0',
  `show_username` tinyint(1) DEFAULT '1',
  `show_email` tinyint(1) DEFAULT '1',
  `auto_approve` tinyint(1) NOT NULL DEFAULT '0',
  `notify_new` tinyint(1) NOT NULL DEFAULT '0',
  `public_access` tinyint(1) NOT NULL DEFAULT '0',
  `sorting` varchar(4) NOT NULL DEFAULT 'DESC',
  `blacklist_words` text,
  `char_limit` varchar(6) NOT NULL DEFAULT '400',
  `perpage` varchar(3) NOT NULL DEFAULT '10',
  `dateformat` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_comments_config`
-- --------------------------------------------------

INSERT INTO `mod_comments_config` (`username_req`, `email_req`, `show_captcha`, `show_www`, `show_username`, `show_email`, `auto_approve`, `notify_new`, `public_access`, `sorting`, `blacklist_words`, `char_limit`, `perpage`, `dateformat`) VALUES ('1', '1', '1', '1', '1', '0', '0', '0', '1', 'DESC', 'arse\narses\nass\nasses\nbollocks\ncrap', '400', '5', '%d %M %Y %H:%i');


-- --------------------------------------------------
# -- Table structure for table `mod_events`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_events`;
CREATE TABLE `mod_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `venue` varchar(150) NOT NULL,
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00',
  `time_start` time NOT NULL DEFAULT '00:00:00',
  `time_end` time NOT NULL DEFAULT '00:00:00',
  `body` text NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `contact_email` varchar(80) NOT NULL,
  `contact_phone` varchar(16) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_events`
-- --------------------------------------------------

INSERT INTO `mod_events` (`id`, `title`, `venue`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('1', 'Free Coffee for Each Monday', 'Office Rental Showroom', '2010-12-08', '2010-12-31', '11:18:00', '21:00:00', 'Vestibulum dictum elit eu risus porta egestas. Sed quis enim neque, sed  fringilla erat. Nunc feugiat tortor eu sem consequat aliquam. Cras non  nibh at lorem auctor interdum. Donec ut lacinia massa.', 'John Doe', 'john@gmail.com', '555-555-5555', '1');
INSERT INTO `mod_events` (`id`, `title`, `venue`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('2', 'Lucky Draw', 'Office Rental Showroom', '2010-12-21', '2010-12-31', '13:30:00', '11:00:00', '&lt;p&gt;&lt;img width=&quot;150&quot; height=&quot;98&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/thumbs/thumb_demo_1.jpg&quot; alt=&quot;thumb_demo_1.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Pellentesque habitant morbi tristique senectus et netus et malesuada  fames ac turpis egestas. Nulla posuere nibh auctor urna tincidunt  fringilla. &lt;br /&gt;\r\nDonec imperdiet, orci quis aliquet laoreet, magna purus semper ligula,  sit amet aliquam sapien enim in orci. Pellentesque at iaculis nibh.&lt;/p&gt;', 'John Doe', 'john@gmail.com', '555-555-5555', '1');
INSERT INTO `mod_events` (`id`, `title`, `venue`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('3', 'E-Commerce Seminar', 'Office Rental Showroom', '2011-01-19', '2011-01-19', '09:30:00', '13:30:00', 'Proin nec nisl est, id ornare lacus. Etiam mauris neque, scelerisque ut  ultrices vel, blandit et nisi. Nam commodo fermentum lectus vulputate  auctor. Maecenas hendrerit sapien sit amet erat mollis venenatis nec sit', 'John Doe', 'john@gmail.com', '555-555-5555', '1');
INSERT INTO `mod_events` (`id`, `title`, `venue`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('4', 'E-Commerce Seminar II', 'Office Rental Showroom', '2011-01-19', '2011-01-19', '17:00:00', '19:00:00', 'Aliquam auctor molestie ipsum ultricies tincidunt. Suspendisse potenti.  Nulla volutpat urna et mi consectetur placerat iaculis lacus lacinia.  Integer a nisi id diam tempus commodo eget a tellus. In consequat augue  nec tortor bibendum vel semper metus sodales. Donec ut dui nisi, id  posuere augue.', 'John Doe', 'john@gmail.com', '555-555-5555', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_gallery_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_gallery_config`;
CREATE TABLE `mod_gallery_config` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `folder` varchar(30) DEFAULT NULL,
  `rows` int(4) NOT NULL DEFAULT '0',
  `thumb_w` int(4) NOT NULL DEFAULT '0',
  `thumb_h` int(4) NOT NULL DEFAULT '0',
  `image_w` int(4) NOT NULL DEFAULT '0',
  `image_h` int(4) NOT NULL DEFAULT '0',
  `watermark` tinyint(1) NOT NULL DEFAULT '0',
  `method` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_gallery_config`
-- --------------------------------------------------

INSERT INTO `mod_gallery_config` (`id`, `title`, `folder`, `rows`, `thumb_w`, `thumb_h`, `image_w`, `image_h`, `watermark`, `method`, `created`) VALUES ('1', 'Demo Gallery', 'demo', '5', '150', '150', '600', '600', '1', '1', '2010-12-10 12:10:10');


-- --------------------------------------------------
# -- Table structure for table `mod_gallery_images`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_gallery_images`;
CREATE TABLE `mod_gallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_id` int(6) NOT NULL DEFAULT '0',
  `title` varchar(100) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `thumb` varchar(100) DEFAULT NULL,
  `sorting` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_gallery_images`
-- --------------------------------------------------

INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('1', '1', 'Demo Flower 1', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_318C0B-0F1A63-7096C7-45B182-87004D-FDF0AE.jpg', '2');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('2', '1', 'Demo Flower 2', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_D45A84-11B3CB-E2E617-8CE590-EB95CB-4C40CF.jpg', '3');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('3', '1', 'Demo Flower 3', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_07264C-30F255-F8E444-C90DC8-093AE6-C83DF4.jpg', '4');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('4', '1', 'Demo Flower 4', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_2822AC-941D16-C5ECEB-4C2787-015575-77FEE8.jpg', '5');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('5', '1', 'Demo Flower 5', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_260FA3-1C8BE1-890AFD-8F20ED-47EB05-EBDFF7.jpg', '6');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('6', '1', 'Demo Flower 6', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_755459-EC4B6C-58E134-2907AA-36BFEC-2604A5.jpg', '7');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('7', '1', 'Demo Flower 7', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_7810C6-0B129B-B97C0D-902867-748A5F-854706.jpg', '9');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('8', '1', 'Demo Flower 8', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_901142-405DB2-4B327C-6418D7-B92E53-CC1FA7.jpg', '10');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('9', '1', 'Demo Flower 9', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_F87715-1EAFB8-D4E516-77E233-215B0A-507EBB.jpg', '11');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('10', '1', 'Demo Flower 10', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_0D08C0-3FFF26-A5D741-BA76C6-F3C61F-D67093.jpg', '12');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('11', '1', 'Demo Flower 11', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_807CA0-B0AB7C-FF9BB6-E4E678-B9A38A-7A81FB.jpg', '13');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('12', '1', 'Demo Flower 12', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_7CF0A7-55F94C-0B0AE0-A4BF0C-476BF7-82CCE0.jpg', '14');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('13', '1', 'Demo Flower 13', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_E1A872-9BDEED-5CA577-3CA6F1-E2545B-DBCF15.jpg', '15');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('14', '1', 'Demo Flower 14', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_2D4A9D-9D3E9E-047D5A-49CC85-4B02A6-1F3BB6.jpg', '1');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `description`, `thumb`, `sorting`) VALUES ('15', '1', 'Demo Flower 15', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_886FAF-5199A3-9758FB-406A40-59CDF0-C5C3C9.jpg', '8');


-- --------------------------------------------------
# -- Table structure for table `mod_newsslider`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_newsslider`;
CREATE TABLE `mod_newsslider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) DEFAULT NULL,
  `body` text,
  `show_title` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  `show_created` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_newsslider`
-- --------------------------------------------------

INSERT INTO `mod_newsslider` (`id`, `title`, `body`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('1', 'Etiam non lacus', 'Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam, dignissim  eu convallis in, posuere quis magna. Curabitur mollis, lectus sit amet  bibendum faucibus, nisi ligula ultricies purus', '1', '2010-10-28 04:14:11', '1', '1', '1');
INSERT INTO `mod_newsslider` (`id`, `title`, `body`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('2', 'Cras ullamcorper', 'Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros  eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna  sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed  risus in est cursus ornare.', '1', '2010-10-28 04:14:33', '1', '2', '1');
INSERT INTO `mod_newsslider` (`id`, `title`, `body`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('3', 'Vivamus vitae', 'Lusce pulvinar velit sit amet ligula ornare tempus vulputate ipsum  semper. Praesent non lorem odio. Fusce sed dui massa, eu viverra erat.  Proin posuere nulla in lectus malesuada volutpat. Cras tristique blandit  tellus, eu consequat ante', '1', '2010-10-28 04:21:34', '1', '3', '1');
INSERT INTO `mod_newsslider` (`id`, `title`, `body`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('4', 'Another News', 'Vivamus vitae augue sed lacus placerat sollicitudin quis vel arcu. Vestibulum auctor, magna sit amet pulvinar tristique, nunc felis viverra tortor, venenatis convallis leo mauris eu massa. Intege', '1', '2010-10-28 04:43:36', '1', '4', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_poll_options`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_poll_options`;
CREATE TABLE `mod_poll_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `value` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `position` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_poll_options`
-- --------------------------------------------------

INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `position`) VALUES ('5', '1', 'Very Hard', '5');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `position`) VALUES ('4', '1', 'Hard', '4');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `position`) VALUES ('3', '1', 'Easy', '3');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `position`) VALUES ('2', '1', 'Very Easy', '2');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `position`) VALUES ('1', '1', 'Piece of cake', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_poll_questions`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_poll_questions`;
CREATE TABLE `mod_poll_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_poll_questions`
-- --------------------------------------------------

INSERT INTO `mod_poll_questions` (`id`, `question`, `created`, `status`) VALUES ('1', 'How do you find Zazavi Installation?', '2010-10-13 07:42:18', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_poll_votes`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_poll_votes`;
CREATE TABLE `mod_poll_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_id` int(11) NOT NULL,
  `voted_on` datetime NOT NULL,
  `ip` varchar(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_poll_votes`
-- --------------------------------------------------

INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('1', '2', '2010-10-14 14:00:55', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('2', '1', '2010-10-14 14:01:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('3', '1', '2010-10-14 14:02:04', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('4', '1', '2010-10-14 14:02:13', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('5', '3', '2010-10-14 14:02:16', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('6', '4', '2010-10-14 14:02:21', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('7', '3', '2010-10-14 14:02:24', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('8', '1', '2010-10-14 14:02:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('9', '2', '2010-10-14 14:02:31', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('10', '5', '2010-10-14 14:02:35', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('11', '1', '2010-10-14 14:02:38', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('12', '2', '2010-10-14 14:02:43', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('13', '1', '2010-10-14 14:02:46', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('14', '1', '2010-10-14 14:02:50', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('15', '1', '2010-10-14 14:05:26', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('16', '1', '2010-10-14 14:05:29', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('17', '4', '2010-10-14 14:05:33', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('18', '2', '2010-10-14 14:05:36', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('19', '1', '2010-10-14 14:05:40', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('20', '3', '2010-10-14 14:05:46', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('21', '2', '2010-10-14 14:05:49', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('22', '2', '2010-10-14 14:21:37', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('23', '1', '2010-10-14 14:21:53', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('24', '5', '2010-10-14 14:21:59', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('25', '1', '2010-10-14 14:35:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('26', '1', '2010-10-15 00:42:05', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('27', '3', '2010-10-15 00:49:42', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('28', '2', '2010-10-15 01:22:00', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('29', '2', '2010-10-15 01:24:51', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('30', '1', '2010-10-15 01:37:21', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('31', '1', '2010-10-15 01:38:48', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('32', '1', '2010-10-15 01:41:30', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('33', '1', '2010-10-15 01:42:21', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('34', '1', '2010-10-15 04:53:42', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('35', '3', '2010-10-15 05:09:14', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('36', '3', '2010-11-24 21:00:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('37', '3', '2010-11-28 00:56:07', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('38', '1', '2011-02-14 17:13:57', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('39', '1', '2011-02-14 17:15:37', '127.0.0.1');


-- --------------------------------------------------
# -- Table structure for table `mod_rss_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_rss_config`;
CREATE TABLE `mod_rss_config` (
  `url` varchar(200) DEFAULT NULL,
  `title_trim` varchar(3) DEFAULT NULL,
  `show_body` tinyint(1) NOT NULL DEFAULT '0',
  `body_trim` varchar(3) DEFAULT NULL,
  `show_date` tinyint(1) NOT NULL DEFAULT '1',
  `dateformat` varchar(30) DEFAULT NULL,
  `perpage` varchar(2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_rss_config`
-- --------------------------------------------------

INSERT INTO `mod_rss_config` (`url`, `title_trim`, `show_body`, `body_trim`, `show_date`, `dateformat`, `perpage`) VALUES ('http://news.google.com/?output=rss', '0', '0', '100', '0', 'F d, Y', '5');


-- --------------------------------------------------
# -- Table structure for table `mod_slider`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_slider`;
CREATE TABLE `mod_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL DEFAULT '',
  `filename` varchar(150) NOT NULL DEFAULT '',
  `url` varchar(150) NOT NULL DEFAULT '',
  `page_id` int(6) DEFAULT '0',
  `urltype` enum('int','ext') DEFAULT NULL,
  `position` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_slider`
-- --------------------------------------------------

INSERT INTO `mod_slider` (`id`, `title`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('4', 'Demo Image 4', 'sports_4.jpg', '#', '0', 'ext', '4');
INSERT INTO `mod_slider` (`id`, `title`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('3', 'Demo Image 3', 'sports_2.jpg', '#', '0', 'ext', '3');
INSERT INTO `mod_slider` (`id`, `title`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('2', 'Demo Image 2', 'sports_3.jpg', '#', '0', 'ext', '2');
INSERT INTO `mod_slider` (`id`, `title`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('1', 'Demo Image 1', 'sports_1.jpg', '#', '0', 'ext', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_slider_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_slider_config`;
CREATE TABLE `mod_slider_config` (
  `animation` varchar(30) NOT NULL,
  `anispeed` varchar(6) NOT NULL DEFAULT '0',
  `anitime` varchar(10) NOT NULL DEFAULT '0',
  `shownav` tinyint(1) NOT NULL DEFAULT '0',
  `shownavhide` tinyint(1) NOT NULL DEFAULT '0',
  `controllnav` tinyint(1) NOT NULL DEFAULT '0',
  `hoverpause` tinyint(1) NOT NULL DEFAULT '0',
  `showcaption` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_slider_config`
-- --------------------------------------------------

INSERT INTO `mod_slider_config` (`animation`, `anispeed`, `anitime`, `shownav`, `shownavhide`, `controllnav`, `hoverpause`, `showcaption`) VALUES ('fade', '500', '3000', '1', '1', '1', '1', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_tabs`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_tabs`;
CREATE TABLE `mod_tabs` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `body` text,
  `position` int(6) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_tabs`
-- --------------------------------------------------

INSERT INTO `mod_tabs` (`id`, `title`, `body`, `position`, `active`) VALUES ('1', 'Website Design', '&lt;img width=&quot;305&quot; height=&quot;220&quot; style=&quot;margin-left: 15px; float: right;&quot; alt=&quot;webdesign.png&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/webdesign.png&quot; /&gt;\r\n&lt;h1&gt;Website Design&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;\r\n&lt;br class=&quot;clear&quot; /&gt;', '1', '1');
INSERT INTO `mod_tabs` (`id`, `title`, `body`, `position`, `active`) VALUES ('2', 'Content Management', '&lt;img width=&quot;305&quot; height=&quot;220&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/cms.png&quot; alt=&quot;cms.png&quot; style=&quot;margin-left: 15px; float: right;&quot; /&gt;\r\n&lt;h1&gt;Content Management&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;&lt;br class=&quot;clear&quot; /&gt;', '2', '1');
INSERT INTO `mod_tabs` (`id`, `title`, `body`, `position`, `active`) VALUES ('3', 'E-Commerce', '&lt;img width=&quot;305&quot; height=&quot;220&quot; style=&quot;margin-left: 15px; float: right;&quot; alt=&quot;ecommerce.png&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/ecommerce.png&quot; /&gt;\r\n&lt;h1&gt;E-Commerce&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;\r\n&lt;br class=&quot;clear&quot; /&gt;', '4', '1');
INSERT INTO `mod_tabs` (`id`, `title`, `body`, `position`, `active`) VALUES ('4', 'Search Engines', '&lt;img width=&quot;305&quot; height=&quot;220&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/seo.png&quot; alt=&quot;seo.png&quot; style=&quot;margin-left: 15px; float: right;&quot; /&gt;\r\n&lt;h1&gt;Search Engines&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;<br />\r\n&lt;p&gt;&lt;a href=&quot;#&quot; class=&quot;button shadow&quot;&gt;Read More&lt;/a&gt;&lt;/p&gt;&lt;br class=&quot;clear&quot; /&gt;', '3', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_twitter_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_twitter_config`;
CREATE TABLE `mod_twitter_config` (
  `username` varchar(150) DEFAULT NULL,
  `counter` int(1) NOT NULL DEFAULT '5',
  `speed` varchar(6) NOT NULL,
  `show_image` tinyint(1) NOT NULL DEFAULT '1',
  `timeout` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_twitter_config`
-- --------------------------------------------------

INSERT INTO `mod_twitter_config` (`username`, `counter`, `speed`, `show_image`, `timeout`) VALUES ('ZazaviDotCom', '5', '300', '1', '10000');


-- --------------------------------------------------
# -- Table structure for table `modules`
-- --------------------------------------------------
DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL,
  `body` text,
  `show_title` tinyint(1) NOT NULL DEFAULT '0',
  `alt_class` varchar(100) NOT NULL DEFAULT '',
  `position` int(11) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0',
  `info` text,
  `modalias` varchar(50) NOT NULL,
  `hasconfig` tinyint(1) NOT NULL DEFAULT '0',
  `sidebar` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `modules`
-- --------------------------------------------------

INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('1', 'Testimonials', '&lt;p class=&quot;testimonial&quot;&gt;&lt;em&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi.&lt;/em&gt;&lt;/p&gt;\r\n&lt;em&gt;John Smith&lt;/em&gt;, &lt;strong&gt;www.somesite.com&lt;/strong&gt;', '1', 'green', '1', '0', '', '', '0', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('2', 'News Slider', '', '1', '', '2', '1', 'Displays latest news items', 'newsslider', '1', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('8', 'More Pages', '&lt;ul class=&quot;lists&quot;&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Home&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Page Types&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Templates&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;About Us&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Services &lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Projects&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Blog&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Contact Us&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '', '0', '0', '', '', '0', '1', '2010-07-22 11:38:51', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('3', 'An unordered list', 'This modul contains a dummy list of items\r\n&lt;ul&gt;\r\n    &lt;li&gt;List item 1&lt;/li&gt;\r\n    &lt;li&gt;List item 2&lt;/li&gt;\r\n    &lt;li&gt;List item 3&lt;/li&gt;\r\n    &lt;li&gt;List item 4&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '', '1', '0', '', '', '0', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('4', 'Info Point', '&lt;ul id=&quot;infopoint-list&quot;&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/iphone.png&quot; /&gt; Cum sociis natoque penatibus et magnis dis parturient montes&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/green.png&quot; /&gt; Curabitur mollis, lectus sit amet bibendum faucibus ligula&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/installer_box.png&quot; /&gt; Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/headphone.png&quot; /&gt; Cras ullamcorper suscipit  justo, at mattis odio auctor quis alteno&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/coins.png&quot; /&gt; Vestibulum  auctor, magna sit amet pulvinar tristique, nunc felis viverra&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://agda-graph/zazavipro/uploads/icons/color_wheel.png&quot; /&gt; Integer aliquet libero sed lorem consequat ut tempus faucibus&lt;/li&gt;\r\n&lt;/ul&gt;', '1', 'red', '1', '0', '', '', '0', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('5', 'Our Contact Numbers', '&lt;strong&gt;Office&lt;/strong&gt; +1-416-123456789&lt;br /&gt;\r\n&lt;strong&gt;helpdesk&lt;/strong&gt; +1-416-123456789&lt;br /&gt;', '1', '', '2', '0', '', '', '0', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('6', 'jQuery Slider', '', '0', '', '3', '1', 'jQuery Slider is one great way to display portfolio pieces, eCommerce product images, or even as an image gallery.', 'jqueryslider', '1', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('11', 'Contact Information', '&lt;ul&gt;\r\n    &lt;li&gt;&lt;b&gt;E-mail:&lt;/b&gt; &lt;a href=&quot;mailto:info@mywebsite.com&quot;&gt;info@mywebsite.com&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;b&gt;Telephone:&lt;/b&gt; 0080 000 000&lt;/li&gt;\r\n    &lt;li&gt;&lt;b&gt;Fax:&lt;/b&gt; 0080 000 000&lt;/li&gt;\r\n    &lt;li&gt;&lt;b&gt;Address:&lt;/b&gt;     1600 Amphitheatre Parkway                 Toronto, ON M2K 1Z7&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '', '0', '0', '', '', '0', '1', '2010-07-22 11:44:15', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('9', 'Even More Pages', '&lt;ul class=&quot;lists&quot;&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Updates&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;News&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Press Releases&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;New Offers&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Our Staff &lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Policy&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Events&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '', '0', '0', '', '', '0', '1', '2010-07-22 11:39:22', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('10', 'Latest Twitts', '', '1', '', '4', '1', 'Shows your latest twitts', 'twitts', '1', '1', '2010-07-22 11:42:08', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('13', 'Ajax Poll', '', '1', '', '5', '1', 'jQuery Ajax poll module.', 'poll', '1', '1', '2010-10-25 14:12:20', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('7', 'jQuery Tabs', '', '0', '', '7', '1', 'jQuery Dynamic Tabs', 'jtabs', '1', '1', '2010-12-20 12:12:20', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('12', 'Event Manager', '', '1', '', '8', '1', 'Easily publish and manage your company events.', 'events', '1', '1', '2010-12-28 10:12:14', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('14', 'Vertical Navigation', '', '1', '', '9', '1', 'Vertical flyout menu module', 'vmenu', '0', '1', '2010-12-27 08:12:14', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('15', 'Commenting System', '', '0', '', '10', '1', 'Encourage your readers to join in the discussion and leave comments and respond promptly to the comments left by your readers to make them feel valued', 'comments', '1', '0', '2011-01-10 14:10:24', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('16', 'Rss Parser', '', '1', '', '12', '1', 'Show rss feeds (RSS 0.9 / RSS 1.0). Also RSS 2.0, and Atom a with few exceptions.', 'rss', '1', '1', '2011-04-16 08:11:55', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('17', 'Gallery', '', '0', '', '13', '1', 'Fully featured gallery module', 'gallery', '1', '0', '2011-04-28 06:19:32', '1');
INSERT INTO `modules` (`id`, `title`, `body`, `show_title`, `alt_class`, `position`, `system`, `info`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('18', 'User Login', '', '1', 'blue', '14', '1', 'Shows login form.', 'login', '0', '1', '2011-05-10 02:12:14', '1');


-- --------------------------------------------------
# -- Table structure for table `pages`
-- --------------------------------------------------
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `contact_form` tinyint(1) NOT NULL DEFAULT '0',
  `gallery_id` int(4) NOT NULL DEFAULT '0',
  `comments` tinyint(1) NOT NULL DEFAULT '0',
  `membership_id` varchar(40) NOT NULL DEFAULT '0',
  `access` enum('Public','Registered','Membership') DEFAULT NULL,
  `keywords` text NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `pages`
-- --------------------------------------------------

INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `description`, `created`, `active`) VALUES ('1', 'Home', 'Home', '0', '0', '0', '0', 'Public', 'zazaviliteCMS, Zazavi Lite CMS, Content Menagement System, Lightweight CMS', 'Zazavi CMS is a web content management system made for the peoples who don&#39;t have much technical knowledge of HTML or PHP but know how to use a simple notepad with computer keyboard.', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `description`, `created`, `active`) VALUES ('2', 'What is Zazavi', 'What-is-Zazavi', '0', '0', '1', '0', 'Public', 'Zazavi, Content Management System, Lightweight CMS', 'Zazavi is a php based database dependent CMS which require one database and obviously php language support on your web hosting server.', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `description`, `created`, `active`) VALUES ('3', 'Contact Info', 'Contact-Info', '1', '0', '0', '0', 'Public', '', '', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `description`, `created`, `active`) VALUES ('5', 'Demo Gallery', 'Demo-Gallery', '0', '1', '0', '0', 'Public', '', '', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `description`, `created`, `active`) VALUES ('6', 'Three Column Page', 'Tree-Column-Page', '0', '0', '0', '0', 'Public', '', '', '2010-07-22 20:26:17', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `description`, `created`, `active`) VALUES ('7', 'All Modules', 'All-Modules', '0', '0', '0', '0', 'Public', '', '', '2010-07-22 20:40:19', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `description`, `created`, `active`) VALUES ('8', 'More Pages', 'More-Pages', '0', '0', '0', '0', 'Public', '', '', '2010-08-09 22:06:58', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `description`, `created`, `active`) VALUES ('9', 'Members Only', 'Members-Only', '0', '0', '0', '0', 'Registered', '', '', '2011-05-19 15:28:29', '1');
INSERT INTO `pages` (`id`, `title`, `slug`, `contact_form`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `description`, `created`, `active`) VALUES ('10', 'Membership Only', 'Membership-Only', '0', '0', '0', '2,3,4,1,5', 'Membership', '', '', '2011-05-19 15:28:48', '1');


-- --------------------------------------------------
# -- Table structure for table `payments`
-- --------------------------------------------------
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txn_id` varchar(100) DEFAULT NULL,
  `membership_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rate_amount` varchar(255) NOT NULL,
  `currency` varchar(4) DEFAULT NULL,
  `date` datetime NOT NULL,
  `pp` enum('PayPal','MoneyBookers') DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `payments`
-- --------------------------------------------------

INSERT INTO `payments` (`id`, `txn_id`, `membership_id`, `user_id`, `rate_amount`, `currency`, `date`, `pp`, `ip`, `status`) VALUES ('1', '', '2', '1', '5.00', '', '2011-04-05 14:12:32', 'PayPal', '', '1');
INSERT INTO `payments` (`id`, `txn_id`, `membership_id`, `user_id`, `rate_amount`, `currency`, `date`, `pp`, `ip`, `status`) VALUES ('2', '', '2', '2', '5.00', '', '2011-03-12 14:12:32', 'PayPal', '', '1');
INSERT INTO `payments` (`id`, `txn_id`, `membership_id`, `user_id`, `rate_amount`, `currency`, `date`, `pp`, `ip`, `status`) VALUES ('3', '', '3', '3', '10.00', '', '2011-03-05 16:47:36', 'MoneyBookers', '', '1');


-- --------------------------------------------------
# -- Table structure for table `posts`
-- --------------------------------------------------
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `show_title` tinyint(1) NOT NULL DEFAULT '1',
  `body` text NOT NULL,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `posts`
-- --------------------------------------------------

INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('1', '1', 'Welcome to Zazavi', '1', 'Welcome to Zazavi. The Lightweight CMS.&lt;br /&gt;\n&lt;br /&gt;\nCongratulation !! your installation of Zazavi&amp;nbsp; was successful.&lt;br /&gt;\n&lt;br /&gt;\nThis is the home page of your default installation of Zazavi.&lt;br /&gt;\nYou can edit or add content to your  Web site  from the administration panel of Zazavi by clicking the link below.&lt;br /&gt;\n&lt;a href=&quot;admin/index.php&quot; class=&quot;but&quot;&gt;&lt;span&gt;Administration panel&lt;/span&gt;&lt;/a&gt; &lt;hr /&gt;\n&lt;div class=&quot;col-31&quot;&gt;\n&lt;h3&gt;Who we are?&lt;/h3&gt;\n&lt;img height=&quot;190&quot; width=&quot;290&quot; alt=&quot;Who Are We?&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/demo_1.jpg&quot; class=&quot;image&quot; style=&quot;border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238); margin: 1px; padding: 5px; -moz-border-radius: 5px 5px 5px 5px;&quot; /&gt;\n&lt;p&gt;Nulla sollicitudin nulla mauris. Donec congue facilisis lorem, ornare tincidunt orci ullamcorper nec.&lt;/p&gt;\n&lt;p&gt;Nam pellentesque auctor turpis nec &lt;strong&gt;dapibus&lt;/strong&gt;. Vivamus interdum dignissim tincidunt. Vestibulum dapibus laoreet arcu, et pharetra augue ultricies quis.&lt;/p&gt;\n&lt;p&gt;Sed luctus condimentum mollis. Etiam lacus turpis, hendrerit vitae &lt;em&gt;feugiat&lt;/em&gt; sit amet, cursus ac quam. Curabitur metus mi.&lt;/p&gt;\n&lt;/div&gt;\n&lt;div class=&quot;col-32&quot;&gt;\n&lt;h3&gt;What we do?&lt;/h3&gt;\n&lt;img height=&quot;190&quot; width=&quot;290&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/demo_2.jpg&quot; alt=&quot;What we do?&quot; style=&quot;border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238); margin: 1px; padding: 5px; -moz-border-radius: 5px 5px 5px 5px;&quot; /&gt;\n&lt;p&gt;Nulla sollicitudin nulla mauris. Donec congue facilisis lorem, ornare tincidunt orci ullamcorper nec.&lt;/p&gt;\n&lt;p&gt;Nam pellentesque auctor turpis nec &lt;strong&gt;dapibus&lt;/strong&gt;. Vivamus interdum dignissim tincidunt. Vestibulum dapibus laoreet arcu, et pharetra augue ultricies quis.&lt;/p&gt;\n&lt;p&gt;Sed luctus condimentum mollis. Etiam lacus turpis, hendrerit vitae &lt;em&gt;feugiat&lt;/em&gt; sit amet, cursus ac quam. Curabitur metus mi.&lt;/p&gt;\n&lt;/div&gt;\n&lt;div class=&quot;col-33&quot;&gt;\n&lt;h3&gt;What is this?&lt;/h3&gt;\n&lt;img height=&quot;190&quot; width=&quot;290&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/demo_3.jpg&quot; alt=&quot;What Is This?&quot; style=&quot;border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238); margin: 1px; padding: 5px; -moz-border-radius: 5px 5px 5px 5px;&quot; /&gt;\n&lt;p&gt;Nulla sollicitudin nulla mauris. Donec congue facilisis lorem, ornare tincidunt orci ullamcorper nec.&lt;/p&gt;\n&lt;p&gt;Nam pellentesque auctor turpis nec &lt;strong&gt;dapibus&lt;/strong&gt;. Vivamus interdum dignissim tincidunt. Vestibulum dapibus laoreet arcu, et pharetra augue ultricies quis.&lt;/p&gt;\n&lt;p&gt;Sed luctus condimentum mollis. Etiam lacus turpis, hendrerit vitae &lt;em&gt;feugiat&lt;/em&gt; sit amet, cursus ac quam. Curabitur metus mi.&lt;/p&gt;\n&lt;/div&gt;\n&lt;div class=&quot;clear&quot;&gt;&amp;nbsp;&lt;/div&gt;', '1', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('2', '2', 'What is Zazavi', '1', '&lt;div style=&quot;text-align: center;&quot;&gt;&lt;img height=&quot;230&quot; width=&quot;585&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/sampleimage_4.jpg&quot; alt=&quot;sampleimage_4.jpg&quot; class=&quot;image&quot; /&gt;&lt;/div&gt;\n&lt;p&gt;Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam,  dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus  sit amet bibendum faucibus, nisi ligula ultricies purus, in malesuada  arcu sem ut mauris. Proin lobortis rutrum ultrices.&lt;/p&gt;\n&lt;h3&gt;Company Background&lt;/h3&gt;\n&lt;p&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut  dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed  feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla  facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit  commodo. Cum sociis natoque penatibus et magnis dis parturient montes,  nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit  justo, at mattis odio auctor quis. In hac habitasse platea dictumst.  Morbi ut turpis vitae risus egestas feugiat quis eget quam. Vivamus  vitae augue sed lacus placerat sollicitudin quis vel arcu. Vestibulum  auctor, magna sit amet pulvinar tristique, nunc felis viverra tortor,  venenatis convallis leo mauris eu massa. Integer aliquet libero sed  lorem consequat ut tempus libero viverra. Donec ut ipsum vitae leo  volutpat commodo.&lt;/p&gt;\n&lt;h3&gt;John Smith, CEO&lt;/h3&gt;\n&lt;a href=&quot;http://agda-graph/zazavipro/uploads/images/pages/blank_profile_image.jpg&quot;&gt;&lt;img height=&quot;150&quot; width=&quot;116&quot; class=&quot;/&quot; alt=&quot;Sample Image&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/blank_profile_image.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;&lt;/a&gt;\n&lt;p&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit commodo.&lt;/p&gt;\n&lt;p&gt;Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio auctor quis.&lt;/p&gt;\n&lt;p&gt;In hac habitasse platea dictumst.ivamus leo diam,  dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus  sit amet bibendum faucibus, nisi ligula ultricies purus&lt;/p&gt;\n&lt;br clear=&quot;left&quot; /&gt;', '1', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('3', '3', 'Contact Information', '1', '&lt;h3&gt;Where to Find Us&lt;/h3&gt;\r\n&lt;img width=&quot;150&quot; height=&quot;150&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/thumbs/thumb_contact-us.jpg&quot; alt=&quot;thumb_contact-us.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros  eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna  sit amet nibh. &lt;br /&gt;\r\n&lt;br /&gt;\r\nSuspendisse sed tortor nisi. Nulla facilisi. In sed  risus in est cursus ornare. Fusce tempor hendrerit commodo. Cum sociis  natoque penatibus et magnis dis parturient montes, nascetur ridiculus  mus. &lt;br /&gt;\r\n&lt;br /&gt;\r\nNam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio  auctor quis. In hac habitasse platea dictumst. Morbi ut turpis vitae  risus egestas feugiat quis eget quam. Vivamus vitae augue sed lacus  placerat sollicitudin quis vel arcu. &lt;br /&gt;\r\n&lt;br /&gt;\r\nVestibulum auctor, magna sit amet  pulvinar tristique, nunc felis viverra tortor, venenatis convallis leo  mauris eu massa. Integer aliquet libero sed lorem consequat ut tempus  libero viverra. Donec ut ipsum vitae leo volutpat commodo.', '1', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('4', '5', 'Gallery Demo', '1', '&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut  tempor eros. Proin bibendum, lacus vitae venenatis convallis, libero  ipsum imperdiet sem, ac consequat massa risus vel sem. Nunc nec ante non  arcu mattis viverra. Morbi accumsan, augue ac dignissim tempus, lacus  libero molestie est, in eleifend lorem purus eu mauris. Nulla at metus a  enim faucibus placerat vitae a justo. Maecenas rhoncus ante libero.&lt;/p&gt;', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('5', '6', 'Three Column Page', '1', '&lt;p&gt;&lt;img width=&quot;150&quot; height=&quot;58&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/thumbs/thumb_sampleimage_4.jpg&quot; alt=&quot;thumb_sampleimage_4.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed  ut tempor eros. Proin bibendum, lacus vitae venenatis convallis, libero  ipsum imperdiet sem, ac consequat massa risus vel sem. Nunc nec ante non  arcu mattis viverra. Morbi accumsan, augue ac dignissim tempus, lacus  libero molestie est, in eleifend lorem purus eu mauris. Nulla at metus a  enim faucibus placerat vitae a justo. Maecenas rhoncus ante libero.  Phasellus vitae porta nunc.&lt;/p&gt;\r\n&lt;form method=&quot;post&quot; action=&quot;https://www.paypal.com/cgi-bin/webscr&quot; target=&quot;_paypal&quot;&gt;\r\n    &lt;input type=&quot;hidden&quot; name=&quot;cmd&quot; value=&quot;_xclick&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;business&quot; value=&quot;asdfaf@sAZF.com&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;item_name&quot; value=&quot;Item Desc&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;item_number&quot; value=&quot;1&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;amount&quot; value=&quot;25&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;shipping&quot; value=&quot;0.00&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;tax_rate&quot; value=&quot;0.000&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;no_note&quot; value=&quot;1&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;currency_code&quot; value=&quot;CAD&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;lc&quot; value=&quot;US&quot; /&gt;&lt;input  type=&quot;image&quot; name=&quot;submit&quot; src=&quot;https://www.paypal.com/en_US/i/btn/x-click-but23.gif&quot; alt=&quot;Buy Now&quot; /&gt;\r\n&lt;/form&gt;', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('6', '7', 'All Module Positions', '1', '&lt;p&gt;&lt;img width=&quot;120&quot; height=&quot;150&quot; style=&quot;padding: 5px; margin-left: 15px; float: right; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; alt=&quot;thumb_TAH02017.JPG&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/thumbs/thumb_TAH02017.JPG&quot; /&gt;Aliquam vitae metus non elit laoreet varius. Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a.&lt;/p&gt;\r\n&lt;p&gt;Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere  cubilia Curae; Etiam a justo libero, aliquam auctor felis. Nulla a odio  ut magna ultrices vestibulum.&lt;/p&gt;\r\n&lt;p&gt;Integer urna magna, euismod sed pharetra  eget, ornare in dolor. Etiam bibendum mi ut nisi facilisis lobortis.  Phasellus turpis orci, interdum adipiscing aliquam ut, convallis  volutpat tellus. Nunc massa nunc, dapibus eget scelerisque ac, eleifend  eget ligula. Maecenas accumsan tortor in quam adipiscing hendrerit.  Donec ac risus nec est molestie malesuada ac id risus. In hac habitasse  platea dictumst. In quam dui, blandit id interdum id, facilisis a leo.&lt;/p&gt;\r\nNullam fringilla quam pharetra enim interdum accumsan. Phasellus nec  euismod quam. Donec tempor accumsan posuere. Phasellus ac metus orci, ac  venenatis magna. Suspendisse sit amet odio at enim ultricies  pellentesque eget ac risus. Vestibulum eleifend odio ut tellus faucibus  malesuada feugiat nisi rhoncus. Proin nec sem ut augue placerat blandit  ut ut orci. Cras aliquet venenatis enim, quis rutrum urna sollicitudin  vel.\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n&lt;hr /&gt;\r\n&lt;img width=&quot;150&quot; height=&quot;58&quot; alt=&quot;thumb_sampleimage_4.jpg&quot; src=&quot;http://agda-graph/zazavipro/uploads/images/pages/thumbs/thumb_sampleimage_4.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Aliquam vitae metus non elit laoreet varius. Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a. Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('9', '8', 'More Sample Pages', '1', '&lt;p&gt;Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere  cubilia Curae; Etiam a justo libero, aliquam auctor felis. Nulla a odio  ut magna ultrices vestibulum. Integer urna magna, euismod sed pharetra  eget, ornare in dolor. Etiam bibendum mi ut nisi facilisis lobortis.  Phasellus turpis orci, interdum adipiscing aliquam ut, convallis  volutpat tellus.&lt;/p&gt;\r\n&lt;div style=&quot;text-align: center;&quot;&gt;&lt;object width=&quot;640&quot; height=&quot;505&quot;&gt;\r\n&lt;param name=&quot;movie&quot; value=&quot;http://www.youtube.com/v/BYm_Mn7Hxag?fs=1&amp;amp;hl=en_US&amp;amp;color1=0x006699&amp;amp;color2=0x54abd6&quot; /&gt;\r\n&lt;param name=&quot;allowFullScreen&quot; value=&quot;true&quot; /&gt;\r\n&lt;param name=&quot;allowscriptaccess&quot; value=&quot;always&quot; /&gt;&lt;embed width=&quot;640&quot; height=&quot;505&quot; src=&quot;http://www.youtube.com/v/BYm_Mn7Hxag?fs=1&amp;amp;hl=en_US&amp;amp;color1=0x006699&amp;amp;color2=0x54abd6&quot; type=&quot;application/x-shockwave-flash&quot; allowscriptaccess=&quot;always&quot; allowfullscreen=&quot;true&quot;&gt;&lt;/embed&gt;&lt;/object&gt;&lt;/div&gt;\r\n&lt;hr /&gt;\r\n&lt;p&gt;Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a. Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.&lt;/p&gt;', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('10', '9', 'Registered Users Only', '1', '&lt;em&gt;&lt;strong&gt;This page is for Registered users only&lt;/strong&gt;&lt;/em&gt;&lt;br /&gt;', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `show_title`, `body`, `position`, `active`) VALUES ('11', '10', 'Membership Access', '1', '&lt;em&gt;&lt;strong&gt;This page can be accessed with valid membership only!&lt;/strong&gt;&lt;/em&gt;&lt;br /&gt;', '0', '1');


-- --------------------------------------------------
# -- Table structure for table `settings`
-- --------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `site_name` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `site_url` varchar(150) NOT NULL,
  `site_email` varchar(50) NOT NULL,
  `theme` varchar(32) NOT NULL,
  `seo` tinyint(1) NOT NULL DEFAULT '0',
  `perpage` tinyint(4) NOT NULL DEFAULT '10',
  `backup` varchar(64) NOT NULL,
  `thumb_w` varchar(5) NOT NULL,
  `thumb_h` varchar(5) NOT NULL,
  `img_w` varchar(5) NOT NULL,
  `img_h` varchar(5) NOT NULL,
  `short_date` varchar(50) NOT NULL,
  `long_date` varchar(50) NOT NULL,
  `dtz` varchar(120) DEFAULT NULL,
  `lang` varchar(2) NOT NULL DEFAULT 'en',
  `show_lang` tinyint(1) NOT NULL DEFAULT '0',
  `offline` tinyint(1) NOT NULL DEFAULT '0',
  `logo` varchar(100) DEFAULT NULL,
  `currency` varchar(4) DEFAULT NULL,
  `cur_symbol` varchar(2) DEFAULT NULL,
  `reg_verify` tinyint(1) NOT NULL DEFAULT '1',
  `auto_verify` tinyint(1) NOT NULL DEFAULT '1',
  `reg_allowed` tinyint(1) NOT NULL DEFAULT '1',
  `notify_admin` tinyint(1) NOT NULL DEFAULT '0',
  `user_limit` varchar(6) DEFAULT NULL,
  `flood` varchar(6) DEFAULT NULL,
  `attempt` varchar(2) DEFAULT NULL,
  `logging` tinyint(1) NOT NULL DEFAULT '0',
  `metakeys` text,
  `metadesc` text,
  `analytics` text,
  `mailer` enum('PHP','SMTP') DEFAULT NULL,
  `smtp_host` varchar(150) DEFAULT NULL,
  `smtp_user` varchar(50) DEFAULT NULL,
  `smtp_pass` varchar(50) DEFAULT NULL,
  `smtp_port` tinyint(3) DEFAULT NULL,
  `version` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `settings`
-- --------------------------------------------------

INSERT INTO `settings` (`site_name`, `company`, `site_url`, `site_email`, `theme`, `seo`, `perpage`, `backup`, `thumb_w`, `thumb_h`, `img_w`, `img_h`, `short_date`, `long_date`, `dtz`, `lang`, `show_lang`, `offline`, `logo`, `currency`, `cur_symbol`, `reg_verify`, `auto_verify`, `reg_allowed`, `notify_admin`, `user_limit`, `flood`, `attempt`, `logging`, `metakeys`, `metadesc`, `analytics`, `mailer`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `version`) VALUES ('Zazavi', 'Zazavi.com', 'http://agda-graph/zazavipro', 'gewa@rogers.com', 'master', '1', '10', '16-May-2011_14-13-24.sql', '150', '150', '800', '800', '%d %b %Y', '%a %d, %M %Y', 'America/Toronto', 'en', '1', '0', 'logo.png', 'CAD', '$', '1', '1', '1', '1', '0', '1800', '3', '1', 'metakeys, separated,by coma', 'Your website description goes here', '', 'PHP', 'mail.hostname.com', 'yourusername', 'yourpass', '25', '2.00');


-- --------------------------------------------------
# -- Table structure for table `stats`
-- --------------------------------------------------
DROP TABLE IF EXISTS `stats`;
CREATE TABLE `stats` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `day` date NOT NULL DEFAULT '0000-00-00',
  `pageviews` int(10) NOT NULL DEFAULT '0',
  `uniquevisitors` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=117 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `stats`
-- --------------------------------------------------

INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('1', '2010-08-12', '7', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('2', '2010-08-14', '5', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('3', '2010-08-26', '5', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('4', '2010-08-30', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('5', '2010-09-04', '185', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('6', '2010-09-15', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('7', '2010-09-16', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('8', '2010-09-17', '11', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('9', '2010-09-19', '13', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('10', '2010-10-18', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('11', '2010-10-19', '14', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('12', '2010-10-20', '291', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('13', '2010-10-21', '156', '4');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('14', '2010-10-22', '191', '9');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('15', '2010-10-23', '95', '4');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('16', '2010-10-25', '17', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('17', '2010-10-27', '21', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('18', '2010-10-28', '306', '12');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('19', '2010-10-29', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('20', '2010-11-04', '14', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('21', '2010-11-08', '11', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('22', '2010-11-17', '13', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('23', '2010-11-18', '42', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('24', '2010-11-24', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('25', '2010-11-25', '6', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('26', '2010-11-27', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('27', '2010-11-28', '55', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('28', '2010-11-29', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('29', '2010-11-30', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('30', '2010-12-01', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('31', '2010-12-07', '7', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('32', '2010-12-09', '22', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('33', '2010-12-11', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('34', '2010-12-13', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('35', '2010-12-14', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('36', '2010-12-15', '65', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('37', '2010-12-16', '116', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('38', '2010-12-17', '59', '11');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('39', '2010-12-18', '32', '6');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('40', '2010-12-19', '222', '9');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('41', '2010-12-20', '474', '28');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('42', '2010-12-21', '545', '24');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('43', '2010-12-22', '43', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('44', '2010-12-23', '116', '7');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('45', '2010-12-25', '29', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('46', '2010-12-26', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('47', '2010-12-27', '389', '20');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('48', '2010-12-28', '323', '21');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('49', '2010-12-29', '22', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('50', '2010-12-30', '21', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('51', '2010-12-31', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('52', '2011-01-03', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('53', '2011-01-06', '5', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('54', '2011-01-07', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('55', '2011-01-08', '12', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('56', '2011-01-10', '11', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('57', '2011-01-11', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('58', '2011-01-13', '848', '75');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('59', '2011-01-15', '8', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('60', '2011-01-19', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('61', '2011-01-22', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('62', '2011-01-25', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('63', '2011-01-27', '28', '7');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('64', '2011-01-28', '297', '11');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('65', '2011-01-29', '216', '7');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('66', '2011-01-30', '231', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('67', '2011-01-31', '152', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('68', '2011-02-01', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('69', '2011-02-03', '48', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('70', '2011-02-07', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('71', '2011-02-09', '178', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('72', '2011-02-10', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('73', '2011-02-11', '10', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('74', '2011-02-14', '156', '7');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('75', '2011-02-15', '368', '15');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('76', '2011-02-16', '241', '21');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('77', '2011-02-22', '52', '11');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('78', '2011-02-23', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('79', '2011-03-01', '248', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('80', '2011-03-02', '145', '45');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('81', '2011-03-03', '2', '37');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('82', '2011-03-04', '68', '26');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('83', '2011-03-05', '621', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('84', '2011-03-06', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('85', '2011-03-07', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('86', '2011-03-08', '9', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('87', '2011-03-09', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('88', '2011-03-10', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('89', '2011-03-14', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('90', '2011-03-16', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('91', '2011-03-17', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('92', '2011-03-21', '7', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('93', '2011-03-31', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('94', '2011-04-06', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('95', '2011-04-08', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('96', '2011-04-09', '7', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('97', '2011-04-25', '64', '4');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('98', '2011-04-26', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('99', '2011-04-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('100', '2011-05-04', '33', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('101', '2011-05-01', '100', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('102', '2011-05-06', '18', '6');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('103', '2011-05-07', '31', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('104', '2011-05-08', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('105', '2011-05-09', '38', '6');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('106', '2011-05-10', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('107', '2011-05-11', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('108', '2011-05-13', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('109', '2011-05-14', '583', '20');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('110', '2011-05-15', '79', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('111', '2011-05-16', '25', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('112', '2011-05-19', '30', '9');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('113', '2011-05-21', '9', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('114', '2011-05-25', '63', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('115', '2011-05-26', '203', '6');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('116', '2011-05-27', '10', '3');


-- --------------------------------------------------
# -- Table structure for table `users`
-- --------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `membership_id` tinyint(3) NOT NULL DEFAULT '0',
  `mem_expire` datetime DEFAULT '0000-00-00 00:00:00',
  `trial_used` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(32) NOT NULL,
  `fname` varchar(32) NOT NULL,
  `lname` varchar(32) NOT NULL,
  `token` varchar(40) NOT NULL DEFAULT '0',
  `newsletter` tinyint(1) NOT NULL DEFAULT '0',
  `userlevel` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  `lastlogin` datetime DEFAULT '0000-00-00 00:00:00',
  `lastip` varchar(16) DEFAULT '0',
  `active` enum('y','n','t','b') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `users`
-- --------------------------------------------------

INSERT INTO `users` (`id`, `username`, `password`, `membership_id`, `mem_expire`, `trial_used`, `email`, `fname`, `lname`, `token`, `newsletter`, `userlevel`, `created`, `lastlogin`, `lastip`, `active`) VALUES ('1', 'admin', '42b7b504b2753b71f41780d5e86f1139a2ab5647', '4', '2012-05-10 16:08:09', '0', 'alex.kuzmanovic@gmail.com', 'Web', 'Master', '0', '1', '9', '2011-04-10 14:16:22', '2011-05-27 11:31:43', '127.0.0.1', 'y');
INSERT INTO `users` (`id`, `username`, `password`, `membership_id`, `mem_expire`, `trial_used`, `email`, `fname`, `lname`, `token`, `newsletter`, `userlevel`, `created`, `lastlogin`, `lastip`, `active`) VALUES ('2', 'john', '42b7b504b2753b71f41780d5e86f1139a2ab5647', '3', '0000-00-00 00:00:00', '0', 'john@mail.com', 'John', 'Johnson', '0', '0', '1', '2011-05-01 18:10:14', '0000-00-00 00:00:00', '127.0.0.1', 'n');
INSERT INTO `users` (`id`, `username`, `password`, `membership_id`, `mem_expire`, `trial_used`, `email`, `fname`, `lname`, `token`, `newsletter`, `userlevel`, `created`, `lastlogin`, `lastip`, `active`) VALUES ('3', 'mike', '42b7b504b2753b71f41780d5e86f1139a2ab5647', '2', '0000-00-00 00:00:00', '0', 'mike@mail.com', 'Mike', 'Manson', '0', '0', '1', '2011-05-02 18:10:14', '0000-00-00 00:00:00', '127.0.0.1', 't');
INSERT INTO `users` (`id`, `username`, `password`, `membership_id`, `mem_expire`, `trial_used`, `email`, `fname`, `lname`, `token`, `newsletter`, `userlevel`, `created`, `lastlogin`, `lastip`, `active`) VALUES ('4', 'steve', '42b7b504b2753b71f41780d5e86f1139a2ab5647', '0', '0000-00-00 00:00:00', '0', 'steve@mail.com', 'Steven', 'Swanson', '0', '0', '1', '2011-05-03 18:10:14', '0000-00-00 00:00:00', '127.0.0.1', 'b');


