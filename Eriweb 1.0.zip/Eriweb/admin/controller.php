<?php
  /**
   * Controller
   *
   * @package Eriweb
   * @author Eriweb.com
   * @license - http://www.gnu.org/licenses/gpl-2.0.html
   * @version $Id: controller.php, v2.00 2011-04-20 10:12:05 gewa Exp $
   */
  define("_VALID_PHP", true);
  
  require_once("init.php");
  if (!$user->is_Admin())
    redirect_to("login.php");
?>
<?php
  /* Proccess Menu */
  if (isset($_POST['processMenu']))
      : if (intval($_POST['processMenu']) == 0 || empty($_POST['processMenu']))
      : redirect_to("index.php?do=menus");
  endif;
  $content->id = (isset($_POST['id'])) ? $_POST['id'] : 0; 
  $content->processMenu();
  endif;
?>
<?php
  /* Proccess Page */
  if (isset($_POST['processPage']))
      : if (intval($_POST['processPage']) == 0 || empty($_POST['processPage']))
      : redirect_to("index.php?do=pages");
  endif;
  $content->pageid = (isset($_POST['pageid'])) ? $_POST['pageid'] : 0; 
  $content->processPage();
  endif;
?>
<?php
  /* Proccess Post */
  if (isset($_POST['processPost']))
      : if (intval($_POST['processPost']) == 0 || empty($_POST['processPost']))
      : redirect_to("index.php?do=posts");
  endif;
  $content->postid = (isset($_POST['postid'])) ? $_POST['postid'] : 0; 
  $content->processPost();
  endif;
?>
<?php
  /* Proccess Module */
  if (isset($_POST['processModule']))
      : if (intval($_POST['processModule']) == 0 || empty($_POST['processModule']))
      : redirect_to("index.php?do=modules");
  endif;
  $content->modid = (isset($_POST['modid'])) ? $_POST['modid'] : 0; 
  $content->processModule();
  endif;
?>
<?php
  /* Proccess Membership */
  if (isset($_POST['processMembership']))
      : if (intval($_POST['processMembership']) == 0 || empty($_POST['processMembership']))
      : redirect_to("index.php?do=pages");
  endif;
  $content->id = (isset($_POST['id'])) ? $_POST['id'] : 0; 
  $member->processMembership();
  endif;
?>
<?php
  /* Proccess User */
  if (isset($_POST['processUser']))
      : if (intval($_POST['processUser']) == 0 || empty($_POST['processUser']))
      : redirect_to("index.php?do=users");
  endif;
  $user->userid = (isset($_POST['userid'])) ? $_POST['userid'] : 0; 
  $user->processUser();
  endif;
?>
<?php
  /* Proccess Configuration */
  if (isset($_POST['processConfig']))
      : if (isset($_POST['processLogo']))
      : if (!empty($_FILES['logo']['name']))
      : move_uploaded_file($_FILES["logo"]["tmp_name"], UPLOADS . $_FILES["logo"]["name"]);
  print $_FILES['logo']['name'];
  endif;
  elseif (isset($_POST['doconfig']))
      : $core->updateSettings();
  endif;
  endif;
?>
<?php
  /* Proccess Email Template */
  if (isset($_POST['processTemplate']))
      : if (intval($_POST['processTemplate']) == 0 || empty($_POST['processTemplate']))
      : redirect_to("index.php?do=templates");
  endif;
  $content->id = (isset($_POST['id'])) ? $_POST['id'] : 0; 
  $member->processEmailTemplate();
  endif;
?>
<?php
  /* Add New Language */
  if (isset($_POST['addLanguage']))
      : if (intval($_POST['addLanguage']) == 0 || empty($_POST['addLanguage']))
      : redirect_to("index.php?do=language");
  endif;
  $core->addLanguage();
  endif;
?>
<?php
  /* Update Language */
  if (isset($_POST['updateLanguage']))
      : if (intval($_POST['updateLanguage']) == 0 || empty($_POST['updateLanguage']))
      : redirect_to("index.php?do=language");
  endif;
  $content->id = (isset($_POST['id'])) ? $_POST['id'] : 0; 
  $core->updateLanguage();
  endif;
?>
<?php
  /* Proccess Newsletter */
  if (isset($_POST['processNewsletter']))
      : if (intval($_POST['processNewsletter']) == 0 || empty($_POST['processNewsletter']))
      : redirect_to("index.php?do=newsletter");
  endif;
  $member->emailUsers();
  endif;
?>
<?php
  /* Proccess Gateway */
  if (isset($_POST['processGateway']))
      : if (intval($_POST['processGateway']) == 0 || empty($_POST['processGateway']))
      : redirect_to("index.php?do=gateways");
  endif;
  $content->id = (isset($_POST['id'])) ? $_POST['id'] : 0; 
  $member->processGateway();
  endif;
?>
<?php
  /* Proccess Form */
  if (isset($_POST['processForm']))
      : if (intval($_POST['processForm']) == 0 || empty($_POST['processForm']))
      : redirect_to("index.php?do=forms");
  endif;
  
  require_once(EriwebLITE . "lib/class_forms.php");
  $form = new Forms();
  
  $form->formid = (isset($_POST['formid'])) ? $_POST['formid'] : 0; 
  $form->processForm();
  endif;
?>
<?php
  /* Proccess Fields */
  if (isset($_POST['processField']))
      : if (intval($_POST['processField']) == 0 || empty($_POST['processField']))
      : redirect_to("index.php?do=forms");
  endif;
  
  require_once(EriwebLITE . "lib/class_forms.php");
  $form = new Forms();
  
  $form->fieldid = (isset($_POST['fieldid'])) ? $_POST['fieldid'] : 0; 
  $form->formid = (isset($_POST['formid'])) ? $_POST['formid'] : 0; 
  $form->processFields();
  endif;
?>