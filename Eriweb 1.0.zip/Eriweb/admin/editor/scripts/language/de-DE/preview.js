function loadTxt()
    {
    document.getElementById("btnClose").value = "schlie\u00DFen";//"close";
    }
function writeTitle()
    {
    document.write("<title>Vorschau</title>")
    }