function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "HTML Code";
    document.getElementById("btnClose").value = "schlie\u00DFen";//"close";
    }
function writeTitle()
    {
    document.write("<title>Sonderzeichen</title>")
    }