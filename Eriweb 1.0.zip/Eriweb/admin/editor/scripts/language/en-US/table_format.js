function loadTxt()
    {
    var txtLang = document.getElementsByName("txtLang");
    txtLang[0].innerHTML = "Auto Format";
            
    document.getElementById("btnClose").value = "close";
    }
function getTxt(s)
    {
    }    
function writeTitle()
    {
    document.write("<title>Table Auto Format</title>")
    }