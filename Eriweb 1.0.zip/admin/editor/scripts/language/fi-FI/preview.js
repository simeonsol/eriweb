function loadTxt()
    {
    document.getElementById("btnClose").value = "Sulje";
    }
function writeTitle()
    {
    document.write("<title>Esikatselu</title>")
    }