function loadTxt()
    {
    var txtLang = document.getElementsByName("txtLang");
    txtLang[0].innerHTML = "Web Pallete";
    txtLang[1].innerHTML = "Couleurs nomm\u00E9es";
    txtLang[2].innerHTML = "216 Couleurs web";
    txtLang[3].innerHTML = "Nouveau";
    txtLang[4].innerHTML = "En cours";
    txtLang[5].innerHTML = "Autres couleurs";
    
    document.getElementById("btnAddToCustom").value = "Ajouter \u00E0 la liste des nouvelles couleurs";
    document.getElementById("btnCancel").value = "Annuler";
    document.getElementById("btnRemove").value = " Enlever la couleur ";
    document.getElementById("btnApply").value = "Appliquer";
    document.getElementById("btnOk").value = " ok ";
    }
function getTxt (s) 
    {
      switch (s) {
        case "Use Color Name": return "Use color name";
      }    
    }
function writeTitle()
    {
    document.write("<title>Couleur</title>")
    }