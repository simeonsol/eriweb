function loadTxt()
    {
    document.getElementById("btnClose").value = "Fermer";
    }
function writeTitle()
    {
    document.write("<title>Aper\u00E7u</title>")
    }