-- --------------------------------------------------------------------------------
-- 
-- @version: 214845.sql Apr 3, 2017 20:03 gewa
-- @package Eriweb
-- @author Eriweb.com.
-- @copyright 2010
-- 
-- --------------------------------------------------------------------------------
-- Host: localhost
-- Database: 214845
-- Time: Apr 3, 2017-20:03
-- MySQL version: 5.5.32
-- PHP version: 5.4.17
-- --------------------------------------------------------------------------------

#
# Database: `214845`
#


-- --------------------------------------------------
# -- Table structure for table `email_templates`
-- --------------------------------------------------
DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE `email_templates` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `name_sa` varchar(200) NOT NULL,
  `name_er` varchar(200) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `subject_sa` varchar(255) NOT NULL,
  `subject_er` varchar(255) NOT NULL,
  `help` text,
  `help_sa` text,
  `help_er` text,
  `body` text,
  `body_sa` text,
  `body_er` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `email_templates`
-- --------------------------------------------------

INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('1', 'Registration Email', 'Registration Email', 'Registration Email', 'Please verify your email', 'Please verify your email', 'Please verify your email', 'This template is used to send Registration Verification Email, when Configuration->Registration Verification is set to YES', 'This template is used to send Registration Verification Email, when Configuration->Registration Verification is set to YES', 'This template is used to send Registration Verification Email, when Configuration->Registration Verification is set to YES', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;         &lt;hr /&gt;\n            The administrator of this site has requested all new accounts&lt;br /&gt;\n            to be activated by the users who created them thus your account&lt;br /&gt;\n            is currently inactive. To activate your account,&lt;br /&gt;\n            please visit the link below and enter the following:&lt;hr /&gt;\n            Token: &lt;strong&gt;[TOKEN]&lt;/strong&gt;&lt;br /&gt;\n            Email: &lt;strong&gt;[EMAIL]&lt;/strong&gt;         &lt;hr /&gt;\n            &lt;a href=&quot;[LINK]&quot;&gt;Click here to activate tour account&lt;/a&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;         &lt;hr /&gt;\n            The administrator of this site has requested all new accounts&lt;br /&gt;\n            to be activated by the users who created them thus your account&lt;br /&gt;\n            is currently inactive. To activate your account,&lt;br /&gt;\n            please visit the link below and enter the following:&lt;hr /&gt;\n            Token: &lt;strong&gt;[TOKEN]&lt;/strong&gt;&lt;br /&gt;\n            Email: &lt;strong&gt;[EMAIL]&lt;/strong&gt;         &lt;hr /&gt;\n            &lt;a href=&quot;[LINK]&quot;&gt;Click here to activate tour account&lt;/a&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;         &lt;hr /&gt;\n            The administrator of this site has requested all new accounts&lt;br /&gt;\n            to be activated by the users who created them thus your account&lt;br /&gt;\n            is currently inactive. To activate your account,&lt;br /&gt;\n            please visit the link below and enter the following:&lt;hr /&gt;\n            Token: &lt;strong&gt;[TOKEN]&lt;/strong&gt;&lt;br /&gt;\n            Email: &lt;strong&gt;[EMAIL]&lt;/strong&gt;         &lt;hr /&gt;\n            &lt;a href=&quot;[LINK]&quot;&gt;Click here to activate tour account&lt;/a&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('2', 'Forgot Password Email', 'Forgot Password Email', 'Forgot Password Email', 'Password Reset', 'Password Reset', 'Password Reset', 'This template is used for retrieving lost user password', 'This template is used for retrieving lost user password', 'This template is used for retrieving lost user password', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;New password reset from [SITE_NAME]!&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello, &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            It seems that you or someone requested a new password for you.&lt;br /&gt;\n            We have generated a new password, as requested:&lt;br /&gt;\n            &lt;br /&gt;\n            Your new password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            To use the new password you need to activate it. To do this click the link provided below and login with your new password.&lt;br /&gt;\n            &lt;a href=&quot;[LINK]&quot;&gt;[LINK]&lt;/a&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            You can change your password after you sign in.&lt;hr /&gt;\n            Password requested from IP: [IP]&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;New password reset from [SITE_NAME]!&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello, &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            It seems that you or someone requested a new password for you.&lt;br /&gt;\n            We have generated a new password, as requested:&lt;br /&gt;\n            &lt;br /&gt;\n            Your new password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            To use the new password you need to activate it. To do this click the link provided below and login with your new password.&lt;br /&gt;\n            &lt;a href=&quot;[LINK]&quot;&gt;[LINK]&lt;/a&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            You can change your password after you sign in.&lt;hr /&gt;\n            Password requested from IP: [IP]&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;New password reset from [SITE_NAME]!&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello, &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            It seems that you or someone requested a new password for you.&lt;br /&gt;\n            We have generated a new password, as requested:&lt;br /&gt;\n            &lt;br /&gt;\n            Your new password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            To use the new password you need to activate it. To do this click the link provided below and login with your new password.&lt;br /&gt;\n            &lt;a href=&quot;[LINK]&quot;&gt;[LINK]&lt;/a&gt;&lt;br /&gt;\n            &lt;br /&gt;\n            You can change your password after you sign in.&lt;hr /&gt;\n            Password requested from IP: [IP]&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('3', 'Welcome Mail From Admin', 'Welcome Mail From Admin', 'Welcome Mail From Admin', 'You have been registered', 'You have been registered', 'You have been registered', 'This template is used to send welcome email, when user is added by administrator', 'This template is used to send welcome email, when user is added by administrator', 'This template is used to send welcome email, when user is added by administrator', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! You have been Registered.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! You have been Registered.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! You have been Registered.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('4', 'Default Newsletter', 'Default Newsletter', 'Default Newsletter', 'Newsletter', 'Newsletter', 'Newsletter', 'This is a default newsletter template', 'This is a default newsletter template', 'This is a default newsletter template', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello [NAME]!&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You are receiving this email as a part of your newsletter subscription.         &lt;hr /&gt;\n            Here goes your newsletter content         &lt;hr /&gt;\n            &lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;         &lt;hr /&gt;\n            &lt;span style=&quot;font-size: 11px;&quot;&gt;&lt;em&gt;To stop receiving future newsletters please login into your account         and uncheck newsletter subscription box.&lt;/em&gt;&lt;/span&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello [NAME]!&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You are receiving this email as a part of your newsletter subscription.         &lt;hr /&gt;\n            Here goes your newsletter content         &lt;hr /&gt;\n            &lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;         &lt;hr /&gt;\n            &lt;span style=&quot;font-size: 11px;&quot;&gt;&lt;em&gt;To stop receiving future newsletters please login into your account         and uncheck newsletter subscription box.&lt;/em&gt;&lt;/span&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello [NAME]!&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You are receiving this email as a part of your newsletter subscription.         &lt;hr /&gt;\n            Here goes your newsletter content         &lt;hr /&gt;\n            &lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;         &lt;hr /&gt;\n            &lt;span style=&quot;font-size: 11px;&quot;&gt;&lt;em&gt;To stop receiving future newsletters please login into your account         and uncheck newsletter subscription box.&lt;/em&gt;&lt;/span&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('5', 'Transaction Completed', 'Transaction Completed', 'Transaction Completed', 'Payment Completed', 'Payment Completed', 'Payment Completed', 'This template is used to notify administrator on successful payment transaction', 'This template is used to notify administrator on successful payment transaction', 'This template is used to notify administrator on successful payment transaction', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have received new payment following:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Membership: &lt;strong&gt;[ITEMNAME]&lt;/strong&gt;&lt;br /&gt;\n            Price: &lt;strong&gt;[PRICE]&lt;/strong&gt;&lt;br /&gt;\n            Status: &lt;strong&gt;[STATUS] &lt;/strong&gt;&lt;br /&gt;\r\n            Processor: &lt;strong&gt;[PP] &lt;/strong&gt;&lt;br /&gt;\n            IP: &lt;strong&gt;[IP] &lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;&lt;em&gt;You can view this transaction from your admin panel&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have received new payment following:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Membership: &lt;strong&gt;[ITEMNAME]&lt;/strong&gt;&lt;br /&gt;\n            Price: &lt;strong&gt;[PRICE]&lt;/strong&gt;&lt;br /&gt;\n            Status: &lt;strong&gt;[STATUS] &lt;/strong&gt;&lt;br /&gt;\r\n            Processor: &lt;strong&gt;[PP] &lt;/strong&gt;&lt;br /&gt;\n            IP: &lt;strong&gt;[IP] &lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;&lt;em&gt;You can view this transaction from your admin panel&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have received new payment following:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Membership: &lt;strong&gt;[ITEMNAME]&lt;/strong&gt;&lt;br /&gt;\n            Price: &lt;strong&gt;[PRICE]&lt;/strong&gt;&lt;br /&gt;\n            Status: &lt;strong&gt;[STATUS] &lt;/strong&gt;&lt;br /&gt;\r\n            Processor: &lt;strong&gt;[PP] &lt;/strong&gt;&lt;br /&gt;\n            IP: &lt;strong&gt;[IP] &lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;&lt;em&gt;You can view this transaction from your admin panel&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('6', 'Transaction Suspicious', 'Transaction Suspicious', 'Transaction Suspicious', 'Suspicious Transaction', 'Suspicious Transaction', 'Suspicious Transaction', 'This template is used to notify administrator on failed/suspicious payment transaction', 'This template is used to notify administrator on failed/suspicious payment transaction', 'This template is used to notify administrator on failed/suspicious payment transaction', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color:#ccc&quot;&gt;Hello, Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align:left&quot;&gt;The following transaction has been disabled due to suspicious activity:&lt;br /&gt;\n            &lt;br /&gt;\n            Buyer: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Item: &lt;strong&gt;[ITEM]&lt;/strong&gt;&lt;br /&gt;\n            Price: &lt;strong&gt;[PRICE]&lt;/strong&gt;&lt;br /&gt;\n            Status: &lt;strong&gt;[STATUS]&lt;/strong&gt;&lt;/td&gt;\r\n            Processor: &lt;strong&gt;[PP] &lt;/strong&gt;&lt;br /&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align:left&quot;&gt;&lt;em&gt;Please verify this transaction is correct. If it is, please activate it in the transaction section of your site&#039;s &lt;br /&gt;\n            administration control panel. If not, it appears that someone tried to fraudulently obtain products from your site.&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color:#ccc&quot;&gt;Hello, Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align:left&quot;&gt;The following transaction has been disabled due to suspicious activity:&lt;br /&gt;\n            &lt;br /&gt;\n            Buyer: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Item: &lt;strong&gt;[ITEM]&lt;/strong&gt;&lt;br /&gt;\n            Price: &lt;strong&gt;[PRICE]&lt;/strong&gt;&lt;br /&gt;\n            Status: &lt;strong&gt;[STATUS]&lt;/strong&gt;&lt;/td&gt;\r\n            Processor: &lt;strong&gt;[PP] &lt;/strong&gt;&lt;br /&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align:left&quot;&gt;&lt;em&gt;Please verify this transaction is correct. If it is, please activate it in the transaction section of your site&#039;s &lt;br /&gt;\n            administration control panel. If not, it appears that someone tried to fraudulently obtain products from your site.&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color:#ccc&quot;&gt;Hello, Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align:left&quot;&gt;The following transaction has been disabled due to suspicious activity:&lt;br /&gt;\n            &lt;br /&gt;\n            Buyer: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Item: &lt;strong&gt;[ITEM]&lt;/strong&gt;&lt;br /&gt;\n            Price: &lt;strong&gt;[PRICE]&lt;/strong&gt;&lt;br /&gt;\n            Status: &lt;strong&gt;[STATUS]&lt;/strong&gt;&lt;/td&gt;\r\n            Processor: &lt;strong&gt;[PP] &lt;/strong&gt;&lt;br /&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align:left&quot;&gt;&lt;em&gt;Please verify this transaction is correct. If it is, please activate it in the transaction section of your site&#039;s &lt;br /&gt;\n            administration control panel. If not, it appears that someone tried to fraudulently obtain products from your site.&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('7', 'Welcome Email', 'Welcome Email', 'Welcome Email', 'Welcome', 'Welcome', 'Welcome', 'This template is used to welcome newly registered user when Configuration->Registration Verification and Configuration->Auto Registration are both set to YES', 'This template is used to welcome newly registered user when Configuration->Registration Verification and Configuration->Auto Registration are both set to YES', 'This template is used to welcome newly registered user when Configuration->Registration Verification and Configuration->Auto Registration are both set to YES', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('8', 'Membership Expire 7 days', 'Membership Expire 7 days', 'Membership Expire 7 days', 'Your membership will expire in 7 days', 'Your membership will expire in 7 days', 'Your membership will expire in 7 days', 'This template is used to remind user that membership will expire in 7 days', 'This template is used to remind user that membership will expire in 7 days', 'This template is used to remind user that membership will expire in 7 days', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, [NAME]&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;\n            &lt;h2 style=&quot;color: rgb(255, 0, 0);&quot;&gt;Your current membership will expire in 7 days&lt;/h2&gt;\n            Please login to your user panel to extend or upgrade your membership.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, [NAME]&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;\n            &lt;h2 style=&quot;color: rgb(255, 0, 0);&quot;&gt;Your current membership will expire in 7 days&lt;/h2&gt;\n            Please login to your user panel to extend or upgrade your membership.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, [NAME]&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;\n            &lt;h2 style=&quot;color: rgb(255, 0, 0);&quot;&gt;Your current membership will expire in 7 days&lt;/h2&gt;\n            Please login to your user panel to extend or upgrade your membership.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('9', 'Membership expired today', 'Membership expired today', 'Membership expired today', 'Your membership has expired', 'Your membership has expired', 'Your membership has expired', 'This template is used to remind user that membership had expired', 'This template is used to remind user that membership had expired', 'This template is used to remind user that membership had expired', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, [NAME]&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;\n            &lt;h2 style=&quot;color: rgb(255, 0, 0);&quot;&gt;Your current membership has expired!&lt;/h2&gt;\n            Please login to your user panel to extend or upgrade your membership.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, [NAME]&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;\n            &lt;h2 style=&quot;color: rgb(255, 0, 0);&quot;&gt;Your current membership has expired!&lt;/h2&gt;\n            Please login to your user panel to extend or upgrade your membership.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello, [NAME]&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;\n            &lt;h2 style=&quot;color: rgb(255, 0, 0);&quot;&gt;Your current membership has expired!&lt;/h2&gt;\n            Please login to your user panel to extend or upgrade your membership.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('10', 'Contact Request', 'Contact Request', 'Contact Request', 'Contact Inquiry', 'Contact Inquiry', 'Contact Inquiry', 'This template is used to send default Contact Request Form', 'This template is used to send default Contact Request Form', 'This template is used to send default Contact Request Form', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new contact request:         &lt;hr /&gt;\n            [MESSAGE]         &lt;hr /&gt;\n            From: &lt;strong&gt;[SENDER] - [NAME]&lt;/strong&gt;&lt;br /&gt;\n            Subject: &lt;strong&gt;[MAILSUBJECT]&lt;/strong&gt;&lt;br /&gt;\n            Senders IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new contact request:         &lt;hr /&gt;\n            [MESSAGE]         &lt;hr /&gt;\n            From: &lt;strong&gt;[SENDER] - [NAME]&lt;/strong&gt;&lt;br /&gt;\n            Subject: &lt;strong&gt;[MAILSUBJECT]&lt;/strong&gt;&lt;br /&gt;\n            Senders IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new contact request:         &lt;hr /&gt;\n            [MESSAGE]         &lt;hr /&gt;\n            From: &lt;strong&gt;[SENDER] - [NAME]&lt;/strong&gt;&lt;br /&gt;\n            Subject: &lt;strong&gt;[MAILSUBJECT]&lt;/strong&gt;&lt;br /&gt;\n            Senders IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('11', 'New Comment', 'New Comment', 'New Comment', 'New Comment Added', 'New Comment Added', 'New Comment Added', 'This template is used to notify admin when new comment has been added', 'This template is used to notify admin when new comment has been added', 'This template is used to notify admin when new comment has been added', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new comment post. You can login into your admin panel to view details:         &lt;hr /&gt;\n            [MESSAGE]         &lt;hr /&gt;\n            From: &lt;strong&gt;[SENDER] - [NAME]&lt;/strong&gt;&lt;br /&gt;\n            www: &lt;strong&gt;[WWW]&lt;/strong&gt;&lt;br /&gt;\n            Page Url: &lt;strong&gt;&lt;a href=&quot;[PAGEURL]&quot;&gt;[PAGEURL]&lt;/a&gt;&lt;/strong&gt;&lt;br /&gt;\n            Senders IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new comment post. You can login into your admin panel to view details:         &lt;hr /&gt;\n            [MESSAGE]         &lt;hr /&gt;\n            From: &lt;strong&gt;[SENDER] - [NAME]&lt;/strong&gt;&lt;br /&gt;\n            www: &lt;strong&gt;[WWW]&lt;/strong&gt;&lt;br /&gt;\n            Page Url: &lt;strong&gt;&lt;a href=&quot;[PAGEURL]&quot;&gt;[PAGEURL]&lt;/a&gt;&lt;/strong&gt;&lt;br /&gt;\n            Senders IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new comment post. You can login into your admin panel to view details:         &lt;hr /&gt;\n            [MESSAGE]         &lt;hr /&gt;\n            From: &lt;strong&gt;[SENDER] - [NAME]&lt;/strong&gt;&lt;br /&gt;\n            www: &lt;strong&gt;[WWW]&lt;/strong&gt;&lt;br /&gt;\n            Page Url: &lt;strong&gt;&lt;a href=&quot;[PAGEURL]&quot;&gt;[PAGEURL]&lt;/a&gt;&lt;/strong&gt;&lt;br /&gt;\n            Senders IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('12', 'Single Email', 'Single Email', 'Single Email', 'Single User Email', 'Single User Email', 'Single User Email', 'This template is used to email single user', 'This template is used to email single user', 'This template is used to email single user', '&lt;div align=&quot;center&quot;&gt;\n  &lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n      &lt;tr&gt;\n        &lt;th style=&quot;background-color:#ccc&quot;&gt;Hello [NAME]&lt;/th&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td valign=&quot;top&quot; style=&quot;text-align:left&quot;&gt;Your message goes here...&lt;/td&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td style=&quot;text-align:left&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n          [SITE_NAME] Team&lt;br /&gt;\n          &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n      &lt;/tr&gt;\n    &lt;/tbody&gt;\n  &lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n  &lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n      &lt;tr&gt;\n        &lt;th style=&quot;background-color:#ccc&quot;&gt;Hello [NAME]&lt;/th&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td valign=&quot;top&quot; style=&quot;text-align:left&quot;&gt;Your message goes here...&lt;/td&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td style=&quot;text-align:left&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n          [SITE_NAME] Team&lt;br /&gt;\n          &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n      &lt;/tr&gt;\n    &lt;/tbody&gt;\n  &lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n  &lt;table width=&quot;600&quot; cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n      &lt;tr&gt;\n        &lt;th style=&quot;background-color:#ccc&quot;&gt;Hello [NAME]&lt;/th&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td valign=&quot;top&quot; style=&quot;text-align:left&quot;&gt;Your message goes here...&lt;/td&gt;\n      &lt;/tr&gt;\n      &lt;tr&gt;\n        &lt;td style=&quot;text-align:left&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n          [SITE_NAME] Team&lt;br /&gt;\n          &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n      &lt;/tr&gt;\n    &lt;/tbody&gt;\n  &lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('13', 'Notify Admin', 'Notify Admin', 'Notify Admin', 'New User Registration', 'New User Registration', 'New User Registration', 'This template is used to notify admin of new registration when Configuration->Registration Notification is set to YES', 'This template is used to notify admin of new registration when Configuration->Registration Notification is set to YES', 'This template is used to notify admin of new registration when Configuration->Registration Notification is set to YES', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new user registration. You can login into your admin panel to view details:&lt;hr /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Name: &lt;strong&gt;[NAME]&lt;/strong&gt;&lt;br /&gt;\n            IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new user registration. You can login into your admin panel to view details:&lt;hr /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Name: &lt;strong&gt;[NAME]&lt;/strong&gt;&lt;br /&gt;\n            IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Hello Admin&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;You have a new user registration. You can login into your admin panel to view details:&lt;hr /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Name: &lt;strong&gt;[NAME]&lt;/strong&gt;&lt;br /&gt;\n            IP: &lt;strong&gt;[IP]&lt;/strong&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');
INSERT INTO `email_templates` (`id`, `name`, `name_sa`, `name_er`, `subject`, `subject_sa`, `subject_er`, `help`, `help_sa`, `help_er`, `body`, `body_sa`, `body_er`) VALUES ('14', 'Registration Pending', 'Registration Pending', 'Registration Pending', 'Registration Verification Pending', 'Registration Verification Pending', 'Registration Verification Pending', 'This template is used to send Registration Verification Email, when Configuration->Auto Registration is set to NO', 'This template is used to send Registration Verification Email, when Configuration->Auto Registration is set to NO', 'This template is used to send Registration Verification Email, when Configuration->Auto Registration is set to NO', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;         &lt;hr /&gt;\n            The administrator of this site has requested all new accounts&lt;br /&gt;\n            to be activated by the users who created them thus your account&lt;br /&gt;\n            is currently pending verification process.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;         &lt;hr /&gt;\n            The administrator of this site has requested all new accounts&lt;br /&gt;\n            to be activated by the users who created them thus your account&lt;br /&gt;\n            is currently pending verification process.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;', '&lt;div align=&quot;center&quot;&gt;\n&lt;table cellspacing=&quot;5&quot; cellpadding=&quot;5&quot; border=&quot;0&quot; width=&quot;600&quot; style=&quot;background: none repeat scroll 0% 0% rgb(244, 244, 244); border: 1px solid rgb(102, 102, 102);&quot;&gt;\n    &lt;tbody&gt;\n        &lt;tr&gt;\n            &lt;th style=&quot;background-color: rgb(204, 204, 204);&quot;&gt;Welcome [NAME]! Thanks for registering.&lt;/th&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td valign=&quot;top&quot; style=&quot;text-align: left;&quot;&gt;Hello,&lt;br /&gt;\n            &lt;br /&gt;\n            You&#039;re now a member of [SITE_NAME].&lt;br /&gt;\n            &lt;br /&gt;\n            Here are your login details. Please keep them in a safe place:&lt;br /&gt;\n            &lt;br /&gt;\n            Username: &lt;strong&gt;[USERNAME]&lt;/strong&gt;&lt;br /&gt;\n            Password: &lt;strong&gt;[PASSWORD]&lt;/strong&gt;         &lt;hr /&gt;\n            The administrator of this site has requested all new accounts&lt;br /&gt;\n            to be activated by the users who created them thus your account&lt;br /&gt;\n            is currently pending verification process.&lt;/td&gt;\n        &lt;/tr&gt;\n        &lt;tr&gt;\n            &lt;td style=&quot;text-align: left;&quot;&gt;&lt;em&gt;Thanks,&lt;br /&gt;\n            [SITE_NAME] Team&lt;br /&gt;\n            &lt;a href=&quot;[URL]&quot;&gt;[URL]&lt;/a&gt;&lt;/em&gt;&lt;/td&gt;\n        &lt;/tr&gt;\n    &lt;/tbody&gt;\n&lt;/table&gt;\n&lt;/div&gt;');


-- --------------------------------------------------
# -- Table structure for table `flds`
-- --------------------------------------------------
DROP TABLE IF EXISTS `flds`;
CREATE TABLE `flds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_id` int(6) NOT NULL DEFAULT '0',
  `title` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `fld_type` int(2) DEFAULT NULL,
  `fld_size` int(3) DEFAULT NULL,
  `position` int(8) DEFAULT NULL,
  `fld_val` text,
  `fld_req` tinyint(1) NOT NULL DEFAULT '0',
  `fld_msg` varchar(200) DEFAULT NULL,
  `fld_tip` text,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `flds`
-- --------------------------------------------------



-- --------------------------------------------------
# -- Table structure for table `forms`
-- --------------------------------------------------
DROP TABLE IF EXISTS `forms`;
CREATE TABLE `forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) DEFAULT NULL,
  `subject` varchar(200) DEFAULT NULL,
  `thankyou` text NOT NULL,
  `mailto` varchar(150) DEFAULT NULL,
  `submit` varchar(50) DEFAULT NULL,
  `captcha` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `forms`
-- --------------------------------------------------



-- --------------------------------------------------
# -- Table structure for table `gallery`
-- --------------------------------------------------
DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `folder` varchar(30) DEFAULT NULL,
  `rows` int(4) NOT NULL DEFAULT '0',
  `thumb_w` int(4) NOT NULL DEFAULT '0',
  `thumb_h` int(4) NOT NULL DEFAULT '0',
  `image_w` int(4) NOT NULL DEFAULT '0',
  `image_h` int(4) NOT NULL DEFAULT '0',
  `watermark` tinyint(1) NOT NULL DEFAULT '0',
  `method` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `gallery`
-- --------------------------------------------------

INSERT INTO `gallery` (`id`, `title`, `folder`, `rows`, `thumb_w`, `thumb_h`, `image_w`, `image_h`, `watermark`, `method`, `created`) VALUES ('1', 'Demo Gallery', 'demo', '5', '150', '150', '600', '600', '1', '1', '2010-12-10 12:10:10');


-- --------------------------------------------------
# -- Table structure for table `gallery_images`
-- --------------------------------------------------
DROP TABLE IF EXISTS `gallery_images`;
CREATE TABLE `gallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_id` int(6) NOT NULL DEFAULT '0',
  `title` varchar(100) DEFAULT NULL,
  `desc` varchar(250) DEFAULT NULL,
  `thumb` varchar(100) DEFAULT NULL,
  `sorting` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `gallery_images`
-- --------------------------------------------------

INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('1', '1', 'Demo Flower 1', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_318C0B-0F1A63-7096C7-45B182-87004D-FDF0AE.jpg', '1');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('2', '1', 'Demo Flower 2', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_D45A84-11B3CB-E2E617-8CE590-EB95CB-4C40CF.jpg', '2');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('3', '1', 'Demo Flower 3', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_07264C-30F255-F8E444-C90DC8-093AE6-C83DF4.jpg', '3');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('4', '1', 'Demo Flower 4', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_2822AC-941D16-C5ECEB-4C2787-015575-77FEE8.jpg', '4');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('5', '1', 'Demo Flower 5', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_260FA3-1C8BE1-890AFD-8F20ED-47EB05-EBDFF7.jpg', '5');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('6', '1', 'Demo Flower 6', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_755459-EC4B6C-58E134-2907AA-36BFEC-2604A5.jpg', '6');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('7', '1', 'Demo Flower 7', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_7810C6-0B129B-B97C0D-902867-748A5F-854706.jpg', '8');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('8', '1', 'Demo Flower 8', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_901142-405DB2-4B327C-6418D7-B92E53-CC1FA7.jpg', '9');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('9', '1', 'Demo Flower 9', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_F87715-1EAFB8-D4E516-77E233-215B0A-507EBB.jpg', '10');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('10', '1', 'Demo Flower 10', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_0D08C0-3FFF26-A5D741-BA76C6-F3C61F-D67093.jpg', '11');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('11', '1', 'Demo Flower 11', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_807CA0-B0AB7C-FF9BB6-E4E678-B9A38A-7A81FB.jpg', '12');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('12', '1', 'Demo Flower 12', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_7CF0A7-55F94C-0B0AE0-A4BF0C-476BF7-82CCE0.jpg', '13');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('13', '1', 'Demo Flower 13', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_E1A872-9BDEED-5CA577-3CA6F1-E2545B-DBCF15.jpg', '14');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('14', '1', 'Demo Flower 14', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_2D4A9D-9D3E9E-047D5A-49CC85-4B02A6-1F3BB6.jpg', '15');
INSERT INTO `gallery_images` (`id`, `gallery_id`, `title`, `desc`, `thumb`, `sorting`) VALUES ('15', '1', 'Demo Flower 15', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_886FAF-5199A3-9758FB-406A40-59CDF0-C5C3C9.jpg', '7');


-- --------------------------------------------------
# -- Table structure for table `gateways`
-- --------------------------------------------------
DROP TABLE IF EXISTS `gateways`;
CREATE TABLE `gateways` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `displayname` varchar(255) NOT NULL,
  `dir` varchar(255) NOT NULL,
  `demo` tinyint(1) NOT NULL DEFAULT '1',
  `extra_txt` varchar(255) NOT NULL,
  `extra_txt2` varchar(255) NOT NULL,
  `extra_txt3` varchar(255) DEFAULT NULL,
  `extra` varchar(255) NOT NULL,
  `extra2` varchar(255) NOT NULL,
  `extra3` varchar(255) DEFAULT NULL,
  `is_recurring` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `gateways`
-- --------------------------------------------------

INSERT INTO `gateways` (`id`, `name`, `displayname`, `dir`, `demo`, `extra_txt`, `extra_txt2`, `extra_txt3`, `extra`, `extra2`, `extra3`, `is_recurring`, `active`) VALUES ('1', 'paypal', 'PayPal', 'paypal', '0', 'Email Address', 'Currency Code', 'Not in Use', 'paypal@address.com', 'CAD', '', '1', '1');
INSERT INTO `gateways` (`id`, `name`, `displayname`, `dir`, `demo`, `extra_txt`, `extra_txt2`, `extra_txt3`, `extra`, `extra2`, `extra3`, `is_recurring`, `active`) VALUES ('2', 'moneybookers', 'MoneyBookers', 'moneybookers', '1', 'Email Address', 'Currency Code', 'Secret Passphrase', 'moneybookers@address.com', 'EUR', 'mypassphrase', '1', '1');


-- --------------------------------------------------
# -- Table structure for table `language`
-- --------------------------------------------------
DROP TABLE IF EXISTS `language`;
CREATE TABLE `language` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `name_sa` varchar(100) DEFAULT NULL,
  `name_er` varchar(100) DEFAULT NULL,
  `flag` varchar(2) DEFAULT NULL,
  `author` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `language`
-- --------------------------------------------------

INSERT INTO `language` (`id`, `name`, `name_sa`, `name_er`, `flag`, `author`) VALUES ('1', 'English', 'English', 'English', 'en', 'http://www.Eriweb.com');
INSERT INTO `language` (`id`, `name`, `name_sa`, `name_er`, `flag`, `author`) VALUES ('5', 'ትግርኛ', 'ትግርኛ', 'ትግርኛ', 'er', 'www.eriweb.eu5.org');
INSERT INTO `language` (`id`, `name`, `name_sa`, `name_er`, `flag`, `author`) VALUES ('6', 'العربية', 'العربية', 'العربية', 'sa', 'www.eriweb.eu5.org');


-- --------------------------------------------------
# -- Table structure for table `layout`
-- --------------------------------------------------
DROP TABLE IF EXISTS `layout`;
CREATE TABLE `layout` (
  `module_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL,
  `place` varchar(20) NOT NULL,
  `position` int(11) NOT NULL,
  KEY `idx_layout_id` (`page_id`),
  KEY `idx_plugin_id` (`module_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `layout`
-- --------------------------------------------------

INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '6', 'left', '5');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '2', 'right', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('1', '2', 'right', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '3', 'left', '15');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('14', '3', 'left', '14');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('8', '6', 'right', '8');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('9', '6', 'left', '7');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('11', '6', 'bottom', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('10', '6', 'bottom', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('3', '7', 'left', '7');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('5', '7', 'bottom', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('9', '7', 'left', '5');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('8', '7', 'right', '8');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('4', '7', 'left', '6');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('10', '7', 'bottom', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('1', '7', 'top', '3');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('11', '7', 'top', '4');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('6', '1', 'top', '15');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('4', '6', 'left', '6');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('11', '1', 'bottom', '16');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('1', '8', 'right', '8');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('4', '8', 'right', '9');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('2', '8', 'right', '10');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('13', '2', 'right', '11');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('7', '6', 'top', '6');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('12', '3', 'left', '16');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('16', '5', 'bottom', '15');
INSERT INTO `layout` (`module_id`, `page_id`, `place`, `position`) VALUES ('18', '3', 'left', '13');


-- --------------------------------------------------
# -- Table structure for table `log`
-- --------------------------------------------------
DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `failed` tinyint(5) NOT NULL,
  `failed_last` int(11) NOT NULL,
  `type` enum('system','admin','user') NOT NULL,
  `message` text NOT NULL,
  `info_icon` varchar(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default',
  `importance` enum('yes','no') NOT NULL DEFAULT 'no',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=525 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `log`
-- --------------------------------------------------

INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('94', 'admin', '85.31.71.66', '2013-01-17 00:28:03', '2', '1359373317', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('2', 'admin', '85.31.71.66', '2012-12-28 06:39:15', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('3', 'admin', '85.31.71.66', '2012-12-28 06:40:03', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('4', 'admin', '85.31.71.66', '2012-12-28 06:47:08', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('6', 'admin', '85.31.71.66', '2013-01-03 01:12:54', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('7', 'admin', '85.31.71.66', '2013-01-03 01:13:55', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('8', 'admin', '85.31.71.66', '2013-01-03 01:14:06', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('9', 'admin', '85.31.71.66', '2013-01-03 01:14:20', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('10', 'admin', '85.31.71.66', '2013-01-03 01:14:34', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('11', 'admin', '85.31.71.66', '2013-01-03 01:14:44', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('12', 'admin', '85.31.71.66', '2013-01-03 01:14:59', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('13', 'admin', '85.31.71.66', '2013-01-03 01:15:18', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('14', 'admin', '85.31.71.66', '2013-01-03 01:15:29', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('15', 'admin', '85.31.71.66', '2013-01-03 01:15:41', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('16', 'admin', '85.31.71.66', '2013-01-03 01:15:56', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('17', 'admin', '85.31.71.66', '2013-01-03 01:16:10', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('18', 'admin', '85.31.71.66', '2013-01-03 01:16:22', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('93', 'admin', '85.31.71.66', '2013-01-16 08:02:35', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('20', 'admin', '85.31.71.66', '2013-01-03 01:21:17', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('21', 'admin', '85.31.71.66', '2013-01-03 01:25:18', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('22', 'admin', '85.31.71.66', '2013-01-03 01:26:34', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('23', 'admin', '85.31.71.66', '2013-01-03 01:26:56', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('24', 'admin', '85.31.71.66', '2013-01-03 01:27:21', '0', '0', 'system', '<span>Success!</span>Backup created successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('25', 'admin', '85.31.71.66', '2013-01-03 01:34:31', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('26', 'admin', '85.31.71.66', '2013-01-03 04:39:52', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('27', 'admin', '85.31.71.66', '2013-01-03 04:43:08', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('92', 'admin', '85.31.71.66', '2013-01-16 08:01:16', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('30', 'admin', '85.31.71.66', '2013-01-03 04:46:26', '0', '0', 'system', '<span>Success!</span>Module updated successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('31', 'admin', '85.31.71.66', '2013-01-03 04:57:49', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('32', 'admin', '85.31.71.66', '2013-01-03 04:58:12', '0', '0', 'system', 'Slide Image <strong>.</strong> deleted successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('33', 'admin', '85.31.71.66', '2013-01-03 04:58:48', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('34', 'admin', '85.31.71.66', '2013-01-03 04:59:05', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('35', 'admin', '85.31.71.66', '2013-01-03 04:59:25', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('36', 'admin', '85.31.71.66', '2013-01-03 04:59:49', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('37', 'admin', '85.31.71.66', '2013-01-03 05:09:19', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('38', 'admin', '85.31.71.66', '2013-01-03 05:13:09', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('39', 'admin', '85.31.71.66', '2013-01-03 05:26:07', '0', '0', 'system', '<span>Success!</span>Language Added Successfully', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('40', 'admin', '85.31.71.66', '2013-01-03 05:29:06', '0', '0', 'system', '<span>Success!</span>Language Added Successfully', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('41', 'admin', '85.31.71.66', '2013-01-03 06:00:18', '0', '0', 'system', '<span>ኣገናዕ!</span>ቋንቋ ተማዓራርዩ ኣሎ', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('42', 'admin', '85.31.71.66', '2013-01-03 06:01:03', '0', '0', 'system', 'لقد تحدث اللُّغة<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('43', 'admin', '85.31.71.66', '2013-01-03 06:02:18', '0', '0', 'system', '<span>ኣገናዕ!</span>ቋንቋ ተማዓራርዩ ኣሎ', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('44', 'admin', '85.31.71.66', '2013-01-03 06:05:38', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('45', 'admin', '85.31.71.66', '2013-01-03 06:07:39', '0', '0', 'system', '!تحديث فحوة الصفحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('46', 'admin', '85.31.71.66', '2013-01-03 06:08:20', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('47', 'admin', '85.31.71.66', '2013-01-03 06:09:40', '0', '0', 'system', '!تحديث فحوة الصفحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('48', 'admin', '85.31.71.66', '2013-01-03 06:22:05', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('49', 'admin', '85.31.71.66', '2013-01-03 06:37:22', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('50', 'admin', '85.31.71.66', '2013-01-03 06:40:03', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('51', 'admin', '85.31.71.66', '2013-01-03 06:43:34', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('52', 'admin', '85.31.71.66', '2013-01-03 06:44:50', '0', '0', 'system', '!تحديث فحوة الصفحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('53', 'admin', '85.31.71.66', '2013-01-03 06:45:07', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('54', 'admin', '85.31.71.66', '2013-01-03 06:49:45', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('55', 'admin', '85.31.71.66', '2013-01-03 06:51:29', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('56', 'admin', '85.31.71.66', '2013-01-03 06:53:08', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('57', 'admin', '85.31.71.66', '2013-01-03 06:53:45', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('58', 'admin', '85.31.71.66', '2013-01-03 06:54:34', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('59', 'admin', '85.31.71.66', '2013-01-03 06:55:23', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('60', 'admin', '85.31.71.66', '2013-01-03 06:56:01', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('61', 'admin', '85.31.71.66', '2013-01-03 07:00:13', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('91', 'admin', '85.31.71.66', '2013-01-16 07:55:52', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('63', 'admin', '85.31.71.66', '2013-01-03 07:13:09', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('64', 'admin', '85.31.71.66', '2013-01-03 07:14:41', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('65', 'admin', '85.31.71.66', '2013-01-03 07:16:34', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('66', 'admin', '85.31.71.66', '2013-01-03 07:23:09', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('67', 'admin', '85.31.71.66', '2013-01-03 07:23:52', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('68', 'admin', '85.31.71.66', '2013-01-03 07:24:07', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('70', 'admin', '85.31.71.66', '2013-01-04 08:15:28', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('71', 'admin', '85.31.71.66', '2013-01-04 08:27:46', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('90', 'admin', '85.31.71.66', '2013-01-16 07:53:42', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('74', 'admin', '85.31.71.66', '2013-01-10 06:49:23', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('89', 'admin', '85.31.71.66', '2013-01-16 07:51:57', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('88', 'admin', '85.31.71.66', '2013-01-16 07:49:06', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('87', 'admin', '85.31.71.66', '2013-01-16 07:40:35', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('79', 'admin', '85.31.71.66', '2013-01-10 07:09:32', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('86', 'admin', '85.31.71.66', '2013-01-16 07:38:22', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('82', 'admin', '85.31.71.66', '2013-01-10 08:28:30', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተወሲኹ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('83', 'admin', '85.31.71.66', '2013-01-10 08:29:51', '0', '0', 'system', 'ስላይድ ስእሊ <strong>cc</strong> ተደምሲሱ!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('85', 'admin', '85.31.71.66', '2013-01-16 07:28:26', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('95', 'admin', '85.31.71.66', '2013-01-17 00:32:52', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('96', 'admin', '85.31.71.66', '2013-01-17 00:47:40', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('97', 'admin', '85.31.71.66', '2013-01-17 00:54:45', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('98', 'admin', '85.31.71.66', '2013-01-17 00:57:16', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('99', 'admin', '85.31.71.66', '2013-01-17 00:57:32', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('100', 'admin', '85.31.71.66', '2013-01-17 00:57:47', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('101', 'admin', '85.31.71.66', '2013-01-17 00:58:11', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('102', 'admin', '85.31.71.66', '2013-01-17 00:58:24', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('103', 'admin', '85.31.71.66', '2013-01-17 00:58:40', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('104', 'admin', '85.31.71.66', '2013-01-17 00:58:53', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('105', 'admin', '85.31.71.66', '2013-01-17 00:59:14', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('106', 'admin', '85.31.71.66', '2013-01-17 00:59:34', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('107', 'admin', '85.31.71.66', '2013-01-17 00:59:48', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('108', 'admin', '85.31.71.66', '2013-01-17 01:00:00', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('109', 'admin', '85.31.71.66', '2013-01-17 01:11:54', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('110', 'admin', '85.31.71.66', '2013-01-17 01:13:53', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('111', 'admin', '85.31.71.66', '2013-01-17 01:14:38', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('112', 'admin', '85.31.71.66', '2013-01-17 01:16:58', '0', '0', 'system', '<span>ኣገናዕ!</span>ሞድዩል ተመዓራርዩ ኣሎ!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('113', 'admin', '85.31.71.66', '2013-01-28 03:29:49', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('114', 'admin', '85.31.71.66', '2013-01-28 05:42:13', '0', '0', 'user', ' مُستخدم  admin قد دخل بنجاح', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('115', 'admin', '85.31.71.66', '2013-01-28 05:46:05', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('116', 'admin', '85.31.71.66', '2013-01-28 05:49:55', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('117', 'admin', '85.31.71.66', '2013-01-28 05:50:55', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('118', 'admin', '85.31.71.66', '2013-01-28 05:52:50', '0', '0', 'system', '<span>Success!</span>Module updated successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('119', 'admin', '85.31.71.66', '2013-01-28 05:53:40', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('120', 'admin', '85.31.71.66', '2013-01-28 05:55:53', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('121', 'admin', '85.31.71.66', '2013-01-28 05:56:32', '0', '0', 'system', '<span>ኣገናዕ!</span>ሞድዩል ተመዓራርዩ ኣሎ!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('122', 'admin', '85.31.71.66', '2013-01-28 05:57:46', '0', '0', 'user', ' مُستخدم  admin قد دخل بنجاح', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('123', 'admin', '85.31.71.66', '2013-01-28 06:04:32', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('124', 'admin', '85.31.71.66', '2013-01-28 06:05:47', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('125', 'admin', '85.31.71.66', '2013-02-01 02:03:25', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('126', 'admin', '85.31.71.66', '2013-02-01 02:09:09', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('127', 'admin', '85.31.71.66', '2013-02-01 02:11:01', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('128', 'admin', '85.31.71.66', '2013-03-22 07:23:03', '0', '0', 'user', ' مُستخدم  admin قد دخل بنجاح', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('129', 'admin', '85.31.71.66', '2013-03-22 07:25:10', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('130', 'admin', '85.31.71.66', '2013-04-30 03:02:20', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('131', 'admin', '85.31.71.66', '2013-04-30 03:04:56', '0', '0', 'system', '<span>Success!</span>Content Page added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('132', 'admin', '85.31.71.66', '2013-04-30 03:09:29', '0', '0', 'system', '<span>Success!</span>Content Post added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('133', 'admin', '85.31.71.66', '2013-04-30 03:10:53', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('134', 'admin', '85.31.71.66', '2013-04-30 03:38:57', '0', '0', 'system', '<span>Success!</span>CMS Gallery added successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('135', 'admin', '85.31.71.66', '2013-04-30 03:53:27', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('136', 'admin', '85.31.71.66', '2013-04-30 03:56:30', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('137', 'admin', '85.31.71.66', '2013-05-02 01:39:50', '0', '0', 'system', '<span>Success!</span>Content Post added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('138', 'admin', '85.31.71.66', '2013-05-02 01:41:30', '0', '0', 'system', '<span>Success!</span>Content Post added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('139', 'admin', '85.31.71.66', '2013-05-02 01:44:28', '0', '0', 'system', '<span>Success!</span>Content Post added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('140', 'admin', '85.31.71.66', '2013-05-02 01:45:15', '0', '0', 'system', '<span>Success!</span>Content Post added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('141', 'admin', '85.31.71.66', '2013-05-02 01:46:08', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('142', 'admin', '85.31.71.66', '2013-05-02 01:46:39', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('143', 'admin', '85.31.71.66', '2013-05-02 01:47:09', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('144', 'admin', '85.31.71.66', '2013-05-02 01:47:24', '0', '0', 'system', 'Post <strong>Ibrahim Body Massage and Therapy</strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('145', 'admin', '85.31.71.66', '2013-05-02 01:48:48', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('146', 'admin', '85.31.71.66', '2013-05-07 11:21:06', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('147', 'admin', '85.31.71.66', '2013-05-07 11:21:27', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('148', 'admin', '83.229.39.98', '2013-07-30 02:43:50', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('149', 'admin', '83.229.39.98', '2013-09-24 07:05:26', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('150', 'admin', '83.229.39.98', '2013-09-24 07:15:49', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('151', 'admin', '83.229.39.98', '2013-09-24 09:36:53', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('152', 'admin', '83.229.39.98', '2013-09-24 09:38:09', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('153', 'admin', '83.229.39.98', '2013-09-24 09:41:54', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('154', 'admin', '83.229.39.98', '2013-09-24 09:43:57', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('155', 'admin', '83.229.39.98', '2013-09-24 09:44:58', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('156', 'admin', '83.229.39.98', '2013-09-24 09:45:51', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('157', 'admin', '83.229.39.98', '2013-09-24 09:46:41', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ገጽ ተመዓራርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('158', 'admin', '83.229.39.98', '2013-09-24 09:47:36', '0', '0', 'user', 'ተጠቃሚ admin  ወጺኡ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('159', 'admin', '83.229.39.101', '2014-04-30 03:07:16', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('160', 'admin', '83.229.39.101', '2014-04-30 03:21:06', '0', '0', 'system', '<span>Success!</span>User added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('161', 'admin', '83.229.39.101', '2014-04-30 03:21:19', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('162', 'MasdarAdmission', '83.229.39.101', '2014-04-30 03:21:44', '0', '0', 'user', 'User MasdarAdmission has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('163', 'MasdarAdmission', '83.229.39.101', '2014-04-30 03:22:38', '0', '0', 'user', 'User MasdarAdmission has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('164', 'admin', '83.229.39.101', '2014-04-30 03:22:49', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('165', 'admin', '83.229.39.101', '2014-04-30 03:28:22', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('166', 'admin', '83.229.39.101', '2014-04-30 03:31:48', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('167', 'MasdarAdmission', '83.229.39.101', '2014-04-30 03:37:49', '0', '0', 'user', 'ተጠቃሚ MasdarAdmission  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('168', 'admin', '83.229.39.101', '2014-07-08 03:04:12', '0', '0', 'system', '<span>Success!</span>Menu added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('169', 'admin', '83.229.39.101', '2014-07-08 03:05:23', '0', '0', 'system', '<span>Success!</span>Menu added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('170', 'admin', '83.229.39.101', '2014-07-08 03:05:49', '0', '0', 'system', '<span>Success!</span>Menu added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('171', 'admin', '83.229.39.101', '2014-07-08 03:06:04', '0', '0', 'system', '<span>Success!</span>Menu added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('172', 'admin', '83.229.39.101', '2014-07-08 03:06:14', '0', '0', 'system', '<span>Success!</span>Menu added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('173', 'admin', '83.229.39.101', '2014-07-08 03:06:25', '0', '0', 'system', '<span>Success!</span>Menu added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('174', 'admin', '83.229.39.101', '2014-07-08 03:06:38', '0', '0', 'system', '<span>Success!</span>Menu added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('175', 'admin', '83.229.39.101', '2014-07-08 03:08:37', '0', '0', 'system', '<span>Success!</span>Menu added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('176', 'admin', '83.229.39.101', '2014-07-08 03:11:12', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('177', 'admin', '83.229.39.101', '2014-07-08 03:11:27', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('178', 'admin', '83.229.39.101', '2014-07-08 03:11:37', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('179', 'admin', '83.229.39.101', '2014-07-08 03:11:58', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('180', 'admin', '83.229.39.101', '2014-07-08 03:12:10', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('181', 'admin', '83.229.39.101', '2014-07-08 03:12:23', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('182', 'admin', '83.229.39.101', '2014-07-08 03:12:38', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('183', 'admin', '83.229.39.101', '2014-07-08 03:13:05', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('184', 'admin', '83.229.39.101', '2014-07-08 03:13:56', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('185', 'admin', '83.229.39.101', '2014-07-08 03:14:20', '0', '0', 'system', '<span>Success!</span>Menu updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('186', 'admin', '83.229.39.101', '2014-07-08 03:15:28', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('187', 'admin', '83.229.39.101', '2014-07-08 03:15:44', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('188', 'admin', '83.229.39.101', '2014-07-08 03:15:56', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('189', 'admin', '83.229.39.101', '2014-07-08 03:16:09', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('190', 'admin', '83.229.39.101', '2014-07-08 03:18:02', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('191', 'admin', '83.229.39.101', '2014-07-08 03:25:16', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('192', 'admin', '83.229.39.101', '2014-07-08 03:29:07', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('193', 'admin', '83.229.39.101', '2014-07-08 03:30:11', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('194', 'admin', '83.229.39.101', '2014-07-08 03:35:25', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('195', 'admin', '83.229.39.101', '2014-07-08 03:36:29', '0', '0', 'system', 'Post <strong>Savanna International Hotel - Asmara</strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('196', 'admin', '83.229.39.101', '2014-07-08 03:36:32', '0', '0', 'system', 'Post <strong>EOMS Electronics, Home Appliances</strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('197', 'admin', '83.229.39.101', '2014-07-08 03:36:36', '0', '0', 'system', 'Post <strong>Alba Bistro</strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('198', 'admin', '83.229.39.101', '2014-07-08 03:36:39', '0', '0', 'system', 'Post <strong>Ibrahim Body Massage and Therapy</strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('199', 'admin', '83.229.39.101', '2014-07-08 03:38:16', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('200', 'admin', '83.229.39.101', '2014-07-08 03:39:08', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('201', 'admin', '83.229.39.101', '2014-07-08 03:41:41', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('202', 'admin', '83.229.39.101', '2014-07-08 03:45:55', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('203', 'admin', '83.229.39.101', '2014-07-08 03:46:49', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('204', 'admin', '83.229.39.101', '2014-07-08 03:48:53', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('205', 'admin', '83.229.39.101', '2014-07-08 03:50:45', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('206', 'admin', '83.229.39.101', '2014-07-08 03:51:38', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('207', 'admin', '83.229.39.101', '2014-07-08 03:52:10', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('208', 'admin', '83.229.39.101', '2014-07-08 03:56:07', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('209', 'admin', '83.229.39.101', '2014-07-08 03:58:16', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('210', 'admin', '83.229.39.101', '2014-07-08 04:05:56', '0', '0', 'system', '<span>Success!</span>Module updated successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('211', 'admin', '83.229.39.101', '2014-07-08 04:06:46', '0', '0', 'system', '<span>Success!</span>Module updated successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('212', 'admin', '83.229.39.101', '2014-07-08 04:08:44', '0', '0', 'system', '<span>Success!</span>Module updated successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('213', 'admin', '83.229.39.101', '2014-07-08 04:09:20', '0', '0', 'system', '<span>Success!</span>Module updated successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('214', 'admin', '83.229.39.101', '2014-07-08 04:18:13', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('215', 'admin', '83.229.39.101', '2014-07-08 04:22:57', '0', '0', 'user', ' مُستخدم  admin قد دخل بنجاح', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('216', 'admin', '83.229.39.101', '2014-07-08 04:41:25', '0', '0', 'user', ' مُستخدم  admin قد دخل بنجاح', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('217', 'admin', '83.229.39.101', '2014-07-08 04:42:31', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('218', 'admin', '83.229.39.101', '2014-07-08 04:47:52', '0', '0', 'user', ' مُستخدم  admin قد دخل بنجاح', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('219', 'admin', '83.229.39.101', '2014-07-08 04:52:10', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('220', 'admin', '83.229.39.101', '2014-07-08 04:55:59', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('221', 'admin', '83.229.39.101', '2014-07-08 04:57:13', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('222', 'admin', '83.229.39.101', '2014-07-08 04:57:54', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('223', 'admin', '83.229.39.101', '2014-07-08 04:58:33', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('224', 'admin', '83.229.39.101', '2014-07-08 05:02:01', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('225', 'admin', '83.229.39.101', '2014-07-08 05:09:17', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('226', 'admin', '83.229.39.101', '2014-07-08 05:14:07', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('227', 'admin', '83.229.39.101', '2014-07-08 05:15:22', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('228', 'admin', '83.229.39.101', '2014-07-08 05:16:10', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('229', 'admin', '83.229.39.101', '2014-07-08 05:16:53', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('230', 'admin', '83.229.39.101', '2014-07-08 05:17:49', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('231', 'admin', '83.229.39.101', '2014-07-08 05:18:21', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('232', 'admin', '83.229.39.101', '2014-07-08 05:21:32', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('233', 'admin', '83.229.39.101', '2014-07-08 05:24:20', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('234', 'admin', '83.229.39.101', '2014-07-08 05:27:37', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('235', 'admin', '83.229.39.101', '2014-07-08 05:36:47', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('236', 'admin', '83.229.39.101', '2014-07-08 05:38:51', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('237', 'admin', '83.229.39.101', '2014-07-08 05:39:50', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('238', 'admin', '83.229.39.101', '2014-07-08 05:42:41', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('239', 'admin', '83.229.39.101', '2014-07-08 05:49:45', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('240', 'admin', '83.229.39.101', '2014-07-08 05:50:34', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('241', 'admin', '83.229.39.101', '2014-07-08 05:50:59', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('242', 'admin', '83.229.39.101', '2014-07-08 05:54:57', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('243', 'admin', '83.229.39.101', '2014-07-08 05:56:47', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('244', 'admin', '83.229.39.101', '2014-07-08 06:08:13', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('245', 'admin', '83.229.39.101', '2014-07-08 06:10:28', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('246', 'admin', '83.229.39.101', '2014-07-08 06:13:44', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('247', 'admin', '83.229.39.101', '2014-07-08 06:16:24', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('248', 'admin', '83.229.39.101', '2014-07-08 06:16:46', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('249', 'admin', '83.229.39.101', '2014-07-08 06:31:57', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('250', 'admin', '83.229.39.101', '2014-07-08 06:42:26', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('251', 'admin', '83.229.39.101', '2014-07-08 06:50:40', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('252', 'admin', '83.229.39.101', '2014-07-08 06:53:27', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('253', 'admin', '83.229.39.101', '2014-07-08 06:54:34', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('254', 'admin', '83.229.39.101', '2014-07-08 07:02:33', '0', '0', 'system', '<span>ኣገናዕ!</span>ሞድዩል ተመዓራርዩ ኣሎ!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('255', 'admin', '83.229.39.101', '2014-07-08 07:06:10', '0', '0', 'system', '<span>ኣገናዕ!</span>ሞድዩል ተመዓራርዩ ኣሎ!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('256', 'admin', '83.229.39.101', '2014-07-08 07:07:15', '0', '0', 'system', '<span>ኣገናዕ!</span>ሞድዩል ተመዓራርዩ ኣሎ!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('257', 'admin', '83.229.39.101', '2014-07-08 07:16:49', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('258', 'admin', '83.229.39.101', '2014-07-08 07:18:06', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('259', 'admin', '83.229.39.101', '2014-07-08 07:18:24', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('260', 'admin', '83.229.39.101', '2014-07-08 07:18:37', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('261', 'admin', '83.229.39.101', '2014-07-08 07:19:04', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('262', 'admin', '83.229.39.101', '2014-07-08 07:19:27', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('263', 'admin', '83.229.39.101', '2014-07-08 07:20:39', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('264', 'admin', '83.229.39.101', '2014-07-08 07:21:34', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('265', 'admin', '83.229.39.101', '2014-07-08 07:23:36', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('266', 'admin', '83.229.39.101', '2014-07-08 07:27:09', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('267', 'admin', '83.229.39.101', '2014-07-08 07:27:54', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('268', 'admin', '83.229.39.101', '2014-07-08 07:28:27', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('269', 'admin', '83.229.39.101', '2014-07-08 07:30:26', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('270', 'admin', '83.229.39.101', '2014-07-08 07:33:44', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('271', 'admin', '83.229.39.101', '2014-07-08 07:35:00', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('272', 'admin', '83.229.39.101', '2014-07-08 07:36:19', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('273', 'admin', '83.229.39.101', '2014-07-08 07:37:07', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('274', 'admin', '83.229.39.101', '2014-07-08 07:38:12', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('275', 'admin', '83.229.39.101', '2014-07-08 07:38:44', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('276', 'admin', '83.229.39.101', '2014-07-08 07:40:15', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('277', 'admin', '83.229.39.101', '2014-07-08 07:41:55', '0', '0', 'system', 'تحديث تشكيل النظام ناجح<span>!نجاح</span>', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('278', 'admin', '83.229.39.101', '2014-07-08 07:44:04', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('279', 'admin', '83.229.39.101', '2014-07-08 07:45:48', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('280', 'admin', '83.229.39.101', '2014-07-08 07:50:00', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('281', 'admin', '83.229.39.101', '2014-07-08 07:50:37', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('282', 'admin', '83.229.39.101', '2014-07-09 01:00:28', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('283', 'admin', '83.229.39.101', '2014-07-09 01:04:41', '0', '0', 'system', '<span>Success!</span>Backup created successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('284', 'admin', '83.229.39.101', '2014-07-09 01:05:42', '0', '0', 'system', '<span>Success!</span>Backup created successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('285', 'admin', '83.229.39.101', '2014-07-09 01:12:05', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('286', 'admin', '83.229.39.101', '2014-07-09 01:13:41', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('287', 'admin', '83.229.39.101', '2014-07-09 01:34:40', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕጃ ዳታበይዝ ተሰሪሑ ኣሎ!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('288', 'admin', '83.229.39.101', '2014-07-09 01:40:05', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('289', 'admin', '83.229.39.101', '2014-07-09 01:43:59', '0', '0', 'system', 'Slide Image <strong>#</strong> deleted successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('290', 'admin', '83.229.39.101', '2014-07-10 03:01:28', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('291', 'admin', '83.229.39.101', '2014-07-10 03:09:50', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('292', 'admin', '83.229.39.101', '2014-07-10 03:13:31', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('293', 'admin', '83.229.39.101', '2014-07-10 03:50:40', '0', '0', 'user', 'ተጠቃሚ admin  ወጺኡ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('294', 'admin', '83.229.39.101', '2014-07-19 00:48:32', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('295', 'admin', '83.229.39.101', '2014-07-19 01:05:35', '0', '0', 'system', 'Slide Image <strong>1</strong> deleted successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('296', 'admin', '83.229.39.101', '2014-07-19 01:05:38', '0', '0', 'system', 'Slide Image <strong>2</strong> deleted successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('297', 'admin', '83.229.39.101', '2014-07-19 01:05:40', '0', '0', 'system', 'Slide Image <strong>3</strong> deleted successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('298', 'admin', '83.229.39.101', '2014-07-19 01:05:43', '0', '0', 'system', 'Slide Image <strong>4</strong> deleted successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('299', 'admin', '83.229.39.101', '2014-07-19 01:06:27', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('300', 'admin', '83.229.39.101', '2014-07-19 01:06:36', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('301', 'admin', '83.229.39.101', '2014-07-19 01:06:50', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('302', 'admin', '83.229.39.101', '2014-07-19 01:06:57', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('303', 'admin', '83.229.39.101', '2014-07-19 01:07:06', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('304', 'admin', '83.229.39.101', '2014-07-19 01:07:11', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('305', 'admin', '83.229.39.101', '2014-07-19 01:07:20', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('306', 'admin', '83.229.39.101', '2014-07-19 01:07:33', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('307', 'admin', '83.229.39.101', '2014-07-19 01:08:36', '0', '0', 'system', 'Slide Image <strong>3</strong> deleted successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('308', 'admin', '83.229.39.101', '2014-07-19 01:08:43', '0', '0', 'system', 'Slide Image <strong>3</strong> deleted successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('309', 'admin', '83.229.39.101', '2014-07-19 01:09:37', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('310', 'admin', '83.229.39.101', '2014-07-19 01:09:48', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('311', 'admin', '83.229.39.101', '2014-07-19 01:11:48', '0', '0', 'system', '<span>Success!</span>Content Post updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('312', 'admin', '83.229.39.101', '2014-07-19 01:13:17', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('313', 'admin', '83.229.39.101', '2014-07-19 01:13:40', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('314', 'admin', '83.229.39.101', '2014-07-19 01:14:42', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('315', 'admin', '83.229.39.101', '2014-07-19 01:14:53', '0', '0', 'system', '<span>Success!</span>Backup created successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('316', 'admin', '83.229.39.101', '2014-07-19 01:15:04', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('317', 'admin', '41.202.166.71', '2014-11-16 05:22:03', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('318', 'admin', '41.202.168.71', '2015-03-18 16:15:16', '0', '0', 'system', '<span>Success!</span>Database restored successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('319', 'admin', '41.202.168.71', '2015-03-18 16:15:41', '0', '0', 'system', 'Membership <strong>Trial 7</strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('320', 'admin', '41.202.168.71', '2015-03-18 16:15:43', '0', '0', 'system', 'Membership <strong>Weekly Access</strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('321', 'admin', '41.202.168.71', '2015-03-18 16:15:45', '0', '0', 'system', 'Membership <strong>Basic 30</strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('322', 'admin', '41.202.168.71', '2015-03-18 16:15:47', '0', '0', 'system', 'Membership <strong>Basic 90</strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('323', 'admin', '41.202.168.71', '2015-03-18 16:15:49', '0', '0', 'system', 'Membership <strong>Platinum Subscription</strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('324', 'admin', '41.202.168.71', '2015-03-18 16:16:33', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('325', 'admin', '41.202.168.71', '2015-03-18 16:18:53', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('326', 'admin', '41.202.170.67', '2015-03-19 05:55:51', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('327', 'admin', '41.202.170.67', '2015-03-19 05:57:02', '0', '0', 'system', '<span>ኣገናዕ!</span>ትሕዝቶ ጽሑፍ ተመዓራርዩ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('328', 'admin', '41.202.170.67', '2015-03-19 05:59:00', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('329', 'Guest', '41.202.169.20', '2015-03-24 07:55:39', '1', '1427201739', 'user', 'Possible Brute force attack', 'attack', 'yes');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('330', 'admin', '41.202.169.20', '2015-03-24 08:01:53', '0', '0', 'system', '<span>Success!</span>User added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('331', 'admin', '41.202.169.20', '2015-03-24 08:02:00', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('332', 'googlehire', '41.202.169.20', '2015-03-24 08:02:24', '0', '0', 'user', 'User googlehire has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('333', 'admin', '41.202.168.178', '2015-03-24 15:54:12', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('334', 'admin', '41.202.168.178', '2015-03-24 15:54:16', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('335', 'googlehire', '41.202.168.178', '2015-03-24 15:54:38', '0', '0', 'user', 'User googlehire has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('336', 'googlehire', '41.202.168.178', '2015-03-24 15:56:05', '0', '0', 'user', 'User googlehire has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('337', 'admin', '41.202.168.178', '2015-03-24 15:56:14', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('338', 'admin', '41.202.168.178', '2015-03-24 15:57:16', '0', '0', 'system', '<span>ኣገናዕ!</span>ተጠቃሚ ተማዓራርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('339', 'admin', '41.202.168.178', '2015-03-24 15:57:19', '0', '0', 'user', 'ተጠቃሚ admin  ወጺኡ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('340', 'Guest', '83.229.39.101', '2015-05-12 04:16:44', '0', '0', 'user', 'User Guest has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('341', 'admin', '83.229.39.101', '2015-05-13 03:03:22', '0', '0', 'system', '<span>Success!</span>Backup created successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('342', 'admin', '83.229.39.101', '2015-05-13 03:23:43', '0', '0', 'system', '<span>Success!</span>Backup deleted successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('343', 'admin', '83.229.39.101', '2015-05-13 03:23:53', '0', '0', 'system', '<span>Success!</span>Backup deleted successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('344', 'admin', '83.229.39.101', '2015-05-13 03:29:22', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('345', 'admin', '83.229.39.101', '2015-05-13 03:29:39', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('346', 'admin', '83.229.39.101', '2015-05-13 05:19:59', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('347', 'admin', '83.229.39.101', '2015-05-13 05:20:46', '0', '0', 'system', '<span>Success!</span>Image added successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('348', 'admin', '83.229.39.101', '2015-05-13 05:22:23', '0', '0', 'system', 'Slide Image <strong>v</strong> deleted successfully!', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('349', 'admin', '83.229.39.101', '2015-05-13 06:12:45', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('350', 'Guest', '83.229.39.101', '2015-05-13 06:33:36', '0', '0', 'user', 'User Guest has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('351', 'admin', '84.11.98.174', '2015-05-19 01:21:17', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('352', 'admin', '84.11.98.174', '2015-05-20 00:18:01', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('353', 'admin', '84.11.98.174', '2015-05-20 00:38:09', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('354', 'admin', '84.11.98.174', '2015-05-20 01:06:26', '0', '0', 'user', ' مُستخدم  admin قد دخل بنجاح', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('357', 'Guest', '76.218.12.10', '2015-08-30 14:09:01', '3', '1441061267', 'user', 'Possible Brute force attack', 'attack', 'yes');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('358', 'Guest', '12.111.83.34', '2015-10-15 23:00:19', '2', '1444968037', 'user', 'Possible Brute force attack', 'attack', 'yes');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('359', 'admin', '12.111.83.34', '2015-10-15 23:01:39', '0', '0', 'system', '<span>ኣገናዕ!</span>ኣሰራርዓ ሲስተም ተማዓራርዩ ኣሎ!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('360', 'admin', '12.111.83.34', '2015-10-15 23:02:18', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('361', 'Guest', '213.132.48.232', '2016-02-17 05:18:12', '0', '0', 'user', 'User mogoszemat08 has successfully registered.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('362', 'admin', '73.241.202.57', '2016-04-08 22:31:38', '0', '0', 'system', '<span>Success!</span>User added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('363', 'admin', '73.241.202.57', '2016-04-08 22:31:44', '2', '1460153397', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('364', 'JayZlab', '73.241.202.57', '2016-04-08 22:32:17', '0', '0', 'user', 'User JayZlab has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('365', 'JayZlab', '73.241.202.57', '2016-04-08 22:34:14', '0', '0', 'user', 'ተጠቃሚ JayZlab  ወጺኡ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('366', 'admin', '73.241.202.57', '2016-04-08 22:34:22', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('367', 'admin', '73.241.202.57', '2016-04-08 22:35:21', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('368', 'admin', '73.241.202.57', '2016-04-08 22:35:28', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('369', 'JayZlab', '73.241.202.57', '2016-04-08 22:35:37', '0', '0', 'user', 'User JayZlab has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('370', 'JayZlab', '73.241.202.57', '2016-04-08 22:37:31', '0', '0', 'user', 'ተጠቃሚ JayZlab  ወጺኡ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('371', 'admin', '73.241.202.57', '2016-04-08 22:37:39', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('372', 'admin', '73.241.202.57', '2016-04-08 22:53:03', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('373', 'admin', '73.241.202.57', '2016-04-08 22:53:07', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('374', 'JayZlab', '73.241.202.57', '2016-04-08 22:53:20', '0', '0', 'user', 'User JayZlab has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('375', 'JayZlab', '73.241.202.57', '2016-04-08 22:56:41', '0', '0', 'user', 'User JayZlab has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('376', 'admin', '73.241.202.57', '2016-04-08 22:56:51', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('377', 'admin', '73.241.202.57', '2016-04-08 22:57:06', '0', '0', 'system', 'User <strong></strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('378', 'admin', '73.241.202.57', '2016-04-08 22:57:11', '0', '0', 'system', 'User <strong></strong> deleted successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('379', 'admin', '73.241.202.57', '2016-04-08 22:58:11', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('380', 'admin', '73.241.202.57', '2016-04-08 22:58:14', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('381', 'admin', '73.241.202.57', '2016-04-08 22:58:29', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('382', 'admin', '73.241.202.57', '2016-04-08 22:59:39', '0', '0', 'system', 'ንግዳዊ ጉዳያት <strong>05 Mar 2011</strong> ተደምሲሱ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('383', 'admin', '73.241.202.57', '2016-04-08 22:59:44', '0', '0', 'system', 'ንግዳዊ ጉዳያት <strong>12 Mar 2011</strong> ተደምሲሱ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('384', 'admin', '73.241.202.57', '2016-04-08 23:00:16', '0', '0', 'user', 'ተጠቃሚ admin  ወጺኡ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('385', 'admin', '73.241.202.57', '2016-04-08 23:00:28', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('386', 'admin', '73.241.202.57', '2016-04-08 23:20:33', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('387', 'JayZlab', '73.241.202.57', '2016-04-08 23:20:50', '0', '0', 'user', 'User JayZlab has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('388', 'JayZlab', '73.241.202.57', '2016-04-08 23:22:25', '0', '0', 'user', 'User JayZlab has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('389', 'admin', '73.241.202.57', '2016-04-08 23:22:40', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('390', 'admin', '73.241.202.57', '2016-04-08 23:23:54', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('391', 'admin', '73.241.202.57', '2016-04-08 23:24:05', '0', '0', 'system', '<span>Success!</span>Backup created successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('392', 'admin', '73.241.202.57', '2016-04-08 23:24:18', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('393', 'JayZlab', '73.241.202.57', '2016-04-08 23:24:32', '0', '0', 'user', 'User JayZlab has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('394', 'JayZlab', '73.241.202.57', '2016-04-09 00:02:48', '0', '0', 'user', 'ተጠቃሚ JayZlab  ወጺኡ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('395', 'admin', '73.241.202.57', '2016-04-09 00:03:07', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('396', 'admin', '73.241.202.57', '2016-04-09 00:03:40', '0', '0', 'system', '<span>ኣገናዕ!</span>ኣሰራርዓ ሲስተም ተማዓራርዩ ኣሎ!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('397', 'admin', '73.241.202.57', '2016-04-09 00:03:45', '0', '0', 'user', 'ተጠቃሚ admin  ወጺኡ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('398', 'admin', '73.241.202.57', '2016-04-09 00:05:03', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('399', 'JayZlab', '73.241.202.57', '2016-04-09 00:05:36', '0', '0', 'user', 'User JayZlab has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('400', 'JayZlab', '73.241.202.57', '2016-04-09 00:05:51', '0', '0', 'user', 'User JayZlab has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('401', 'JayZlab', '73.241.202.57', '2016-04-09 00:06:26', '0', '0', 'system', '<span>Success!</span>System Configuration updated successfully!', 'config', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('402', 'JayZlab', '73.241.202.57', '2016-04-09 00:09:40', '0', '0', 'user', 'ተጠቃሚ JayZlab  ወጺኡ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('403', 'admin', '73.241.202.57', '2016-04-09 00:10:10', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('404', 'admin', '73.241.202.57', '2016-04-09 00:11:34', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('405', 'JayZlab', '73.241.202.57', '2016-04-09 01:54:21', '0', '0', 'user', 'ተጠቃሚ JayZlab  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('406', 'admin', '73.241.202.57', '2016-04-09 06:08:10', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('407', 'admin', '73.241.202.57', '2016-04-09 06:26:44', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('408', 'admin', '73.241.202.57', '2016-04-09 06:27:10', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('409', 'admin', '73.241.202.57', '2016-04-09 06:28:20', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('410', 'admin', '73.241.202.57', '2016-04-09 06:30:47', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('411', 'admin', '73.241.202.57', '2016-04-09 06:31:43', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('412', 'admin', '73.241.202.57', '2016-04-09 06:32:27', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('413', 'admin', '73.241.202.57', '2016-04-09 06:34:36', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('414', 'admin', '73.241.202.57', '2016-04-09 06:36:26', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('415', 'admin', '73.241.202.57', '2016-04-09 06:38:13', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('416', 'admin', '73.241.202.57', '2016-04-09 06:38:26', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('417', 'admin', '73.241.202.57', '2016-04-09 06:38:54', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('418', 'admin', '73.241.202.57', '2016-04-09 06:39:14', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('419', 'admin', '73.241.202.57', '2016-04-09 06:40:16', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('420', 'admin', '73.241.202.57', '2016-04-09 06:40:52', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('421', 'admin', '73.241.202.57', '2016-04-09 06:41:27', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('422', 'admin', '73.241.202.57', '2016-04-09 06:41:42', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('423', 'admin', '73.241.202.57', '2016-04-09 06:42:22', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('424', 'admin', '73.241.202.57', '2016-04-09 06:42:46', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('425', 'admin', '73.241.202.57', '2016-04-09 06:43:06', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('426', 'admin', '73.241.202.57', '2016-04-09 06:43:43', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('427', 'admin', '73.241.202.57', '2016-04-09 06:44:03', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('428', 'admin', '73.241.202.57', '2016-04-09 06:44:18', '0', '0', 'system', '<span>ኣገናዕ!</span>ሜንዩ ተማዓርርዩ ኣሎ!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('429', 'admin', '73.241.202.57', '2016-04-09 06:46:08', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('430', 'admin', '73.241.202.57', '2016-04-09 06:48:29', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('431', 'admin', '73.241.202.57', '2016-04-09 06:48:45', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('432', 'admin', '73.241.202.57', '2016-04-09 06:49:19', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('433', 'admin', '73.241.202.57', '2016-04-09 06:50:01', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('434', 'admin', '73.241.202.57', '2016-04-09 06:50:31', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('435', 'admin', '73.241.202.57', '2016-04-09 06:52:26', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('436', 'admin', '73.241.202.57', '2016-04-09 06:53:10', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('437', 'admin', '73.241.202.57', '2016-04-09 06:53:52', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('438', 'admin', '73.241.202.57', '2016-04-09 06:54:25', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('439', 'admin', '73.241.202.57', '2016-04-09 06:54:47', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('440', 'admin', '73.241.202.57', '2016-04-09 06:58:13', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('441', 'admin', '73.241.202.57', '2016-04-09 06:58:50', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('442', 'admin', '73.241.202.57', '2016-04-09 07:01:01', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('443', 'admin', '73.241.202.57', '2016-04-09 07:01:51', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('444', 'admin', '73.241.202.57', '2016-04-09 07:02:40', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('445', 'admin', '73.241.202.57', '2016-04-09 07:03:26', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('446', 'admin', '73.241.202.57', '2016-04-09 07:03:56', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('447', 'admin', '73.241.202.57', '2016-04-09 07:05:00', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('448', 'admin', '73.241.202.57', '2016-04-09 07:05:36', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('449', 'admin', '73.241.202.57', '2016-04-09 07:06:08', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('450', 'admin', '73.241.202.57', '2016-04-09 07:06:59', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('451', 'admin', '73.241.202.57', '2016-04-09 07:07:23', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('452', 'admin', '73.241.202.57', '2016-04-09 07:08:00', '0', '0', 'system', '!تحديث اللائٍحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('453', 'admin', '73.241.202.57', '2016-04-09 07:10:28', '0', '0', 'system', '!تحديث فحوة الصفحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('454', 'admin', '73.241.202.57', '2016-04-09 07:11:08', '0', '0', 'system', '!تحديث فحوة الصفحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('455', 'admin', '73.241.202.57', '2016-04-09 07:11:40', '0', '0', 'system', '!تحديث فحوة الصفحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('456', 'admin', '73.241.202.57', '2016-04-09 07:13:42', '0', '0', 'system', '!تحديث فحوة الصفحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('457', 'admin', '73.241.202.57', '2016-04-09 07:15:13', '0', '0', 'system', '!تحديث فحوة الصفحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('458', 'admin', '73.241.202.57', '2016-04-09 07:19:24', '0', '0', 'system', '!تحديث فحوة الصفحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('459', 'admin', '73.241.202.57', '2016-04-09 07:20:01', '0', '0', 'system', '!تحديث فحوة الصفحة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('460', 'admin', '73.241.202.57', '2016-04-09 07:20:42', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('461', 'admin', '73.241.202.57', '2016-04-09 07:21:10', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('462', 'admin', '73.241.202.57', '2016-04-09 07:21:38', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('463', 'admin', '73.241.202.57', '2016-04-09 07:22:25', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('464', 'admin', '73.241.202.57', '2016-04-09 07:23:08', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('465', 'admin', '73.241.202.57', '2016-04-09 07:25:44', '0', '0', 'system', '!تحديث فحوة كتابة ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('466', 'admin', '73.241.202.57', '2016-04-09 07:26:40', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('467', 'admin', '73.241.202.57', '2016-04-09 07:27:27', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('468', 'admin', '73.241.202.57', '2016-04-09 07:28:01', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('469', 'admin', '73.241.202.57', '2016-04-09 07:28:26', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('470', 'admin', '73.241.202.57', '2016-04-09 07:28:51', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('471', 'admin', '73.241.202.57', '2016-04-09 07:29:27', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('472', 'admin', '73.241.202.57', '2016-04-09 07:40:41', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('473', 'admin', '73.241.202.57', '2016-04-09 07:42:08', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('474', 'admin', '73.241.202.57', '2016-04-09 07:42:59', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('475', 'admin', '73.241.202.57', '2016-04-09 07:44:33', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('476', 'admin', '73.241.202.57', '2016-04-09 07:45:13', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('477', 'admin', '73.241.202.57', '2016-04-09 07:45:47', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('478', 'admin', '73.241.202.57', '2016-04-09 07:46:14', '0', '0', 'system', '.تحديث الموديول ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('479', 'admin', '73.241.202.57', '2016-04-09 07:59:07', '0', '0', 'system', '!إرسال كل إ مٍيلات كان ناجح<span>!نجاح</span>', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('480', 'admin', '73.241.202.57', '2016-08-13 06:13:19', '0', '0', 'system', '<span>Success!</span>Database restored successfully!', 'database', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('481', 'admin', '73.241.202.57', '2016-08-13 06:24:54', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('482', 'Guest', '73.241.202.57', '2016-08-13 06:25:44', '0', '0', 'user', 'User Guest has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('483', 'admin', '73.241.202.57', '2016-10-04 04:53:16', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('484', 'admin', '73.241.202.57', '2016-10-04 04:54:17', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('485', 'admin', '73.241.202.57', '2016-10-04 04:54:39', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('486', 'admin', '73.241.202.57', '2016-10-04 04:55:07', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('487', 'admin', '73.241.202.57', '2016-10-04 04:55:30', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('488', 'admin', '73.241.202.57', '2016-10-04 04:55:49', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('489', 'admin', '73.241.202.57', '2016-10-04 04:56:11', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('490', 'admin', '73.241.202.57', '2016-10-04 04:56:55', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('491', 'admin', '73.241.202.57', '2016-10-04 04:58:35', '0', '0', 'system', '<span>Success!</span>Image updated successfuly.', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('492', 'admin', '73.241.202.57', '2016-10-04 05:01:31', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('493', 'admin', '73.241.202.57', '2016-10-04 05:01:54', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('494', 'admin', '73.241.202.57', '2016-10-04 05:03:55', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('495', 'admin', '73.241.202.57', '2016-10-04 05:04:20', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('496', 'admin', '73.241.202.57', '2016-10-04 05:04:53', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('497', 'admin', '73.241.202.57', '2016-10-04 05:05:21', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('498', 'admin', '73.241.202.57', '2016-10-04 05:05:44', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('499', 'admin', '73.241.202.57', '2016-10-04 05:06:04', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('500', 'admin', '73.241.202.57', '2016-10-04 05:07:08', '0', '0', 'system', '.تحديث الصورة ناجح<span>!نجاح</span>', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('501', 'admin', '73.241.202.57', '2016-10-04 05:09:16', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('502', 'admin', '73.241.202.57', '2016-10-04 05:10:24', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('503', 'admin', '73.241.202.57', '2016-10-04 05:11:02', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('504', 'admin', '73.241.202.57', '2016-10-04 05:11:40', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('505', 'admin', '73.241.202.57', '2016-10-04 05:12:20', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('506', 'admin', '73.241.202.57', '2016-10-04 05:12:58', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('507', 'admin', '73.241.202.57', '2016-10-04 05:13:38', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('508', 'admin', '73.241.202.57', '2016-10-04 05:14:58', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('509', 'admin', '73.241.202.57', '2016-10-04 05:15:13', '0', '0', 'system', '<span>ኣገናዕ!</span>ስእሊ ተመዓራርዩ', 'module', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('510', 'admin', '12.111.83.34', '2016-12-20 05:45:18', '0', '0', 'system', '<span>Success!</span>User added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('511', 'admin', '12.111.83.34', '2016-12-20 05:47:09', '0', '0', 'system', '<span>Success!</span>User added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('512', 'admin', '12.111.83.34', '2016-12-20 05:47:23', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('513', 'nang', '12.111.83.34', '2016-12-20 05:47:31', '0', '0', 'user', 'User nang has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('514', 'nang', '12.111.83.34', '2016-12-20 05:47:39', '0', '0', 'user', 'User nang has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('515', 'admin', '12.111.83.34', '2016-12-20 05:47:48', '0', '0', 'user', 'User admin has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('516', 'admin', '12.111.83.34', '2016-12-20 05:48:45', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('517', 'admin', '12.111.83.34', '2016-12-20 05:48:47', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('518', 'nang', '12.111.83.34', '2016-12-20 05:48:54', '0', '0', 'user', 'User nang has successfully logged in.', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('519', 'nang', '12.111.83.34', '2016-12-20 05:49:40', '0', '0', 'user', 'ተጠቃሚ nang  ወጺኡ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('520', 'admin', '12.111.83.34', '2016-12-20 05:49:47', '0', '0', 'user', 'ተጠቃሚ admin  ኣትዩ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('521', 'admin', '12.111.83.34', '2016-12-20 06:04:45', '0', '0', 'user', 'ተጠቃሚ admin  ወጺኡ', 'user', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('522', 'admin', '130.65.109.103', '2017-01-05 20:10:27', '0', '0', 'system', '<span>Success!</span>User updated successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('523', 'admin', '130.65.109.103', '2017-01-05 20:15:35', '0', '0', 'system', '<span>Success!</span>User added successfully!', 'content', 'no');
INSERT INTO `log` (`id`, `user_id`, `ip`, `created`, `failed`, `failed_last`, `type`, `message`, `info_icon`, `importance`) VALUES ('524', 'admin', '130.65.109.103', '2017-01-05 20:16:13', '0', '0', 'user', 'User admin has successfully logged out.', 'user', 'no');


-- --------------------------------------------------
# -- Table structure for table `memberships`
-- --------------------------------------------------
DROP TABLE IF EXISTS `memberships`;
CREATE TABLE `memberships` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `title_sa` varchar(255) NOT NULL,
  `title_er` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `description_sa` text,
  `description_er` text,
  `price` float(10,2) NOT NULL DEFAULT '0.00',
  `days` int(5) NOT NULL DEFAULT '0',
  `period` varchar(1) NOT NULL DEFAULT 'D',
  `trial` tinyint(1) NOT NULL DEFAULT '0',
  `recurring` tinyint(1) NOT NULL DEFAULT '0',
  `private` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `memberships`
-- --------------------------------------------------



-- --------------------------------------------------
# -- Table structure for table `menus`
-- --------------------------------------------------
DROP TABLE IF EXISTS `menus`;
CREATE TABLE `menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `name_sa` varchar(100) NOT NULL,
  `name_er` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `content_type` varchar(20) NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `target` enum('_self','_blank') NOT NULL DEFAULT '_blank',
  `position` int(11) NOT NULL DEFAULT '0',
  `home_page` tinyint(1) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `content_id` (`active`),
  KEY `parent_id` (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `menus`
-- --------------------------------------------------

INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('1', '0', '3', 'Contact Us', 'اتصل بنا', 'ተወከሱና', '-', 'page', '', '', '21', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('2', '0', '1', 'Home', 'الصفحة الرئيسية', 'ርእሰ ገጽ', '-', 'page', '', '', '9', '1', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('3', '0', '7', 'All Modules', 'جميع وحدات', 'ኩሎም ሞዱላት', '-', 'page', '', '', '10', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('4', '0', '6', 'Three Columns', 'ثلاثة أعمدة', 'ሰለስተ ዓምድታት', '-', 'page', '', '', '11', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('5', '0', '5', 'Full Width Page', 'عرض صفحة كاملة', 'ምሉእ ዝጎድኑ ገጽ', '-', 'page', '', '', '16', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('6', '0', '0', 'External Link', 'رابط خارجي', 'ግዳማዊ ሊንክ', '-', 'web', 'http://www.google.com', '_blank', '17', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('7', '0', '8', 'Sample Submenus', 'قوائم فرعية عينة', 'ተራ ትሕተ-ሜንዩ', '-', 'page', '', '', '12', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('8', '7', '6', 'New Submenu 1', 'القائمة الفرعية الجديدة 1', 'ሓድሽ ትሕተ-ሜንዩ 1', '-1', 'page', '', '', '13', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('9', '7', '7', 'New Submenu 2', 'القائمة الفرعية الجديدة 2', 'ሓድሽ ትሕተ-ሜንዩ 2', '-2', 'page', '', '', '14', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('10', '9', '3', 'New Submenu 3', 'القائمة الفرعية الجديدة 3', 'ሓድሽ ትሕተ-ሜንዩ 3', '-3', 'page', '', '', '15', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('11', '0', '2', 'About Us', 'معلومات عنا', 'ብዛዕባና', '-', 'page', '', '', '18', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('17', '11', '9', 'Members Only', 'الأعضاء فقط', 'ንኣባላት ዝተሓዝአ', '-', 'page', '', '', '19', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('18', '11', '10', 'Membership Only', 'عضوية فقط', 'ንኣባልነት ዝተሓዝአ', '-', 'page', '', '', '20', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('19', '0', '7', 'Products', 'المنتجات', 'ፍርያት', '', 'page', '', '', '1', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('20', '0', '6', 'About Us', 'معلومات عنا', 'ብዛዕባና', '-', 'page', '', '', '2', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('21', '0', '6', 'Company Profile', 'ملف الشركة', 'ፕሮፋይል ትካልና', '-', 'page', '', '', '3', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('22', '0', '6', 'Quality', 'جودة', 'ብቕዓት', '', 'page', '', '', '4', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('23', '0', '6', 'Partners', 'شركاء', 'መሻርኽቲ', '', 'page', '', '', '5', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('24', '0', '6', 'Job Opportunities', 'فرص عمل', 'ናይ ስራሕ ዕድላት', '-', 'page', '', '', '6', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('25', '0', '6', 'Contact Us', 'مرحبا بكم في آصيل الدوائية', 'ተወከሱና', '-', 'page', '', '', '7', '0', '0');
INSERT INTO `menus` (`id`, `parent_id`, `page_id`, `name`, `name_sa`, `name_er`, `slug`, `content_type`, `link`, `target`, `position`, `home_page`, `active`) VALUES ('26', '0', '2', 'Welcome to Azel Pharmaceutical', 'الصفحة الرئيسية', 'መርሓባ ናብ ኣዘል', '-', 'page', '', '', '8', '0', '0');


-- --------------------------------------------------
# -- Table structure for table `mod_comments`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_comments`;
CREATE TABLE `mod_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `page_id` int(11) NOT NULL DEFAULT '0',
  `username` varchar(24) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `body` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `www` varchar(220) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ip` varchar(16) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `parent` (`parent_id`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_comments`
-- --------------------------------------------------

INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('1', '0', '2', 'Webmaster', 'webmaster@Eriweb.com', 'First comment is on me.', 'http://www.Eriweb.com', '2011-01-30 16:34:55', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('2', '3', '2', 'Admin', 'admin@mail.com', '<pre>Cum sociis natoque penatibus et <strong>magnis dis parturient</strong> montes, </pre>nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio auctor quis.', '', '2011-01-31 08:40:42', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('3', '5', '2', 'User1', 'user1@mail.com', 'Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed risus in est cursus ornare.', '', '2011-01-31 08:45:54', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('4', '0', '2', 'User2', 'user2@mail.com', 'Etiam non lacus ac velit <em>lobortis rutrum sed</em> id turpis. <code>Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris,</code>sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit commodo.', '', '2011-01-31 08:48:26', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('5', '0', '2', 'User3', 'user3@mail.com', 'In hac habit***e platea dictumst.ivamus leo diam, dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus sit amet bibendum faucibus, nisi ligula ultricies purus', '', '2011-01-31 08:51:25', '127.0.0.1', '1');
INSERT INTO `mod_comments` (`id`, `parent_id`, `page_id`, `username`, `email`, `body`, `www`, `created`, `ip`, `active`) VALUES ('6', '0', '2', 'User4', 'user4@mail.com', 'Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam, dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus sit amet bibendum faucibus, nisi ligula ultricies purus, in malesuada arcu sem ut mauris. Proin lobortis rutrum ultrices.', '', '2011-01-31 08:53:51', '127.0.0.1', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_comments_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_comments_config`;
CREATE TABLE `mod_comments_config` (
  `username_req` tinyint(1) NOT NULL DEFAULT '0',
  `email_req` tinyint(1) NOT NULL DEFAULT '0',
  `show_captcha` tinyint(1) NOT NULL DEFAULT '1',
  `show_www` tinyint(1) NOT NULL DEFAULT '0',
  `show_username` tinyint(1) DEFAULT '1',
  `show_email` tinyint(1) DEFAULT '1',
  `auto_approve` tinyint(1) NOT NULL DEFAULT '0',
  `notify_new` tinyint(1) NOT NULL DEFAULT '0',
  `public_access` tinyint(1) NOT NULL DEFAULT '0',
  `sorting` varchar(4) NOT NULL DEFAULT 'DESC',
  `blacklist_words` text,
  `char_limit` varchar(6) NOT NULL DEFAULT '400',
  `perpage` varchar(3) NOT NULL DEFAULT '10',
  `dateformat` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_comments_config`
-- --------------------------------------------------

INSERT INTO `mod_comments_config` (`username_req`, `email_req`, `show_captcha`, `show_www`, `show_username`, `show_email`, `auto_approve`, `notify_new`, `public_access`, `sorting`, `blacklist_words`, `char_limit`, `perpage`, `dateformat`) VALUES ('1', '1', '1', '1', '1', '0', '0', '0', '1', 'DESC', 'arse\narses\nass\nasses\nbollocks\ncrap', '400', '5', '%d %M %Y %H:%i');


-- --------------------------------------------------
# -- Table structure for table `mod_events`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_events`;
CREATE TABLE `mod_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `title_sa` varchar(150) NOT NULL,
  `title_er` varchar(150) NOT NULL,
  `venue` varchar(150) NOT NULL,
  `venue_sa` varchar(150) NOT NULL,
  `venue_er` varchar(150) NOT NULL,
  `date_start` date NOT NULL DEFAULT '0000-00-00',
  `date_end` date NOT NULL DEFAULT '0000-00-00',
  `time_start` time NOT NULL DEFAULT '00:00:00',
  `time_end` time NOT NULL DEFAULT '00:00:00',
  `body` text NOT NULL,
  `body_sa` text,
  `body_er` text,
  `contact_person` varchar(100) NOT NULL,
  `contact_email` varchar(80) NOT NULL,
  `contact_phone` varchar(16) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_events`
-- --------------------------------------------------

INSERT INTO `mod_events` (`id`, `title`, `title_sa`, `title_er`, `venue`, `venue_sa`, `venue_er`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `body_sa`, `body_er`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('1', 'Free Coffee for Each Monday', 'Free Coffee for Each Monday', 'Free Coffee for Each Monday', 'Office Rental Showroom', 'Office Rental Showroom', 'Office Rental Showroom', '2011-05-08', '2011-05-31', '11:18:00', '21:00:00', 'Vestibulum dictum elit eu risus porta egestas. Sed quis enim neque, sed  fringilla erat. Nunc feugiat tortor eu sem consequat aliquam. Cras non  nibh at lorem auctor interdum. Donec ut lacinia massa.', 'Vestibulum dictum elit eu risus porta egestas. Sed quis enim neque, sed  fringilla erat. Nunc feugiat tortor eu sem consequat aliquam. Cras non  nibh at lorem auctor interdum. Donec ut lacinia massa.', 'Vestibulum dictum elit eu risus porta egestas. Sed quis enim neque, sed  fringilla erat. Nunc feugiat tortor eu sem consequat aliquam. Cras non  nibh at lorem auctor interdum. Donec ut lacinia massa.', 'John Doe', 'john@gmail.com', '555-555-5555', '1');
INSERT INTO `mod_events` (`id`, `title`, `title_sa`, `title_er`, `venue`, `venue_sa`, `venue_er`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `body_sa`, `body_er`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('2', 'Lucky Draw', 'Lucky Draw', 'Lucky Draw', 'Office Rental Showroom', 'Office Rental Showroom', 'Office Rental Showroom', '2011-05-21', '2011-05-31', '13:30:00', '11:00:00', '&lt;p&gt;&lt;img width=&quot;150&quot; height=&quot;98&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_demo_1.jpg&quot; alt=&quot;thumb_demo_1.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Pellentesque habitant morbi tristique senectus et netus et malesuada  fames ac turpis egestas. Nulla posuere nibh auctor urna tincidunt  fringilla. &lt;br /&gt;\r\nDonec imperdiet, orci quis aliquet laoreet, magna purus semper ligula,  sit amet aliquam sapien enim in orci. Pellentesque at iaculis nibh.&lt;/p&gt;', '&lt;p&gt;&lt;img width=&quot;150&quot; height=&quot;98&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_demo_1.jpg&quot; alt=&quot;thumb_demo_1.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Pellentesque habitant morbi tristique senectus et netus et malesuada  fames ac turpis egestas. Nulla posuere nibh auctor urna tincidunt  fringilla. &lt;br /&gt;\r\nDonec imperdiet, orci quis aliquet laoreet, magna purus semper ligula,  sit amet aliquam sapien enim in orci. Pellentesque at iaculis nibh.&lt;/p&gt;', '&lt;p&gt;&lt;img width=&quot;150&quot; height=&quot;98&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_demo_1.jpg&quot; alt=&quot;thumb_demo_1.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Pellentesque habitant morbi tristique senectus et netus et malesuada  fames ac turpis egestas. Nulla posuere nibh auctor urna tincidunt  fringilla. &lt;br /&gt;\r\nDonec imperdiet, orci quis aliquet laoreet, magna purus semper ligula,  sit amet aliquam sapien enim in orci. Pellentesque at iaculis nibh.&lt;/p&gt;', 'John Doe', 'john@gmail.com', '555-555-5555', '1');
INSERT INTO `mod_events` (`id`, `title`, `title_sa`, `title_er`, `venue`, `venue_sa`, `venue_er`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `body_sa`, `body_er`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('3', 'E-Commerce Seminar', 'E-Commerce Seminar', 'E-Commerce Seminar', 'Office Rental Showroom', 'Office Rental Showroom', 'Office Rental Showroom', '2011-06-19', '2011-06-19', '09:30:00', '13:30:00', 'Proin nec nisl est, id ornare lacus. Etiam mauris neque, scelerisque ut  ultrices vel, blandit et nisi. Nam commodo fermentum lectus vulputate  auctor. Maecenas hendrerit sapien sit amet erat mollis venenatis nec sit', 'Proin nec nisl est, id ornare lacus. Etiam mauris neque, scelerisque ut  ultrices vel, blandit et nisi. Nam commodo fermentum lectus vulputate  auctor. Maecenas hendrerit sapien sit amet erat mollis venenatis nec sit', 'Proin nec nisl est, id ornare lacus. Etiam mauris neque, scelerisque ut  ultrices vel, blandit et nisi. Nam commodo fermentum lectus vulputate  auctor. Maecenas hendrerit sapien sit amet erat mollis venenatis nec sit', 'John Doe', 'john@gmail.com', '555-555-5555', '1');
INSERT INTO `mod_events` (`id`, `title`, `title_sa`, `title_er`, `venue`, `venue_sa`, `venue_er`, `date_start`, `date_end`, `time_start`, `time_end`, `body`, `body_sa`, `body_er`, `contact_person`, `contact_email`, `contact_phone`, `active`) VALUES ('4', 'E-Commerce Seminar II', 'E-Commerce Seminar II', 'E-Commerce Seminar II', 'Office Rental Showroom', 'Office Rental Showroom', 'Office Rental Showroom', '2011-06-19', '2011-06-19', '17:00:00', '19:00:00', 'Aliquam auctor molestie ipsum ultricies tincidunt. Suspendisse potenti.  Nulla volutpat urna et mi consectetur placerat iaculis lacus lacinia.  Integer a nisi id diam tempus commodo eget a tellus. In consequat augue  nec tortor bibendum vel semper metus sodales. Donec ut dui nisi, id  posuere augue.', 'Aliquam auctor molestie ipsum ultricies tincidunt. Suspendisse potenti.  Nulla volutpat urna et mi consectetur placerat iaculis lacus lacinia.  Integer a nisi id diam tempus commodo eget a tellus. In consequat augue  nec tortor bibendum vel semper metus sodales. Donec ut dui nisi, id  posuere augue.', 'Aliquam auctor molestie ipsum ultricies tincidunt. Suspendisse potenti.  Nulla volutpat urna et mi consectetur placerat iaculis lacus lacinia.  Integer a nisi id diam tempus commodo eget a tellus. In consequat augue  nec tortor bibendum vel semper metus sodales. Donec ut dui nisi, id  posuere augue.', 'John Doe', 'john@gmail.com', '555-555-5555', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_gallery_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_gallery_config`;
CREATE TABLE `mod_gallery_config` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `title_sa` varchar(100) NOT NULL,
  `title_er` varchar(100) NOT NULL,
  `folder` varchar(30) DEFAULT NULL,
  `rows` int(4) NOT NULL DEFAULT '0',
  `thumb_w` int(4) NOT NULL DEFAULT '0',
  `thumb_h` int(4) NOT NULL DEFAULT '0',
  `image_w` int(4) NOT NULL DEFAULT '0',
  `image_h` int(4) NOT NULL DEFAULT '0',
  `watermark` tinyint(1) NOT NULL DEFAULT '0',
  `method` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_gallery_config`
-- --------------------------------------------------

INSERT INTO `mod_gallery_config` (`id`, `title`, `title_sa`, `title_er`, `folder`, `rows`, `thumb_w`, `thumb_h`, `image_w`, `image_h`, `watermark`, `method`, `created`) VALUES ('1', 'Demo Gallery', 'Demo Gallery', 'Demo Gallery', 'demo', '5', '150', '150', '600', '600', '1', '1', '2010-12-10 12:10:10');
INSERT INTO `mod_gallery_config` (`id`, `title`, `title_sa`, `title_er`, `folder`, `rows`, `thumb_w`, `thumb_h`, `image_w`, `image_h`, `watermark`, `method`, `created`) VALUES ('2', 'Savanna International Hotel', '', '', 'savanna', '4', '200', '200', '300', '300', '0', '1', '2013-04-30 03:38:57');


-- --------------------------------------------------
# -- Table structure for table `mod_gallery_images`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_gallery_images`;
CREATE TABLE `mod_gallery_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gallery_id` int(6) NOT NULL DEFAULT '0',
  `title` varchar(100) DEFAULT NULL,
  `title_sa` varchar(100) NOT NULL,
  `title_er` varchar(100) NOT NULL,
  `description` varchar(250) DEFAULT NULL,
  `description_sa` varchar(250) NOT NULL,
  `description_er` varchar(250) NOT NULL,
  `thumb` varchar(100) DEFAULT NULL,
  `sorting` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_gallery_images`
-- --------------------------------------------------

INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('1', '1', 'Demo Flower 1', 'Demo Flower 1', 'Demo Flower 1', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_318C0B-0F1A63-7096C7-45B182-87004D-FDF0AE.jpg', '2');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('2', '1', 'Demo Flower 2', 'Demo Flower 2', 'Demo Flower 2', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_D45A84-11B3CB-E2E617-8CE590-EB95CB-4C40CF.jpg', '3');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('3', '1', 'Demo Flower 3', 'Demo Flower 3', 'Demo Flower 3', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_07264C-30F255-F8E444-C90DC8-093AE6-C83DF4.jpg', '4');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('4', '1', 'Demo Flower 4', 'Demo Flower 4', 'Demo Flower 4', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_2822AC-941D16-C5ECEB-4C2787-015575-77FEE8.jpg', '5');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('5', '1', 'Demo Flower 5', 'Demo Flower 5', 'Demo Flower 5', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_260FA3-1C8BE1-890AFD-8F20ED-47EB05-EBDFF7.jpg', '6');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('6', '1', 'Demo Flower 6', 'Demo Flower 6', 'Demo Flower 6', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_755459-EC4B6C-58E134-2907AA-36BFEC-2604A5.jpg', '7');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('7', '1', 'Demo Flower 7', 'Demo Flower 7', 'Demo Flower 7', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_7810C6-0B129B-B97C0D-902867-748A5F-854706.jpg', '9');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('8', '1', 'Demo Flower 8', 'Demo Flower 8', 'Demo Flower 8', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_901142-405DB2-4B327C-6418D7-B92E53-CC1FA7.jpg', '10');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('9', '1', 'Demo Flower 9', 'Demo Flower 9', 'Demo Flower 9', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_F87715-1EAFB8-D4E516-77E233-215B0A-507EBB.jpg', '11');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('10', '1', 'Demo Flower 10', 'Demo Flower 10', 'Demo Flower 10', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_0D08C0-3FFF26-A5D741-BA76C6-F3C61F-D67093.jpg', '12');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('11', '1', 'Demo Flower 11', 'Demo Flower 11', 'Demo Flower 11', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_807CA0-B0AB7C-FF9BB6-E4E678-B9A38A-7A81FB.jpg', '13');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('12', '1', 'Demo Flower 12', 'Demo Flower 12', 'Demo Flower 12', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_7CF0A7-55F94C-0B0AE0-A4BF0C-476BF7-82CCE0.jpg', '14');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('13', '1', 'Demo Flower 13', 'Demo Flower 13', 'Demo Flower 13', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_E1A872-9BDEED-5CA577-3CA6F1-E2545B-DBCF15.jpg', '15');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('14', '1', 'Demo Flower 14', 'Demo Flower 14', 'Demo Flower 14', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_2D4A9D-9D3E9E-047D5A-49CC85-4B02A6-1F3BB6.jpg', '1');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('15', '1', 'Demo Flower 15', 'Demo Flower 15', 'Demo Flower 15', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'Fusce hendrerit vulputate rutrum. Phasellus in quam a mi fringilla ultrices.', 'IMG_886FAF-5199A3-9758FB-406A40-59CDF0-C5C3C9.jpg', '8');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('16', '2', 'Img Title', '', '', 'Img Description', '', '', 'IMG_E044CD-404DF1-ABC69F-E259D6-48440D-B0D933.jpg', '0');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('17', '2', 'Img Title', '', '', 'Img Description', '', '', 'IMG_D58351-832C68-FA4FB1-C0C579-782B8A-00FC6F.jpg', '0');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('18', '2', 'Img Title', '', '', 'Img Description', '', '', 'IMG_DBBB1A-E6DBDB-E6D3EC-D386FB-585903-C55B79.jpg', '0');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('19', '2', 'Img Title', '', '', 'Img Description', '', '', 'IMG_550A09-112343-5F64FE-336E0A-03F673-810314.jpg', '0');
INSERT INTO `mod_gallery_images` (`id`, `gallery_id`, `title`, `title_sa`, `title_er`, `description`, `description_sa`, `description_er`, `thumb`, `sorting`) VALUES ('20', '2', 'Img Title', '', '', 'Img Description', '', '', 'IMG_E69EEE-806E6A-B41921-7A6461-F67F8E-BEF077.jpg', '0');


-- --------------------------------------------------
# -- Table structure for table `mod_newsslider`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_newsslider`;
CREATE TABLE `mod_newsslider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) DEFAULT NULL,
  `title_sa` varchar(150) NOT NULL,
  `title_er` varchar(150) NOT NULL,
  `body` text,
  `body_sa` text,
  `body_er` text,
  `show_title` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  `show_created` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_newsslider`
-- --------------------------------------------------

INSERT INTO `mod_newsslider` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('1', 'Etiam non lacus', 'Etiam non lacus', 'Etiam non lacus', 'Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam, dignissim  eu convallis in, posuere quis magna. Curabitur mollis, lectus sit amet  bibendum faucibus, nisi ligula ultricies purus', 'Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam, dignissim  eu convallis in, posuere quis magna. Curabitur mollis, lectus sit amet  bibendum faucibus, nisi ligula ultricies purus', 'Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam, dignissim  eu convallis in, posuere quis magna. Curabitur mollis, lectus sit amet  bibendum faucibus, nisi ligula ultricies purus', '1', '2010-10-28 04:14:11', '1', '1', '1');
INSERT INTO `mod_newsslider` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('2', 'Cras ullamcorper', 'Cras ullamcorper', 'Cras ullamcorper', 'Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros  eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna  sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed  risus in est cursus ornare.', 'Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros  eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna  sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed  risus in est cursus ornare.', 'Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros  eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna  sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed  risus in est cursus ornare.', '1', '2010-10-28 04:14:33', '1', '2', '1');
INSERT INTO `mod_newsslider` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('3', 'Vivamus vitae', 'Vivamus vitae', 'Vivamus vitae', 'Lusce pulvinar velit sit amet ligula ornare tempus vulputate ipsum  semper. Praesent non lorem odio. Fusce sed dui massa, eu viverra erat.  Proin posuere nulla in lectus malesuada volutpat. Cras tristique blandit  tellus, eu consequat ante', 'Lusce pulvinar velit sit amet ligula ornare tempus vulputate ipsum  semper. Praesent non lorem odio. Fusce sed dui massa, eu viverra erat.  Proin posuere nulla in lectus malesuada volutpat. Cras tristique blandit  tellus, eu consequat ante', 'Lusce pulvinar velit sit amet ligula ornare tempus vulputate ipsum  semper. Praesent non lorem odio. Fusce sed dui massa, eu viverra erat.  Proin posuere nulla in lectus malesuada volutpat. Cras tristique blandit  tellus, eu consequat ante', '1', '2010-10-28 04:21:34', '1', '3', '1');
INSERT INTO `mod_newsslider` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `created`, `show_created`, `position`, `active`) VALUES ('4', 'Another News', 'Another News', 'Another News', 'Vivamus vitae augue sed lacus placerat sollicitudin quis vel arcu. Vestibulum auctor, magna sit amet pulvinar tristique, nunc felis viverra tortor, venenatis convallis leo mauris eu massa. Intege', 'Vivamus vitae augue sed lacus placerat sollicitudin quis vel arcu. Vestibulum auctor, magna sit amet pulvinar tristique, nunc felis viverra tortor, venenatis convallis leo mauris eu massa. Intege', 'Vivamus vitae augue sed lacus placerat sollicitudin quis vel arcu. Vestibulum auctor, magna sit amet pulvinar tristique, nunc felis viverra tortor, venenatis convallis leo mauris eu massa. Intege', '1', '2010-10-28 04:43:36', '1', '4', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_poll_options`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_poll_options`;
CREATE TABLE `mod_poll_options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `value` varchar(300) NOT NULL,
  `value_sa` varchar(250) NOT NULL,
  `value_er` varchar(250) NOT NULL,
  `position` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_poll_options`
-- --------------------------------------------------

INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `value_sa`, `value_er`, `position`) VALUES ('5', '1', 'Very Hard', 'Very Hard', 'Very Hard', '5');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `value_sa`, `value_er`, `position`) VALUES ('4', '1', 'Hard', 'Hard', 'Hard', '4');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `value_sa`, `value_er`, `position`) VALUES ('3', '1', 'Easy', 'Easy', 'Easy', '3');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `value_sa`, `value_er`, `position`) VALUES ('2', '1', 'Very Easy', 'Very Easy', 'Very Easy', '2');
INSERT INTO `mod_poll_options` (`id`, `question_id`, `value`, `value_sa`, `value_er`, `position`) VALUES ('1', '1', 'Piece of cake', 'Piece of cake', 'Piece of cake', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_poll_questions`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_poll_questions`;
CREATE TABLE `mod_poll_questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(250) NOT NULL,
  `question_sa` varchar(250) NOT NULL,
  `question_er` varchar(250) NOT NULL,
  `created` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_poll_questions`
-- --------------------------------------------------

INSERT INTO `mod_poll_questions` (`id`, `question`, `question_sa`, `question_er`, `created`, `status`) VALUES ('1', 'How do you find Eriweb Installation?', 'How do you find Eriweb Installation?', 'How do you find Eriweb Installation?', '2010-10-13 07:42:18', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_poll_votes`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_poll_votes`;
CREATE TABLE `mod_poll_votes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option_id` int(11) NOT NULL,
  `voted_on` datetime NOT NULL,
  `ip` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_poll_votes`
-- --------------------------------------------------

INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('1', '2', '2010-10-14 14:00:55', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('2', '1', '2010-10-14 14:01:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('3', '1', '2010-10-14 14:02:04', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('4', '1', '2010-10-14 14:02:13', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('5', '3', '2010-10-14 14:02:16', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('6', '4', '2010-10-14 14:02:21', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('7', '3', '2010-10-14 14:02:24', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('8', '1', '2010-10-14 14:02:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('9', '2', '2010-10-14 14:02:31', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('10', '5', '2010-10-14 14:02:35', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('11', '1', '2010-10-14 14:02:38', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('12', '2', '2010-10-14 14:02:43', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('13', '1', '2010-10-14 14:02:46', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('14', '1', '2010-10-14 14:02:50', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('15', '1', '2010-10-14 14:05:26', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('16', '1', '2010-10-14 14:05:29', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('17', '4', '2010-10-14 14:05:33', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('18', '2', '2010-10-14 14:05:36', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('19', '1', '2010-10-14 14:05:40', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('20', '3', '2010-10-14 14:05:46', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('21', '2', '2010-10-14 14:05:49', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('22', '2', '2010-10-14 14:21:37', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('23', '1', '2010-10-14 14:21:53', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('24', '5', '2010-10-14 14:21:59', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('25', '1', '2010-10-14 14:35:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('26', '1', '2010-10-15 00:42:05', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('27', '3', '2010-10-15 00:49:42', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('28', '2', '2010-10-15 01:22:00', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('29', '2', '2010-10-15 01:24:51', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('30', '1', '2010-10-15 01:37:21', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('31', '1', '2010-10-15 01:38:48', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('32', '1', '2010-10-15 01:41:30', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('33', '1', '2010-10-15 01:42:21', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('34', '1', '2010-10-15 04:53:42', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('35', '3', '2010-10-15 05:09:14', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('36', '3', '2010-11-24 21:00:27', '127.0.0.1');
INSERT INTO `mod_poll_votes` (`id`, `option_id`, `voted_on`, `ip`) VALUES ('37', '3', '2010-11-28 00:56:07', '127.0.0.1');


-- --------------------------------------------------
# -- Table structure for table `mod_rss_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_rss_config`;
CREATE TABLE `mod_rss_config` (
  `url` varchar(200) DEFAULT NULL,
  `title_trim` varchar(3) DEFAULT NULL,
  `show_body` tinyint(1) NOT NULL DEFAULT '0',
  `body_trim` varchar(3) DEFAULT NULL,
  `show_date` tinyint(1) NOT NULL DEFAULT '1',
  `dateformat` varchar(30) DEFAULT NULL,
  `perpage` varchar(2) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_rss_config`
-- --------------------------------------------------

INSERT INTO `mod_rss_config` (`url`, `title_trim`, `show_body`, `body_trim`, `show_date`, `dateformat`, `perpage`) VALUES ('http://news.google.com/?output=rss', '0', '0', '100', '0', 'F d, Y', '5');


-- --------------------------------------------------
# -- Table structure for table `mod_slider`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_slider`;
CREATE TABLE `mod_slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL DEFAULT '',
  `title_sa` varchar(150) NOT NULL,
  `title_er` varchar(150) NOT NULL,
  `filename` varchar(150) NOT NULL DEFAULT '',
  `url` varchar(150) NOT NULL DEFAULT '',
  `page_id` int(6) DEFAULT '0',
  `urltype` enum('int','ext') DEFAULT NULL,
  `position` int(5) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_slider`
-- --------------------------------------------------

INSERT INTO `mod_slider` (`id`, `title`, `title_sa`, `title_er`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('14', 'Great Products', 'المنتجات عظيمة', 'ብሉጽ ፍርያት', 'Chemputer-3D-printer-that-can-print-pharmaceuticals.jpg', '#', '0', 'ext', '1');
INSERT INTO `mod_slider` (`id`, `title`, `title_sa`, `title_er`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('13', 'Superior Quality', 'جودة فائقة', 'ልዑል ብቕዓት', 'images (9).jpg', '#', '0', 'ext', '2');
INSERT INTO `mod_slider` (`id`, `title`, `title_sa`, `title_er`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('15', 'Advanced Pharmaceuticals', 'الصيدلة المتقدمة', 'ምዕቡል ፋርማሱቲካል', 'download (2).jpg', '#', '0', 'ext', '3');
INSERT INTO `mod_slider` (`id`, `title`, `title_sa`, `title_er`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('16', 'Strong Partnerships', 'شراكات قوية', 'ድልዱል ምሕዝነት', 'download.jpg', '#', '0', 'ext', '4');
INSERT INTO `mod_slider` (`id`, `title`, `title_sa`, `title_er`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('22', 'Customer Satisfaction', 'رضا العملاء', 'ዕግበት ዓማዊል', 'images (7).jpg', '#', '0', 'ext', '5');
INSERT INTO `mod_slider` (`id`, `title`, `title_sa`, `title_er`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('21', 'Proven and Tested', 'اختبر وثبت', 'ፍቱንን ርጉጽን', 'images (10).jpg', '#', '0', 'ext', '6');
INSERT INTO `mod_slider` (`id`, `title`, `title_sa`, `title_er`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('19', 'Expertise and Know-how', 'الخبرة والدراية', 'ክኢላዊ ዓቅምን ኣፍልጦን', 'images (4).jpg', '#', '0', 'ext', '7');
INSERT INTO `mod_slider` (`id`, `title`, `title_sa`, `title_er`, `filename`, `url`, `page_id`, `urltype`, `position`) VALUES ('20', 'Azel Pharma - Pharmaceuticals that work!!', '!آزل فارما - الصيدلة التي تعمل', 'ኣዘል ፋርማ - ፍቱን ፋርማሱቲካል!', 'images.jpg', '#', '0', 'ext', '8');


-- --------------------------------------------------
# -- Table structure for table `mod_slider_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_slider_config`;
CREATE TABLE `mod_slider_config` (
  `animation` varchar(30) NOT NULL,
  `anispeed` varchar(6) NOT NULL DEFAULT '0',
  `anitime` varchar(10) NOT NULL DEFAULT '0',
  `shownav` tinyint(1) NOT NULL DEFAULT '0',
  `shownavhide` tinyint(1) NOT NULL DEFAULT '0',
  `controllnav` tinyint(1) NOT NULL DEFAULT '0',
  `hoverpause` tinyint(1) NOT NULL DEFAULT '0',
  `showcaption` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_slider_config`
-- --------------------------------------------------

INSERT INTO `mod_slider_config` (`animation`, `anispeed`, `anitime`, `shownav`, `shownavhide`, `controllnav`, `hoverpause`, `showcaption`) VALUES ('fade', '500', '3000', '1', '1', '1', '1', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_tabs`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_tabs`;
CREATE TABLE `mod_tabs` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `title_sa` varchar(50) NOT NULL,
  `title_er` varchar(50) NOT NULL,
  `body` text,
  `body_sa` text,
  `body_er` text,
  `position` int(6) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_tabs`
-- --------------------------------------------------

INSERT INTO `mod_tabs` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('1', 'Website Design', 'Website Design', 'Website Design', '&lt;img width=&quot;305&quot; height=&quot;220&quot; style=&quot;margin-left: 15px; float: right;&quot; alt=&quot;webdesign.png&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/webdesign.png&quot; /&gt;\r\n&lt;h1&gt;Website Design&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;\r\n&lt;br class=&quot;clear&quot; /&gt;', '&lt;img width=&quot;305&quot; height=&quot;220&quot; style=&quot;margin-left: 15px; float: right;&quot; alt=&quot;webdesign.png&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/webdesign.png&quot; /&gt;\r\n&lt;h1&gt;Website Design&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;\r\n&lt;br class=&quot;clear&quot; /&gt;', '&lt;img width=&quot;305&quot; height=&quot;220&quot; style=&quot;margin-left: 15px; float: right;&quot; alt=&quot;webdesign.png&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/webdesign.png&quot; /&gt;\r\n&lt;h1&gt;Website Design&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;\r\n&lt;br class=&quot;clear&quot; /&gt;', '1', '1');
INSERT INTO `mod_tabs` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('2', 'Content Management', 'Content Management', 'Content Management', '&lt;img width=&quot;305&quot; height=&quot;220&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/cms.png&quot; alt=&quot;cms.png&quot; style=&quot;margin-left: 15px; float: right;&quot; /&gt;\r\n&lt;h1&gt;Content Management&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;&lt;br class=&quot;clear&quot; /&gt;', '&lt;img width=&quot;305&quot; height=&quot;220&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/cms.png&quot; alt=&quot;cms.png&quot; style=&quot;margin-left: 15px; float: right;&quot; /&gt;\r\n&lt;h1&gt;Content Management&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;&lt;br class=&quot;clear&quot; /&gt;', '&lt;img width=&quot;305&quot; height=&quot;220&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/cms.png&quot; alt=&quot;cms.png&quot; style=&quot;margin-left: 15px; float: right;&quot; /&gt;\r\n&lt;h1&gt;Content Management&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;&lt;br class=&quot;clear&quot; /&gt;', '2', '1');
INSERT INTO `mod_tabs` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('3', 'E-Commerce', 'E-Commerce', 'E-Commerce', '&lt;img width=&quot;305&quot; height=&quot;220&quot; style=&quot;margin-left: 15px; float: right;&quot; alt=&quot;ecommerce.png&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/ecommerce.png&quot; /&gt;\r\n&lt;h1&gt;E-Commerce&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;\r\n&lt;br class=&quot;clear&quot; /&gt;', '&lt;img width=&quot;305&quot; height=&quot;220&quot; style=&quot;margin-left: 15px; float: right;&quot; alt=&quot;ecommerce.png&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/ecommerce.png&quot; /&gt;\r\n&lt;h1&gt;E-Commerce&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;\r\n&lt;br class=&quot;clear&quot; /&gt;', '&lt;img width=&quot;305&quot; height=&quot;220&quot; style=&quot;margin-left: 15px; float: right;&quot; alt=&quot;ecommerce.png&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/ecommerce.png&quot; /&gt;\r\n&lt;h1&gt;E-Commerce&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;\r\n&lt;br class=&quot;clear&quot; /&gt;', '4', '1');
INSERT INTO `mod_tabs` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('4', 'Search Engines', 'Search Engines', 'Search Engines', '&lt;img width=&quot;305&quot; height=&quot;220&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/seo.png&quot; alt=&quot;seo.png&quot; style=&quot;margin-left: 15px; float: right;&quot; /&gt;\r\n&lt;h1&gt;Search Engines&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;<br />\r\n&lt;p&gt;&lt;a href=&quot;#&quot; class=&quot;button shadow&quot;&gt;Read More&lt;/a&gt;&lt;/p&gt;&lt;br class=&quot;clear&quot; /&gt;', '&lt;img width=&quot;305&quot; height=&quot;220&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/seo.png&quot; alt=&quot;seo.png&quot; style=&quot;margin-left: 15px; float: right;&quot; /&gt;\r\n&lt;h1&gt;Search Engines&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;<br />\r\n&lt;p&gt;&lt;a href=&quot;#&quot; class=&quot;button shadow&quot;&gt;Read More&lt;/a&gt;&lt;/p&gt;&lt;br class=&quot;clear&quot; /&gt;', '&lt;img width=&quot;305&quot; height=&quot;220&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/seo.png&quot; alt=&quot;seo.png&quot; style=&quot;margin-left: 15px; float: right;&quot; /&gt;\r\n&lt;h1&gt;Search Engines&lt;/h1&gt;\r\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis  facilisis dapibus tincidunt. Aliquam non mauris ac urna pretium  malesuada. Mauris viverra fringilla lectus, nec congue neque adipiscing  ultrices.&lt;/p&gt;\r\n&lt;p&gt;Nulla vel magna in leo mattis congue in eget quam. Proin  dignissim nunc vitae nunc euismod sollicitudin. Nullam pretium placerat  eleifend. Aliquam erat volutpat. Nunc et massa nisl, lacinia pharetra  eros. In sit amet augue a ante tincidunt viverra.&lt;/p&gt;<br />\r\n&lt;p&gt;&lt;a href=&quot;#&quot; class=&quot;button shadow&quot;&gt;Read More&lt;/a&gt;&lt;/p&gt;&lt;br class=&quot;clear&quot; /&gt;', '3', '1');


-- --------------------------------------------------
# -- Table structure for table `mod_twitter_config`
-- --------------------------------------------------
DROP TABLE IF EXISTS `mod_twitter_config`;
CREATE TABLE `mod_twitter_config` (
  `username` varchar(150) DEFAULT NULL,
  `counter` int(1) NOT NULL DEFAULT '5',
  `speed` varchar(6) NOT NULL,
  `show_image` tinyint(1) NOT NULL DEFAULT '1',
  `timeout` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `mod_twitter_config`
-- --------------------------------------------------

INSERT INTO `mod_twitter_config` (`username`, `counter`, `speed`, `show_image`, `timeout`) VALUES ('EriwebDotCom', '5', '300', '1', '10000');


-- --------------------------------------------------
# -- Table structure for table `modules`
-- --------------------------------------------------
DROP TABLE IF EXISTS `modules`;
CREATE TABLE `modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(120) NOT NULL,
  `title_sa` varchar(120) NOT NULL,
  `title_er` varchar(120) NOT NULL,
  `body` text,
  `body_sa` text,
  `body_er` text,
  `show_title` tinyint(1) NOT NULL DEFAULT '0',
  `alt_class` varchar(100) NOT NULL DEFAULT '',
  `position` int(11) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT '0',
  `info` text,
  `info_sa` text,
  `info_er` text,
  `modalias` varchar(50) NOT NULL,
  `hasconfig` tinyint(1) NOT NULL DEFAULT '0',
  `sidebar` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `modules`
-- --------------------------------------------------

INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('1', 'Testimonials', 'Testimonials', 'Testimonials', '&lt;p class=&quot;testimonial&quot;&gt;&lt;em&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi.&lt;/em&gt;&lt;/p&gt;\r\n&lt;em&gt;John Smith&lt;/em&gt;, &lt;strong&gt;www.somesite.com&lt;/strong&gt;', '&lt;p class=&quot;testimonial&quot;&gt;&lt;em&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi.&lt;/em&gt;&lt;/p&gt;\r\n&lt;em&gt;John Smith&lt;/em&gt;, &lt;strong&gt;www.somesite.com&lt;/strong&gt;', '&lt;p class=&quot;testimonial&quot;&gt;&lt;em&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi.&lt;/em&gt;&lt;/p&gt;\r\n&lt;em&gt;John Smith&lt;/em&gt;, &lt;strong&gt;www.somesite.com&lt;/strong&gt;', '1', 'green', '1', '0', '', '', '', '', '0', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('2', 'News Slider', 'متزلج الأخبار', 'News Slider', '', '\n', '', '1', '', '2', '1', 'Displays latest news items', 'Displays latest news items', 'Displays latest news items', 'newsslider', '1', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('8', 'More Pages', 'More Pages', 'More Pages', '&lt;ul class=&quot;lists&quot;&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Home&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Page Types&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Templates&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;About Us&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Services &lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Projects&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Blog&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Contact Us&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;', '&lt;ul class=&quot;lists&quot;&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Home&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Page Types&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Templates&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;About Us&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Services &lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Projects&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Blog&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Contact Us&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;', '&lt;ul class=&quot;lists&quot;&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Home&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Page Types&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Templates&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;About Us&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Services &lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Projects&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Blog&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Contact Us&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '', '0', '0', '', '', '', '', '0', '1', '2010-07-22 11:38:51', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('3', 'An unordered list', 'An unordered list', 'An unordered list', 'This modul contains a dummy list of items\r\n&lt;ul&gt;\r\n    &lt;li&gt;List item 1&lt;/li&gt;\r\n    &lt;li&gt;List item 2&lt;/li&gt;\r\n    &lt;li&gt;List item 3&lt;/li&gt;\r\n    &lt;li&gt;List item 4&lt;/li&gt;\r\n&lt;/ul&gt;', 'This modul contains a dummy list of items\r\n&lt;ul&gt;\r\n    &lt;li&gt;List item 1&lt;/li&gt;\r\n    &lt;li&gt;List item 2&lt;/li&gt;\r\n    &lt;li&gt;List item 3&lt;/li&gt;\r\n    &lt;li&gt;List item 4&lt;/li&gt;\r\n&lt;/ul&gt;', 'This modul contains a dummy list of items\r\n&lt;ul&gt;\r\n    &lt;li&gt;List item 1&lt;/li&gt;\r\n    &lt;li&gt;List item 2&lt;/li&gt;\r\n    &lt;li&gt;List item 3&lt;/li&gt;\r\n    &lt;li&gt;List item 4&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '', '1', '0', '', '', '', '', '0', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('4', 'Info Point', 'Info Point', 'Info Point', '&lt;ul id=&quot;infopoint-list&quot;&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/iphone.png&quot; /&gt; Cum sociis natoque penatibus et magnis dis parturient montes&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/green.png&quot; /&gt; Curabitur mollis, lectus sit amet bibendum faucibus ligula&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/installer_box.png&quot; /&gt; Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/headphone.png&quot; /&gt; Cras ullamcorper suscipit  justo, at mattis odio auctor quis alteno&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/coins.png&quot; /&gt; Vestibulum  auctor, magna sit amet pulvinar tristique, nunc felis viverra&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/color_wheel.png&quot; /&gt; Integer aliquet libero sed lorem consequat ut tempus faucibus&lt;/li&gt;\r\n&lt;/ul&gt;', '&lt;ul id=&quot;infopoint-list&quot;&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/iphone.png&quot; /&gt; Cum sociis natoque penatibus et magnis dis parturient montes&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/green.png&quot; /&gt; Curabitur mollis, lectus sit amet bibendum faucibus ligula&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/installer_box.png&quot; /&gt; Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/headphone.png&quot; /&gt; Cras ullamcorper suscipit  justo, at mattis odio auctor quis alteno&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/coins.png&quot; /&gt; Vestibulum  auctor, magna sit amet pulvinar tristique, nunc felis viverra&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/color_wheel.png&quot; /&gt; Integer aliquet libero sed lorem consequat ut tempus faucibus&lt;/li&gt;\r\n&lt;/ul&gt;', '&lt;ul id=&quot;infopoint-list&quot;&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/iphone.png&quot; /&gt; Cum sociis natoque penatibus et magnis dis parturient montes&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/green.png&quot; /&gt; Curabitur mollis, lectus sit amet bibendum faucibus ligula&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/installer_box.png&quot; /&gt; Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/headphone.png&quot; /&gt; Cras ullamcorper suscipit  justo, at mattis odio auctor quis alteno&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/coins.png&quot; /&gt; Vestibulum  auctor, magna sit amet pulvinar tristique, nunc felis viverra&lt;/li&gt;\r\n    &lt;li&gt;&lt;img alt=&quot;&quot; src=&quot;http://eriweb.eu5.org/uploads/icons/color_wheel.png&quot; /&gt; Integer aliquet libero sed lorem consequat ut tempus faucibus&lt;/li&gt;\r\n&lt;/ul&gt;', '1', 'red', '1', '0', '', '', '', '', '0', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('5', 'Our Contact Numbers', 'Our Contact Numbers', 'Our Contact Numbers', '&lt;strong&gt;Office&lt;/strong&gt; +1-416-123456789&lt;br /&gt;\r\n&lt;strong&gt;helpdesk&lt;/strong&gt; +1-416-123456789&lt;br /&gt;', '&lt;strong&gt;Office&lt;/strong&gt; +1-416-123456789&lt;br /&gt;\r\n&lt;strong&gt;helpdesk&lt;/strong&gt; +1-416-123456789&lt;br /&gt;', '&lt;strong&gt;Office&lt;/strong&gt; +1-416-123456789&lt;br /&gt;\r\n&lt;strong&gt;helpdesk&lt;/strong&gt; +1-416-123456789&lt;br /&gt;', '1', '', '2', '0', '', '', '', '', '0', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('6', 'jQuery Slider', 'مسج المتزلج', 'jQuery Slider', '', '\n', '', '0', '', '3', '1', 'jQuery Slider is one great way to display portfolio pieces, eCommerce product images, or even as an image gallery.', 'jQuery Slider is one great way to display portfolio pieces, eCommerce product images, or even as an image gallery.', 'jQuery Slider is one great way to display portfolio pieces, eCommerce product images, or even as an image gallery.', 'jqueryslider', '1', '1', '2010-07-20 14:10:15', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('11', 'Contact Us using the Azel Pharmaceutical Share Co. Contact Information below', 'يمكنكم ان تتصل بنا باستخدام معلومات الاتصال أدناه لآز ل الصيدلانية حصة الشركة', 'በዚ ኣብ ታሕቲ ዝርከብ ናይ ኣዘል ፋርማሱቲካል ናይ ወኸሳ ሓበሬታ ኣቢልኩም ክትውከሱና ትኽእሉ', '\n&lt;ul&gt;\n\t&lt;li&gt;\n\t\t&lt;p&gt;&lt;br /&gt;\n\t\t\t&lt;/p&gt;\n\t\t&lt;p&gt;&lt;strong&gt;\n\t\t\t\t&lt;table style=&quot;text-align: center; border-collapse: collapse; width: 100%;&quot;&gt;\n\t\t\t\t\t&lt;tbody&gt;\n\t\t\t\t\t\t&lt;tr&gt;\n\t\t\t\t\t\t\t&lt;td&gt;\n\t\t\t\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;PLANT ADDRESS&lt;/strong&gt;&lt;/p&gt;\n\t\t\t\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;P.O.Box 89 Keren, Eritrea&lt;/p&gt;\n\t\t\t\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;Tel : 291-1-400233/34&lt;/p&gt;\n\t\t\t\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;Fax: 291-1-400235&lt;/p&gt;\n\t\t\t\t\t\t\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/td&gt;\n\t\t\t\t\t\t\t&lt;td&gt;\n\t\t\t\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;&lt;strong&gt;COMMERCIAL OFFICE ADDRESS&lt;/strong&gt;&lt;/p&gt;\n\t\t\t\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;P.O.Box 6799- Asmara, Eritrea&lt;/p&gt;\n\t\t\t\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;Tel: 291-1-121991&lt;/p&gt;\n\t\t\t\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;175-11Str., No.51&lt;/p&gt;\n\t\t\t\t\t\t\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/td&gt;\n\t\t\t\t\t\t\t&lt;td&gt;\n\t\t\t\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;Email:&amp;nbsp;&lt;/span&gt;&lt;a href=&quot;mailto:azelph@tse.com.er&quot;&gt;azel@azelpharma.com&lt;/a&gt;&lt;/p&gt;\n\t\t\t\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;Fax: 291-1-121002 or&lt;/p&gt;\n\t\t\t\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;Fax: 291-1-126455&lt;br /&gt;\n\t\t\t\t\t\t\t\t\t&lt;/p&gt;\n\t\t\t\t\t\t\t\t&lt;div style=&quot;text-align: center;&quot;&gt;&lt;br /&gt;\n\t\t\t\t\t\t\t\t\t&lt;/div&gt;\n\t\t\t\t\t\t\t\t&lt;div style=&quot;text-align: center;&quot;&gt;&lt;br /&gt;\n\t\t\t\t\t\t\t\t\t&lt;/div&gt;&lt;/td&gt;\n\t\t\t\t\t\t&lt;/tr&gt;\n\t\t\t\t\t&lt;/tbody&gt;\n\t\t\t\t&lt;/table&gt;&lt;/strong&gt;&lt;/p&gt;\n\t\t&lt;div style=&quot;text-align: center;&quot;&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;&lt;/li&gt;\n&lt;/ul&gt;   ', '\n&lt;div style=&quot;text-align: center;&quot;&gt;&amp;nbsp;&lt;/div&gt;\n&lt;div&gt;\n\t&lt;p&gt;&lt;strong&gt;\n\t\t\t&lt;table style=&quot;text-align: center;&quot;&gt;\n\t\t\t\t&lt;tbody&gt;\n\t\t\t\t\t&lt;tr&gt;\n\t\t\t\t\t\t&lt;td&gt;\n\t\t\t\t\t\t\t&lt;p&gt;&lt;strong style=&quot;font-size: 13px; line-height: 1.4em;&quot;&gt;\n\t\t\t\t\t\t\t\t\t&lt;table style=&quot;text-align: center; display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;tbody style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;tr style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t&lt;td style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;div style=&quot;display: inline !important;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;عنوان المصنع&lt;/span&gt;&lt;/div&gt;&lt;/td&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;/tr&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;/tbody&gt;\n\t\t\t\t\t\t\t\t\t&lt;/table&gt;&lt;/strong&gt;&lt;/p&gt;\n\t\t\t\t\t\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\t\t\t\t\t\t\t&lt;div&gt;&lt;strong style=&quot;font-size: 13px; line-height: 1.4em;&quot;&gt;\n\t\t\t\t\t\t\t\t\t&lt;table style=&quot;text-align: center; display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;tbody style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;tr style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t&lt;td style=&quot;display: inline !important;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;p style=&quot;display: inline !important;&quot;&gt;&amp;nbsp;&lt;/p&gt;&lt;/span&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;div style=&quot;display: inline !important;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;صندوق بريد &lt;/span&gt;89&lt;span style=&quot;font-weight: bold;&quot;&gt; كيرين، إريتريا&lt;/span&gt;&lt;/div&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;p style=&quot;font-weight: bold;&quot;&gt;&amp;nbsp;&lt;/p&gt;&lt;/td&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;/tr&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;/tbody&gt;\n\t\t\t\t\t\t\t\t\t&lt;/table&gt;&lt;/strong&gt;&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;div&gt;&lt;span style=&quot;font-size: 13px; line-height: 1.4em; font-weight: bold;&quot;&gt;\n\t\t\t\t\t\t\t\t\t&lt;table style=&quot;text-align: center; display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;tbody style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;tr style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t&lt;td style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;p style=&quot;display: inline !important;&quot;&gt;&amp;nbsp;&lt;/p&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;div style=&quot;display: inline !important;&quot;&gt;الهاتف: 291-1-400233/34&lt;/div&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/td&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;/tr&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;/tbody&gt;\n\t\t\t\t\t\t\t\t\t&lt;/table&gt;&lt;/span&gt;&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;div&gt;&lt;strong style=&quot;font-size: 13px; line-height: 1.4em;&quot;&gt;\n\t\t\t\t\t\t\t\t\t&lt;table style=&quot;text-align: center; display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;tbody style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;tr style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t&lt;td style=&quot;display: inline !important;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;p style=&quot;display: inline !important;&quot;&gt;&amp;nbsp;&lt;/p&gt;&lt;/span&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;div style=&quot;display: inline !important;&quot;&gt;الفاكس: 291-1-400235&lt;/div&gt;&lt;/td&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;/tr&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;/tbody&gt;\n\t\t\t\t\t\t\t\t\t&lt;/table&gt;&lt;br /&gt;\n\t\t\t\t\t\t\t\t\t&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&lt;/strong&gt;&lt;/div&gt;&lt;/td&gt;\n\t\t\t\t\t\t&lt;td&gt;\n\t\t\t\t\t\t\t&lt;div&gt;&lt;strong&gt;&lt;strong style=&quot;font-size: 13px; line-height: 1.4em;&quot;&gt;&lt;strong&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;table&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t&lt;tbody&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;tr&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;td&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;p&gt;&lt;strong&gt;&lt;/strong&gt;&lt;/p&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;div&gt;&lt;strong&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&lt;/strong&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;عنوان مكتب التجاري&lt;/span&gt;&lt;/div&gt;&lt;/td&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;/tr&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t&lt;/tbody&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;/table&gt;&lt;/strong&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;table style=&quot;text-align: center; display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;tbody style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t&lt;tr style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;td style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;div style=&quot;display: inline !important;&quot;&gt;&lt;strong&gt;صندوق بريد &lt;/strong&gt;6799&lt;strong&gt; - أسمرة، إريتريا&lt;/strong&gt;&lt;/div&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/td&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t&lt;/tr&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;/tbody&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;/table&gt;&lt;/strong&gt;&lt;/strong&gt;&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;div&gt;&lt;strong style=&quot;font-size: 13px; line-height: 1.4em;&quot;&gt;\n\t\t\t\t\t\t\t\t\t&lt;table style=&quot;text-align: center; display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;tbody style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;tr style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t&lt;td style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;div style=&quot;display: inline !important;&quot;&gt;&lt;strong&gt;الهاتف: &lt;/strong&gt;291-1-121991&lt;/div&gt;&lt;/td&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;/tr&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;/tbody&gt;\n\t\t\t\t\t\t\t\t\t&lt;/table&gt;&lt;/strong&gt;&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;div&gt;&lt;strong style=&quot;font-size: 13px; line-height: 1.4em;&quot;&gt;\n\t\t\t\t\t\t\t\t\t&lt;table style=&quot;text-align: center; display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;tbody style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;tr style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t&lt;td style=&quot;display: inline !important;&quot;&gt;\n\t\t\t\t\t\t\t\t\t\t\t\t\t&lt;div style=&quot;display: inline !important;&quot;&gt;&lt;strong&gt;شارع &lt;/strong&gt;175&lt;strong&gt;-&lt;/strong&gt;11&lt;strong&gt;، رقم&lt;/strong&gt; 51&lt;/div&gt;&lt;/td&gt;\n\t\t\t\t\t\t\t\t\t\t\t&lt;/tr&gt;\n\t\t\t\t\t\t\t\t\t\t&lt;/tbody&gt;\n\t\t\t\t\t\t\t\t\t&lt;/table&gt;&lt;br /&gt;\n\t\t\t\t\t\t\t\t\t&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&lt;/strong&gt;&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/td&gt;\n\t\t\t\t\t\t&lt;td&gt;\n\t\t\t\t\t\t\t&lt;p&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;&lt;/span&gt;&lt;/p&gt;\n\t\t\t\t\t\t\t&lt;div&gt;:البريد الإلكتروني&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t\t\t\t\t\t&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;div&gt;azel@azelpharma.com&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t\t\t\t\t\t&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;div&gt;الفاكس: 291-1-121002 أو&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t\t\t\t\t\t&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;div&gt;الفاكس: 291-1-126455&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;div&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&amp;nbsp;&lt;/div&gt;\n\t\t\t\t\t\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/td&gt;\n\t\t\t\t\t&lt;/tr&gt;\n\t\t\t\t&lt;/tbody&gt;\n\t\t\t&lt;/table&gt;&lt;br /&gt;\n\t\t\t&lt;/strong&gt;&lt;/p&gt;&lt;/div&gt; ', '\n&lt;ul style=&quot;&quot;&gt;\n&lt;/ul&gt;\n&lt;table&gt;\n\t&lt;tbody&gt;\n\t\t&lt;tr&gt;\n\t\t\t&lt;td&gt;&lt;br /&gt;\n\t\t\t\t&lt;/td&gt;\n\t\t\t&lt;td&gt;&lt;br /&gt;\n\t\t\t\t&lt;/td&gt;\n\t\t\t&lt;td&gt;&lt;br /&gt;\n\t\t\t\t&lt;/td&gt;\n\t\t&lt;/tr&gt;\n\t&lt;/tbody&gt;\n&lt;/table&gt;\n&lt;ul style=&quot;&quot;&gt;\n\t&lt;li&gt;\n\t\t&lt;ul&gt;\n\t\t\t&lt;li&gt;\n\t\t\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/li&gt;\n\t\t&lt;/ul&gt;&lt;/li&gt;\n&lt;/ul&gt;\n&lt;p style=&quot;line-height: 1.4em;&quot;&gt;&lt;br /&gt;\n\t&lt;/p&gt;\n&lt;p style=&quot;line-height: 1.4em;&quot;&gt;\n\t&lt;table&gt;\n\t\t&lt;tbody&gt;\n\t\t\t&lt;tr&gt;\n\t\t\t\t&lt;td&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;ኣድራሻ ፋብሪካ&lt;/span&gt;&lt;/p&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;ቁ.ሳ.ፖስታ 89 ከረን, ኤርትራ&lt;/p&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;ቁ. ስልኪ : 291-1-400233/34&lt;/p&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;ፋክስ: 291-1-400235&lt;/p&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&amp;nbsp;&lt;/p&gt;\n\t\t\t\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/td&gt;\n\t\t\t\t&lt;td&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;&amp;nbsp;ኣድራሻ ንግዳዊ ቤት-ጽሕፈት&lt;/span&gt;&lt;/p&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;ቁ.ሳ.ፖስታ 6799 - ኣስመራ, ኤርትራ&lt;/p&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;ቁ.ስልኪ: 291-1-121991&lt;/p&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;ጎደና 175-11, ቁ.51&lt;/p&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&lt;/p&gt;\n\t\t\t\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/td&gt;\n\t\t\t\t&lt;td&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-weight: bold;&quot;&gt;ኢ-መይል:&amp;nbsp;&lt;/span&gt;&lt;a href=&quot;mailto:azelph@tse.com.er&quot;&gt;azel@azelpharma.com&lt;/a&gt;&lt;/p&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;ፋክስ: 291-1-121002 or&lt;/p&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;ፋክስ: 291-1-126455&lt;br /&gt;\n\t\t\t\t\t\t&lt;/p&gt;\n\t\t\t\t\t&lt;p style=&quot;text-align: center;&quot;&gt;&lt;br /&gt;\n\t\t\t\t\t\t&lt;/p&gt;\n\t\t\t\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t\t\t\t&lt;/div&gt;\n\t\t\t\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t\t\t\t&lt;/div&gt;&lt;/td&gt;\n\t\t\t&lt;/tr&gt;\n\t\t&lt;/tbody&gt;\n\t&lt;/table&gt;&lt;/p&gt;\n&lt;ul style=&quot;&quot;&gt;\n\t&lt;li&gt;&lt;/li&gt;\n&lt;/ul&gt;    ', '1', '', '0', '0', '', '', '', '', '0', '1', '2010-07-22 11:44:15', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('9', 'Even More Pages', 'Even More Pages', 'Even More Pages', '&lt;ul class=&quot;lists&quot;&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Updates&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;News&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Press Releases&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;New Offers&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Our Staff &lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Policy&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Events&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;', '&lt;ul class=&quot;lists&quot;&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Updates&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;News&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Press Releases&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;New Offers&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Our Staff &lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Policy&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Events&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;', '&lt;ul class=&quot;lists&quot;&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Updates&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;News&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Press Releases&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;New Offers&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Our Staff &lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Policy&lt;/a&gt;&lt;/li&gt;\r\n    &lt;li&gt;&lt;a href=&quot;#&quot;&gt;Events&lt;/a&gt;&lt;/li&gt;\r\n&lt;/ul&gt;', '1', '', '0', '0', '', '', '', '', '0', '1', '2010-07-22 11:39:22', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('10', 'Latest Twitts', 'أحدث من تويتر', 'Latest Twitts', '', '\n', '', '1', '', '4', '1', 'Shows your latest twitts', 'Shows your latest twitts', 'Shows your latest twitts', 'twitts', '1', '1', '2010-07-22 11:42:08', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('13', 'Ajax Poll', 'اياكس الإستطلاع', 'Ajax Poll', '', '\n', '', '1', '', '5', '1', 'jQuery Ajax poll module.', 'jQuery Ajax poll module.', 'jQuery Ajax poll module.', 'poll', '1', '1', '2010-10-25 14:12:20', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('7', 'jQuery Tabs', 'مسج علامات التبويب', 'jQuery Tabs', '', '\n', '', '0', '', '7', '1', 'jQuery Dynamic Tabs', 'jQuery Dynamic Tabs', 'jQuery Dynamic Tabs', 'jtabs', '1', '1', '2010-12-20 12:12:20', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('12', 'Event Manager', 'مدير الحدث', 'Event Manager', '', '\n', '', '1', '', '8', '1', 'Easily publish and manage your company events.', 'Easily publish and manage your company events.', 'Easily publish and manage your company events.', 'events', '1', '1', '2010-12-28 10:12:14', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('14', 'Vertical Navigation', 'الإنتقال العمودي', 'Vertical Navigation', '', '\n', '', '1', '', '9', '1', 'Vertical flyout menu module', 'Vertical flyout menu module', 'Vertical flyout menu module', 'vmenu', '0', '1', '2010-12-27 08:12:14', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('15', 'Commenting System', 'نظام التعليق', 'Commenting System', '', '\n', '', '0', '', '10', '1', 'Encourage your readers to join in the discussion and leave comments and respond promptly to the comments left by your readers to make them feel valued', 'Encourage your readers to join in the discussion and leave comments and respond promptly to the comments left by your readers to make them feel valued', 'Encourage your readers to join in the discussion and leave comments and respond promptly to the comments left by your readers to make them feel valued', 'comments', '1', '0', '2011-01-10 14:10:24', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('16', 'Rss Parser', 'RSS محلل', 'Rss Parser', '', '\n', '', '1', '', '12', '1', 'Show rss feeds (RSS 0.9 / RSS 1.0). Also RSS 2.0, and Atom a with few exceptions.', 'Show rss feeds (RSS 0.9 / RSS 1.0). Also RSS 2.0, and Atom a with few exceptions.', 'Show rss feeds (RSS 0.9 / RSS 1.0). Also RSS 2.0, and Atom a with few exceptions.', 'rss', '1', '1', '2011-04-16 08:11:55', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('17', 'Gallery', 'صالة عرض', 'Gallery', '', '\n', '', '0', '', '13', '1', 'Fully featured gallery module', 'Fully featured gallery module', 'Fully featured gallery module', 'gallery', '1', '0', '2011-04-28 06:19:32', '1');
INSERT INTO `modules` (`id`, `title`, `title_sa`, `title_er`, `body`, `body_sa`, `body_er`, `show_title`, `alt_class`, `position`, `system`, `info`, `info_sa`, `info_er`, `modalias`, `hasconfig`, `sidebar`, `created`, `active`) VALUES ('18', 'User Login', 'دخول المستخدم', 'User Login', '', '\n', '', '1', 'blue', '14', '1', 'Shows login form.', 'Shows login form.', 'Shows login form.', 'login', '0', '1', '2011-05-10 02:12:14', '1');


-- --------------------------------------------------
# -- Table structure for table `pages`
-- --------------------------------------------------
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `title_sa` varchar(200) NOT NULL,
  `title_er` varchar(200) NOT NULL,
  `slug` varchar(150) NOT NULL,
  `slug_sa` varchar(150) NOT NULL,
  `slug_er` varchar(150) NOT NULL,
  `contact_form` tinyint(1) NOT NULL DEFAULT '0',
  `cform` int(4) NOT NULL DEFAULT '0',
  `gallery_id` int(4) NOT NULL DEFAULT '0',
  `comments` tinyint(1) NOT NULL DEFAULT '0',
  `membership_id` int(6) NOT NULL DEFAULT '0',
  `access` enum('Public','Registered','Membership') NOT NULL DEFAULT 'Public',
  `keywords` text NOT NULL,
  `keywords_sa` text,
  `keywords_er` text,
  `description` text NOT NULL,
  `description_sa` text,
  `description_er` text,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `pages`
-- --------------------------------------------------

INSERT INTO `pages` (`id`, `title`, `title_sa`, `title_er`, `slug`, `slug_sa`, `slug_er`, `contact_form`, `cform`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `keywords_sa`, `keywords_er`, `description`, `description_sa`, `description_er`, `created`, `active`) VALUES ('1', 'Home', 'الصفحة الرئيسية', 'ርእሰ ገጽ', 'Home', '-', 'Home', '0', '0', '0', '0', '0', 'Public', 'EriwebliteCMS, Eriweb CMS, Content Menagement System, Lightweight CMS', 'EriwebliteCMS, Eriweb CMS, Content Menagement System, Lightweight CMS', 'EriwebliteCMS, Eriweb CMS, Content Menagement System, Lightweight CMS', 'Eriweb CMS is a web content management system made for the peoples who don&#39;t have much technical knowledge of HTML or PHP but know how to use a simple notepad with computer keyboard.', 'Eriweb CMS is a web content management system made for the peoples who don&#039;t have much technical knowledge of HTML or PHP but know how to use a simple notepad with computer keyboard.', 'Eriweb CMS is a web content management system made for the peoples who don&#039;t have much technical knowledge of HTML or PHP but know how to use a simple notepad with computer keyboard.', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `title_sa`, `title_er`, `slug`, `slug_sa`, `slug_er`, `contact_form`, `cform`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `keywords_sa`, `keywords_er`, `description`, `description_sa`, `description_er`, `created`, `active`) VALUES ('2', 'What is Eriweb', 'ما هو إريويب', 'What is Eriweb', 'What-is-Eriweb', '-', 'What-is-Eriweb', '0', '0', '0', '1', '0', 'Public', 'Eriweb, Content Management System, Lightweight CMS', 'Eriweb, Content Management System, Lightweight CMS', 'Eriweb, Content Management System, Lightweight CMS', 'Eriweb is a php based database dependent CMS which require one database and obviously php language support on your web hosting server.', 'Eriweb is a php based database dependent CMS which require one database and obviously php language support on your web hosting server.', 'Eriweb is a php based database dependent CMS which require one database and obviously php language support on your web hosting server.', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `title_sa`, `title_er`, `slug`, `slug_sa`, `slug_er`, `contact_form`, `cform`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `keywords_sa`, `keywords_er`, `description`, `description_sa`, `description_er`, `created`, `active`) VALUES ('3', 'Contact Info', 'معلومات الاتصال', 'Contact Info', 'Contact-Info', '-', 'Contact-Info', '1', '0', '0', '0', '0', 'Public', '', '', '', '', '', '', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `title_sa`, `title_er`, `slug`, `slug_sa`, `slug_er`, `contact_form`, `cform`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `keywords_sa`, `keywords_er`, `description`, `description_sa`, `description_er`, `created`, `active`) VALUES ('5', 'Demo Gallery', 'عرض معرض', 'Demo Gallery', 'Demo-Gallery', '-', 'Demo-Gallery', '0', '0', '1', '0', '0', 'Public', '', '', '', '', '', '', '2010-07-22 20:11:55', '1');
INSERT INTO `pages` (`id`, `title`, `title_sa`, `title_er`, `slug`, `slug_sa`, `slug_er`, `contact_form`, `cform`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `keywords_sa`, `keywords_er`, `description`, `description_sa`, `description_er`, `created`, `active`) VALUES ('6', 'Three Column Page', 'ثلاثة عمود الصفحة', 'Three Column Page', 'Tree-Column-Page', '-', 'Tree-Column-Page', '0', '0', '0', '0', '0', 'Public', '', '', '', '', '', '', '2010-07-22 20:26:17', '1');
INSERT INTO `pages` (`id`, `title`, `title_sa`, `title_er`, `slug`, `slug_sa`, `slug_er`, `contact_form`, `cform`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `keywords_sa`, `keywords_er`, `description`, `description_sa`, `description_er`, `created`, `active`) VALUES ('7', 'All Modules', 'جميع وحدات', 'All Modules', 'All-Modules', '-', 'All-Modules', '0', '0', '0', '0', '0', 'Public', '', '', '', '', '', '', '2010-07-22 20:40:19', '1');
INSERT INTO `pages` (`id`, `title`, `title_sa`, `title_er`, `slug`, `slug_sa`, `slug_er`, `contact_form`, `cform`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `keywords_sa`, `keywords_er`, `description`, `description_sa`, `description_er`, `created`, `active`) VALUES ('8', 'More Pages', 'المزيد من الصفحات', 'More Pages', 'More-Pages', '-', 'More-Pages', '0', '0', '0', '0', '0', 'Public', '', '', '', '', '', '', '2010-08-09 22:06:58', '1');
INSERT INTO `pages` (`id`, `title`, `title_sa`, `title_er`, `slug`, `slug_sa`, `slug_er`, `contact_form`, `cform`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `keywords_sa`, `keywords_er`, `description`, `description_sa`, `description_er`, `created`, `active`) VALUES ('9', 'Members Only', 'الأعضاء فقط', 'Members Only', 'Members-Only', '-', 'Members-Only', '0', '0', '0', '0', '0', 'Registered', '', '', '', '', '', '', '2011-05-19 15:28:29', '1');
INSERT INTO `pages` (`id`, `title`, `title_sa`, `title_er`, `slug`, `slug_sa`, `slug_er`, `contact_form`, `cform`, `gallery_id`, `comments`, `membership_id`, `access`, `keywords`, `keywords_sa`, `keywords_er`, `description`, `description_sa`, `description_er`, `created`, `active`) VALUES ('11', 'Asmara Hotels', 'فنادق في أسمره', '', 'asmarahotels', '-', '', '0', '0', '0', '0', '0', 'Public', 'hotel savanna international, hotel asmara palace', '', '', 'hotels', '', '', '2013-04-30 03:04:56', '1');


-- --------------------------------------------------
# -- Table structure for table `payments`
-- --------------------------------------------------
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `txn_id` varchar(100) DEFAULT NULL,
  `membership_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rate_amount` varchar(255) NOT NULL,
  `currency` varchar(4) DEFAULT NULL,
  `date` datetime NOT NULL,
  `pp` enum('PayPal','MoneyBookers') DEFAULT NULL,
  `ip` varchar(20) DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `payments`
-- --------------------------------------------------

INSERT INTO `payments` (`id`, `txn_id`, `membership_id`, `user_id`, `rate_amount`, `currency`, `date`, `pp`, `ip`, `status`) VALUES ('1', '', '2', '1', '5.00', '', '2011-04-05 14:12:32', 'PayPal', '', '1');


-- --------------------------------------------------
# -- Table structure for table `posts`
-- --------------------------------------------------
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `title_sa` varchar(150) NOT NULL,
  `title_er` varchar(150) NOT NULL,
  `show_title` tinyint(1) NOT NULL DEFAULT '1',
  `body` text NOT NULL,
  `body_sa` text,
  `body_er` text,
  `position` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `posts`
-- --------------------------------------------------

INSERT INTO `posts` (`id`, `page_id`, `title`, `title_sa`, `title_er`, `show_title`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('1', '1', 'Welcome to Eriweb', 'مرحبا بكم في  إريويب', 'ናብ ኤሪ-ዌብ እንቋዕ ብደሓን መጻእኩም', '0', '\n&lt;div style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;line-height: 1.4em;&quot;&gt;Welcome to our &amp;nbsp;website.&amp;nbsp;&lt;/span&gt;&lt;span style=&quot;line-height: 1.4em;&quot;&gt;For best browsing experience, use Mozilla Firefox or Google Chrome.&lt;/span&gt;&lt;/div&gt;\n&lt;div&gt;\n\t&lt;div style=&quot;text-align: center;&quot;&gt;&lt;br /&gt;\n\t\t&lt;/div&gt;\n\t&lt;div style=&quot;text-align: center;&quot;&gt;Azel pharmaceutical Sh.Co. established in 1994 as a joint venture share company between the Ministry of Health of the State of Eritrea and the Jordanian Pharmaceutical Manufacturing Company (JPM) in June 2003 to meet the demand for quality pharmaceutical products . The factory is situated in Keren a town 91km north of the capital Asmara&lt;br /&gt;\n\t\t&lt;/div&gt;&lt;hr style=&quot;text-align: center;&quot; /&gt;\n\t\n\t&lt;div class=&quot;col-31&quot;&gt;\n\t\t&lt;h3&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; Our Mission&lt;/h3&gt;\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\t\t&lt;ul&gt;\n\t\t\t&lt;li&gt;Azel pharma recognizes the right of all people to consume a pharmaceutical medication with confidence of the purity and effectiveness of their life saving products.&lt;/li&gt;\n\t\t\t&lt;li&gt;To comply with the current international Good Manufacturing Practices to ensure that all products that all products will retain their purity and efficacy.&lt;/li&gt;\n\t\t\t&lt;li&gt;It is the goal of the company to produce, distribute and sell high quality essential drugs at competitive prices and in widening market coverage.&lt;/li&gt;\n\t\t\t&lt;li&gt;Completion of the course of action of performing WHO prequalification requirements.&lt;/li&gt;\n\t\t\t&lt;li&gt;&lt;/li&gt;\n\t\t&lt;/ul&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/div&gt;\n\t&lt;div class=&quot;col-32&quot;&gt;\n\t\t&lt;h3&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; Company Profile&lt;/h3&gt;\n\t\t&lt;p&gt;&lt;br /&gt;\n\t\t\t&lt;/p&gt;\n\t\t&lt;p&gt;The basic Operations of Azel Pharmaceutical Share Co. can be summarized into the following four main activities. We strive for high quality production of more than 50 different products.&amp;nbsp;&lt;/p&gt;\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\t\t&lt;p&gt;Development and formulation of branded generic pharmaceuticals.&lt;/p&gt;\n\t\t&lt;p&gt;Production of pharmaceutical products.&lt;/p&gt;\n\t\t&lt;p&gt;Providing technical knowhow and advanced training to other companies in our region.&lt;/p&gt;\n\t\t&lt;p&gt;Production of diagnostic kits.&lt;/p&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\t\t&lt;p&gt;&lt;br /&gt;\n\t\t\t&lt;/p&gt;\n\t\t&lt;p&gt;&lt;br /&gt;\n\t\t\t&lt;/p&gt;\n\t\t&lt;p&gt;&lt;br /&gt;\n\t\t\t&lt;/p&gt;\n\t\t&lt;p&gt;&lt;br /&gt;\n\t\t\t&lt;/p&gt;&lt;/div&gt;\n\t&lt;div class=&quot;col-33&quot;&gt;\n\t\t&lt;h3&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; Our Partners&lt;/h3&gt;\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\t\t&lt;ul&gt;\n\t\t\t&lt;li&gt;\n\t\t\t\t&lt;div align=&quot;justify&quot;&gt;The&amp;nbsp;&lt;em&gt;Jordanian Pharmaceutical Manufacturing Co. Ltd. (JPM)&lt;/em&gt;was founded in 1978. It is a privately owned company and produces pharmaceutical products of about 130 of different dosage forms. It is a research oriented manufacturing company and has many publications in basic research topics. JPM markets its products in the Middle East and some African and European countries.&lt;/div&gt;\n\t\t\t\t&lt;div align=&quot;justify&quot;&gt;&lt;br /&gt;\n\t\t\t\t\t&lt;/div&gt;&lt;/li&gt;\n\t\t\t&lt;li&gt;Ministry of Health&lt;/li&gt;\n\t\t&lt;/ul&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;\n\t\t&lt;ul&gt;\n\t\t\t&lt;li&gt;Pharmecor&lt;/li&gt;\n\t\t\t&lt;li&gt;&lt;/li&gt;\n\t\t&lt;/ul&gt;\n\t\t&lt;ul&gt;\n\t\t&lt;/ul&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/div&gt;\n\t&lt;div class=&quot;clear&quot;&gt;&amp;nbsp;&lt;/div&gt; &lt;/div&gt;        ', '\n&lt;div align=&quot;right&quot; style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: 12pt; font-weight: bold; line-height: 1.4em;&quot;&gt;.مرحباً لموقعنا على الانترنت ايها الضيوف الفضلائ&lt;/span&gt;&lt;/div&gt;\n&lt;div align=&quot;right&quot; style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: 12pt; font-weight: bold; line-height: 1.4em;&quot;&gt;&lt;br /&gt;\n\t\t&lt;/span&gt;&lt;/div&gt;\n&lt;div align=&quot;right&quot; style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: 12pt; font-weight: bold;&quot;&gt;آز ل&amp;nbsp;الصيدلانية حصة الشركة أنشئت في &amp;nbsp;عام&amp;nbsp;1994 &amp;nbsp;كشركة حصة المشروع المشترك بين وزارة الصحة في دولة إريتريا والشركة الأردنية لإنتاج الأدوية في يونيو 2003 حزيران لتلبية الطلب على المنتجات الصيدلانية الجودة. يقع المصنع في بلدة كيرين على بعد &amp;nbsp;91كم من شمال العاصمة اسمرة&lt;/span&gt;&lt;/div&gt;\n&lt;div align=&quot;right&quot; style=&quot;text-align: center;&quot;&gt;&lt;br /&gt;\n\t&lt;/div&gt;\n&lt;div align=&quot;left&quot; style=&quot;text-align: center;&quot;&gt;&lt;span style=&quot;font-size: 12pt; font-weight: bold;&quot;&gt;&lt;br /&gt;\n\t\t&lt;/span&gt;&lt;/div&gt;\n&lt;div align=&quot;left&quot; style=&quot;text-align: center;&quot;&gt;&lt;br /&gt;\n\t&lt;/div&gt;\n&lt;div&gt;&lt;hr /&gt;\n\t\n\t&lt;div class=&quot;col-31&quot;&gt;\n\t\t&lt;h3&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; شركاؤنا&lt;/h3&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\t\t&lt;div&gt;تأسست الشركة الأردنية لإنتاج الأدوية في عام 1991، وهي شركة مملوكة للقطاع الخاص وتنتج المنتجات الصيدلانية من حوالي 130 من جرعات مختلفة. بل هو البحوث الموجهة &amp;nbsp;نحو شركة تصنيع ولها العديد من المؤلفات في موضوعات البحوث الأساسية. الشركة تبيع منتجاتها في منطقة الشرق الأوسط وبعض الدول الأفريقية والأوروبية&amp;nbsp;&lt;/div&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;\n\t\t&lt;div&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; وزارة الصحة الإريترية&lt;/div&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;\n\t\t&lt;div&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;(Pharmecor)فارميكور&amp;nbsp;&lt;/div&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/div&gt;\n\t&lt;div class=&quot;col-32&quot;&gt;\n\t\t&lt;h3&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;نبذة عن الشركة &amp;nbsp;&lt;/h3&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;p&gt;العمليات الأساسية للشركة حصة آز ل الدوائية يمكن تلخيصها في الأنشطة الرئيسية الأربعة التالية. ونحن نسعى جاهدين لإنتاج نوعية عالية من أكثر من خمسين المنتجات المختلفة&lt;br /&gt;\n\t\t\t&lt;/p&gt;\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\t\t&lt;div&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; نمية وصياغة الأدوية الجنيسة ذات العلامات التجارية&lt;/div&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;\n\t\t&lt;div&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;إنتاج المنتجات الصيدلانية&lt;/div&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;\n\t\t&lt;div&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; توفير المعرفة التقنية والتدريب المتقدم لشركات أخرى في منطقتنا&lt;/div&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;\n\t\t&lt;div&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; إنتاج أدوات التشخيص&lt;/div&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\t\t&lt;p&gt;&lt;br /&gt;\n\t\t\t&lt;/p&gt;\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/div&gt;\n\t&lt;div class=&quot;col-33&quot;&gt;\n\t\t&lt;h3&gt;&lt;/h3&gt;\n\t\t&lt;h3&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;ما هو مهمتنا؟&lt;/h3&gt;\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\t\t&lt;div&gt;يعترف آز ل فارما حق جميع الناس أن تستهلك الأدوية الصيدلانية مع ثقة نقاء وفعالية المنتجات الموفرة حياتهم&lt;/div&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;\n\t\t&lt;div&gt;على الامتثال لممارسات التصنيع الجيدة الدولية الحالية لضمان أن جميع المنتجات جميع المنتجات التي ستحتفظ نقاء وفعالية.&lt;/div&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;\n\t\t&lt;div&gt;هذا هو هدف الشركة لإنتاج وتوزيع وبيع الأدوية الأساسية عالية الجودة وبأسعار تنافسية وتوسيع نطاق التغطية في السوق.&lt;/div&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;\n\t\t&lt;div&gt;الانتهاء من مسار العمل على أداء متطلبات التأهيل منظمة الصحة العالمية.&lt;/div&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;/div&gt;\n\t&lt;div class=&quot;clear&quot;&gt;&amp;nbsp;&lt;/div&gt;   &lt;/div&gt;         ', '\n&lt;div align=&quot;center&quot;&gt;&lt;span style=&quot;font-size: 12pt;&quot;&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;div align=&quot;center&quot;&gt;ናብ ዌብሳይትና እንቋዕ ብደሓን መጻእኩም። ንዝበለጸ ምርኢት፡ ሞዚላ ፋየርፎክስ ወይ ጉግል ክሮም ተጠቀሙ።&lt;/div&gt;\n\t\t&lt;div align=&quot;center&quot;&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;\n\t\t&lt;div align=&quot;center&quot;&gt;ኣዘል ፋርማሱቲካል (Azel pharmaceutical Sh.Co.) ናይ ብርኪ ትካል ብ1994 ዓ፡ም ብሓባራዊ ኣላይነት ኣብ መንጎ ሚኒስትሪ ጥዕና ሃገረ ኤርትራን ዮርዳኖሳዊ ትካል&amp;nbsp;መፍረ ፋርማሱቲካልን (ማለት Jordanian Pharmaceutical Manufacturing Company (JPM)) ብሰነ 2003 ጠለብ ናይ ብሉጽ ፋርማስያዊ ፍርያት ንምምላእ ከም ሓባራዊ ናይ ብርኪ ትካል ተመስሪቱ። እቲ ፋብሪካ 91ኪሜ ንሸነኽ ሰሜን ካብ ርእሰ-ከተማ ኣስመራ ርሒቑ ኣብ ከተማ ከረን ተደኲኑ ይርከብ።&lt;/div&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;&lt;/span&gt;&lt;br /&gt;\n\t&lt;br /&gt;\n\t&lt;/div&gt;&lt;hr /&gt;\n\n&lt;div class=&quot;col-31&quot;&gt;\n\t&lt;h3&gt;&lt;span style=&quot;font-size: 12pt;&quot;&gt;\n\t\t\t&lt;h3&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;ተልእኾናን ዕላማናን&lt;/h3&gt;&lt;/span&gt;&lt;/h3&gt;&lt;span style=&quot;font-size: 12pt; line-height: 1.4em;&quot;&gt;\n\t\t&lt;ul style=&quot;&quot;&gt;\n\t\t\t&lt;li&gt;&lt;span style=&quot;font-size: 12pt; line-height: 1.4em;&quot;&gt;ትካልና ኣዘል ፋርማ ኩሎም ደቂ-ሰባት ብንጹህነትን ብቕዓትን ናይ ዝወሃቦም ፋርማስያዊ ኣፋውስ &lt;/span&gt;&lt;span style=&quot;font-size: 12pt; line-height: 1.4em;&quot;&gt;ምሉእ ምትእምማን ኣሕዲሮም ህይወቶም ዘድሕኑ መድሃኒታት ናይ ምጥቃም መሰል ከምዘለዎም ዝሰማምዓሉ&#039;ዩ።&lt;/span&gt;&lt;/li&gt;\n\t\t&lt;/ul&gt;&lt;/span&gt;&lt;span style=&quot;font-size: 16px;&quot;&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;ul style=&quot;&quot;&gt;\n\t\t\t&lt;li&gt;&lt;span style=&quot;font-size: 12pt; line-height: 22.390625px;&quot;&gt;ብዘይካ&#039;ዚ ትካልና ብቕቡላት ኣህጉራውያን መምርሒታት ምምስራሕ መድሃኒት ተቐዪዱ ኩሎም ፍርያቱ ንጽህናኦምን ብቕዓቶምን ሓልዮም ከምዝፈርዩ ምርግጋጽ ብቐዳምነት ይሰርሓሉ።&amp;nbsp;&lt;/span&gt;&lt;/li&gt;\n\t\t&lt;/ul&gt;&lt;/span&gt;&lt;span style=&quot;font-size: 16px; line-height: 22.390625px;&quot;&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;ul style=&quot;&quot;&gt;\n\t\t\t&lt;li&gt;&lt;span style=&quot;font-size: 12pt; line-height: 1.4em;&quot;&gt;ዕላማ ናይዚ ትካል ብሉጻትን ኣገደስትን ኣፋውስ ብምፍራይ፡ ኣብ ሰፊሕ ዝርጋሐ ብርትዓዊ ዋጋታት ናብ ዕዳጋ ምቕራብ እዩ።&lt;/span&gt;&lt;/li&gt;\n\t\t&lt;/ul&gt;&lt;/span&gt;&lt;span style=&quot;font-size: 16px;&quot;&gt;&lt;br /&gt;\n\t\t\n\t\t&lt;ul style=&quot;&quot;&gt;\n\t\t\t&lt;li&gt;&lt;span style=&quot;font-size: 12pt; line-height: 1.4em;&quot;&gt;ናይ ዓለማዊ ውድብ ጥዕና ቅድመ-መረጋገጺ ብቕዓት ንዘሎ ንጥፈታት ብግቡእ ምፍጻምን ምምላእን።&lt;/span&gt;&lt;/li&gt;\n\t\t&lt;/ul&gt;&lt;/span&gt;\n\t&lt;p&gt;&lt;span style=&quot;font-size: 12pt;&quot;&gt;&lt;br /&gt;\n\t\t\t&lt;/span&gt;&lt;/p&gt;&lt;/div&gt;\n&lt;div class=&quot;col-32&quot;&gt;\n\t&lt;h3&gt;&lt;span style=&quot;font-size: 12pt;&quot;&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &lt;/span&gt;ብዛዕባ&#039;ዚ ትካል&lt;/h3&gt;\n\t&lt;p style=&quot;font-size: 12pt;&quot;&gt;እቶም መሰረታውያን ስራሓት ናይ ኣዘል ፋርማሱቲካል ኣብዞም ዝስዕቡ ጥብታት ክጠቓለሉ ይኽእሉ። ትካልና ልዕሊ 50 ዝተፈላለዩ ፍርያት ብብቕዓት ኣብ ምምስራሕ ይርከብ።&lt;/p&gt;\n\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;\n\t&lt;ul style=&quot;font-size: 12pt;&quot;&gt;\n\t\t&lt;li&gt;&lt;span style=&quot;font-size: 12pt; line-height: 1.4em;&quot;&gt;ምምዕባልን ምምስራሕን ስሙያት ጀነሪካዊ ፋርማስያዊ ፍርያት&lt;/span&gt;&lt;/li&gt;\n\t&lt;/ul&gt;&lt;span style=&quot;font-size: 16px; line-height: 22.390625px;&quot;&gt;&lt;br /&gt;\n\t\t&lt;/span&gt;\n\t&lt;ul style=&quot;font-size: 12pt;&quot;&gt;\n\t\t&lt;li&gt;&lt;span style=&quot;font-size: 12pt; line-height: 1.4em;&quot;&gt;ኣብ ዞባና ንዝርከባ ካልኦት ትካላት ቴክኒካዊ ፍልጠትን ብሉጽ ስልጠናን ብምሃብ ተሞክሮአን ከምዘዕብያ ምግባር&lt;/span&gt;&lt;/li&gt;\n\t&lt;/ul&gt;&lt;span style=&quot;font-size: 16px; line-height: 22.390625px;&quot;&gt;&lt;br /&gt;\n\t\t&lt;/span&gt;\n\t&lt;ul style=&quot;font-size: 12pt;&quot;&gt;\n\t\t&lt;li&gt;&lt;span style=&quot;line-height: 22.390625px;&quot;&gt;ናይ መድሃኒትን ሕክምናን ኣቑሑ ምፍራይ&lt;/span&gt;&lt;/li&gt;\n\t&lt;/ul&gt;\n\t&lt;div&gt;&lt;span style=&quot;font-size: 16px; line-height: 22.390625px;&quot;&gt;&lt;br /&gt;\n\t\t\t&lt;/span&gt;&lt;/div&gt;\n\t&lt;div&gt;&lt;span style=&quot;font-size: 16px; line-height: 22.390625px;&quot;&gt;&lt;br /&gt;\n\t\t\t&lt;/span&gt;&lt;/div&gt;\n\t&lt;div&gt;&lt;span style=&quot;font-size: 16px; line-height: 22.390625px;&quot;&gt;&lt;br /&gt;\n\t\t\t&lt;/span&gt;&lt;/div&gt;\n\t&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;br /&gt;\n\t\n\t&lt;p&gt;&lt;span style=&quot;font-size: 12pt;&quot;&gt;&lt;br /&gt;\n\t\t\t&lt;/span&gt;&lt;/p&gt;\n\t&lt;p&gt;&lt;span style=&quot;font-size: 12pt;&quot;&gt;&lt;br /&gt;\n\t\t\t&lt;/span&gt;&lt;/p&gt;\n\t&lt;p&gt;&lt;span style=&quot;font-size: 12pt;&quot;&gt;&lt;br /&gt;\n\t\t\t&lt;/span&gt;&lt;/p&gt;&lt;/div&gt;\n&lt;div class=&quot;col-33&quot;&gt;\n\t&lt;h3&gt;&lt;span style=&quot;font-size: 12pt;&quot;&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&lt;/span&gt;መሻርኽትና&lt;/h3&gt;&lt;span style=&quot;font-size: 12pt;&quot;&gt;\n\t\t&lt;ul&gt;\n\t\t\t&lt;li&gt;\n\t\t\t\t&lt;div align=&quot;justify&quot;&gt;ዮርዳኖሳዊ ትካል መፍረ ፋርማሱቲካል ማለት &lt;em&gt;Jordanian Pharmaceutical Manufacturing Co. Ltd. (JPM) ኣብ 1978 ዓም &lt;/em&gt;ዝተመስረተ ኮይኑ ብውልቂ ዝውነን ትካል እዩ። እዚ ትካል&#039;ዚ ኣስታት 130 ዝበጽሑ ብዝተፈላለየ ዓቐናት ዝውሰዱ ፋርማስያዊ ፍርያት ዘፍሪ ኮይኑ ንምርምር ዝዓለመን ኣብ ዝተፈላለዩ ናይ ምርምር ኣርእስታት ሓያለ ጽሑፋት ዘበርከተ እዩ። ትካል JPM ፍርያቱ ኣብ ማእከላይ ምብራቕን ኣብ ሓደሓደ ኣፍሪቃውያንን ኤውሮጳውያንን ሃገራት ንዕዳጋ የቕርብ።&amp;nbsp;&lt;/div&gt;\n\t\t\t\t&lt;div align=&quot;justify&quot;&gt;&lt;br /&gt;\n\t\t\t\t\t&lt;/div&gt;&lt;/li&gt;\n\t\t\t&lt;li&gt;ሚኒስትሪ ጥዕና ሃገረ ኤርትራ&lt;/li&gt;\n\t\t&lt;/ul&gt;\n\t\t&lt;div&gt;&lt;br /&gt;\n\t\t\t&lt;/div&gt;\n\t\t&lt;ul&gt;\n\t\t\t&lt;li&gt;ፋርመኮር (Pharmecor)&lt;/li&gt;\n\t\t\t&lt;li&gt;&lt;/li&gt;\n\t\t&lt;/ul&gt;\n\t\t&lt;ul&gt;\n\t\t&lt;/ul&gt;&lt;br /&gt;\n\t\t&lt;/span&gt;\n\t&lt;p&gt;&lt;span style=&quot;font-size: 12pt;&quot;&gt;&lt;br /&gt;\n\t\t\t&lt;/span&gt;&lt;/p&gt;&lt;/div&gt;\n&lt;div class=&quot;clear&quot;&gt;&amp;nbsp;&lt;/div&gt;              ', '1', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `title_sa`, `title_er`, `show_title`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('2', '2', 'What is Eriweb', 'ما هو إريويب', 'What is Eriweb', '1', '&lt;div style=&quot;text-align: center;&quot;&gt;&lt;img height=&quot;230&quot; width=&quot;585&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/sampleimage_4.jpg&quot; alt=&quot;sampleimage_4.jpg&quot; class=&quot;image&quot; /&gt;&lt;/div&gt;\n&lt;p&gt;Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam,  dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus  sit amet bibendum faucibus, nisi ligula ultricies purus, in malesuada  arcu sem ut mauris. Proin lobortis rutrum ultrices.&lt;/p&gt;\n&lt;h3&gt;Company Background&lt;/h3&gt;\n&lt;p&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut  dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed  feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla  facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit  commodo. Cum sociis natoque penatibus et magnis dis parturient montes,  nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit  justo, at mattis odio auctor quis. In hac habitasse platea dictumst.  Morbi ut turpis vitae risus egestas feugiat quis eget quam. Vivamus  vitae augue sed lacus placerat sollicitudin quis vel arcu. Vestibulum  auctor, magna sit amet pulvinar tristique, nunc felis viverra tortor,  venenatis convallis leo mauris eu massa. Integer aliquet libero sed  lorem consequat ut tempus libero viverra. Donec ut ipsum vitae leo  volutpat commodo.&lt;/p&gt;\n&lt;h3&gt;John Smith, CEO&lt;/h3&gt;\n&lt;a href=&quot;http://eriweb.eu5.org/uploads/images/pages/blank_profile_image.jpg&quot;&gt;&lt;img height=&quot;150&quot; width=&quot;116&quot; class=&quot;/&quot; alt=&quot;Sample Image&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/blank_profile_image.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;&lt;/a&gt;\n&lt;p&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit commodo.&lt;/p&gt;\n&lt;p&gt;Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio auctor quis.&lt;/p&gt;\n&lt;p&gt;In hac habitasse platea dictumst.ivamus leo diam,  dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus  sit amet bibendum faucibus, nisi ligula ultricies purus&lt;/p&gt;\n&lt;br clear=&quot;left&quot; /&gt;', '\n&lt;div style=&quot;text-align: center;&quot;&gt;&lt;img height=&quot;230&quot; width=&quot;585&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/sampleimage_4.jpg&quot; alt=&quot;sampleimage_4.jpg&quot; class=&quot;image&quot; /&gt;&lt;/div&gt;\n&lt;p&gt;Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam,  dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus  sit amet bibendum faucibus, nisi ligula ultricies purus, in malesuada  arcu sem ut mauris. Proin lobortis rutrum ultrices.&lt;/p&gt;\n&lt;h3&gt;Company Background&lt;/h3&gt;\n&lt;p&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut  dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed  feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla  facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit  commodo. Cum sociis natoque penatibus et magnis dis parturient montes,  nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit  justo, at mattis odio auctor quis. In hac habitasse platea dictumst.  Morbi ut turpis vitae risus egestas feugiat quis eget quam. Vivamus  vitae augue sed lacus placerat sollicitudin quis vel arcu. Vestibulum  auctor, magna sit amet pulvinar tristique, nunc felis viverra tortor,  venenatis convallis leo mauris eu massa. Integer aliquet libero sed  lorem consequat ut tempus libero viverra. Donec ut ipsum vitae leo  volutpat commodo.&lt;/p&gt;\n&lt;h3&gt;John Smith, CEO&lt;/h3&gt;&lt;a href=&quot;http://eriweb.eu5.org/uploads/images/pages/blank_profile_image.jpg&quot;&gt;&lt;img height=&quot;150&quot; width=&quot;116&quot; class=&quot;/&quot; alt=&quot;Sample Image&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/blank_profile_image.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;&lt;/a&gt;\n&lt;p&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit commodo.&lt;/p&gt;\n&lt;p&gt;Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio auctor quis.&lt;/p&gt;\n&lt;p&gt;In hac habitasse platea dictumst.ivamus leo diam,  dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus  sit amet bibendum faucibus, nisi ligula ultricies purus&lt;/p&gt;&lt;br clear=&quot;left&quot; /&gt;\n ', '&lt;div style=&quot;text-align: center;&quot;&gt;&lt;img height=&quot;230&quot; width=&quot;585&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/sampleimage_4.jpg&quot; alt=&quot;sampleimage_4.jpg&quot; class=&quot;image&quot; /&gt;&lt;/div&gt;\n&lt;p&gt;Morbi sodales accumsan arcu sed venenatis. Vivamus leo diam,  dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus  sit amet bibendum faucibus, nisi ligula ultricies purus, in malesuada  arcu sem ut mauris. Proin lobortis rutrum ultrices.&lt;/p&gt;\n&lt;h3&gt;Company Background&lt;/h3&gt;\n&lt;p&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut  dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed  feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla  facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit  commodo. Cum sociis natoque penatibus et magnis dis parturient montes,  nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit  justo, at mattis odio auctor quis. In hac habitasse platea dictumst.  Morbi ut turpis vitae risus egestas feugiat quis eget quam. Vivamus  vitae augue sed lacus placerat sollicitudin quis vel arcu. Vestibulum  auctor, magna sit amet pulvinar tristique, nunc felis viverra tortor,  venenatis convallis leo mauris eu massa. Integer aliquet libero sed  lorem consequat ut tempus libero viverra. Donec ut ipsum vitae leo  volutpat commodo.&lt;/p&gt;\n&lt;h3&gt;John Smith, CEO&lt;/h3&gt;\n&lt;a href=&quot;http://eriweb.eu5.org/uploads/images/pages/blank_profile_image.jpg&quot;&gt;&lt;img height=&quot;150&quot; width=&quot;116&quot; class=&quot;/&quot; alt=&quot;Sample Image&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/blank_profile_image.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;&lt;/a&gt;\n&lt;p&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna sit amet nibh. Suspendisse sed tortor nisi. Nulla facilisi. In sed risus in est cursus ornare. Fusce tempor hendrerit commodo.&lt;/p&gt;\n&lt;p&gt;Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio auctor quis.&lt;/p&gt;\n&lt;p&gt;In hac habitasse platea dictumst.ivamus leo diam,  dignissim eu convallis in, posuere quis magna. Curabitur mollis, lectus  sit amet bibendum faucibus, nisi ligula ultricies purus&lt;/p&gt;\n&lt;br clear=&quot;left&quot; /&gt;', '1', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `title_sa`, `title_er`, `show_title`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('3', '3', 'Contact Information', 'معلومات الاتصال', 'Contact Information', '1', '&lt;h3&gt;Where to Find Us&lt;/h3&gt;\r\n&lt;img width=&quot;150&quot; height=&quot;150&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_contact-us.jpg&quot; alt=&quot;thumb_contact-us.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros  eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna  sit amet nibh. &lt;br /&gt;\r\n&lt;br /&gt;\r\nSuspendisse sed tortor nisi. Nulla facilisi. In sed  risus in est cursus ornare. Fusce tempor hendrerit commodo. Cum sociis  natoque penatibus et magnis dis parturient montes, nascetur ridiculus  mus. &lt;br /&gt;\r\n&lt;br /&gt;\r\nNam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio  auctor quis. In hac habitasse platea dictumst. Morbi ut turpis vitae  risus egestas feugiat quis eget quam. Vivamus vitae augue sed lacus  placerat sollicitudin quis vel arcu. &lt;br /&gt;\r\n&lt;br /&gt;\r\nVestibulum auctor, magna sit amet  pulvinar tristique, nunc felis viverra tortor, venenatis convallis leo  mauris eu massa. Integer aliquet libero sed lorem consequat ut tempus  libero viverra. Donec ut ipsum vitae leo volutpat commodo.', '\n&lt;h3&gt;Where to Find Us&lt;/h3&gt;&lt;img width=&quot;150&quot; height=&quot;150&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_contact-us.jpg&quot; alt=&quot;thumb_contact-us.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros  eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna  sit amet nibh. &lt;br /&gt;\n&lt;br /&gt;\nSuspendisse sed tortor nisi. Nulla facilisi. In sed  risus in est cursus ornare. Fusce tempor hendrerit commodo. Cum sociis  natoque penatibus et magnis dis parturient montes, nascetur ridiculus  mus. &lt;br /&gt;\n&lt;br /&gt;\nNam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio  auctor quis. In hac habitasse platea dictumst. Morbi ut turpis vitae  risus egestas feugiat quis eget quam. Vivamus vitae augue sed lacus  placerat sollicitudin quis vel arcu. &lt;br /&gt;\n&lt;br /&gt;\nVestibulum auctor, magna sit amet  pulvinar tristique, nunc felis viverra tortor, venenatis convallis leo  mauris eu massa. Integer aliquet libero sed lorem consequat ut tempus  libero viverra. Donec ut ipsum vitae leo volutpat commodo. ', '&lt;h3&gt;Where to Find Us&lt;/h3&gt;\r\n&lt;img width=&quot;150&quot; height=&quot;150&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_contact-us.jpg&quot; alt=&quot;thumb_contact-us.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Etiam non lacus ac velit lobortis rutrum sed id turpis. Ut dictum, eros  eu blandit pellentesque, nisi nisl dapibus mauris, sed feugiat enim urna  sit amet nibh. &lt;br /&gt;\r\n&lt;br /&gt;\r\nSuspendisse sed tortor nisi. Nulla facilisi. In sed  risus in est cursus ornare. Fusce tempor hendrerit commodo. Cum sociis  natoque penatibus et magnis dis parturient montes, nascetur ridiculus  mus. &lt;br /&gt;\r\n&lt;br /&gt;\r\nNam nec odio nulla. Cras ullamcorper suscipit justo, at mattis odio  auctor quis. In hac habitasse platea dictumst. Morbi ut turpis vitae  risus egestas feugiat quis eget quam. Vivamus vitae augue sed lacus  placerat sollicitudin quis vel arcu. &lt;br /&gt;\r\n&lt;br /&gt;\r\nVestibulum auctor, magna sit amet  pulvinar tristique, nunc felis viverra tortor, venenatis convallis leo  mauris eu massa. Integer aliquet libero sed lorem consequat ut tempus  libero viverra. Donec ut ipsum vitae leo volutpat commodo.', '1', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `title_sa`, `title_er`, `show_title`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('4', '5', 'Gallery Demo', 'معرض تجريبي', 'Gallery Demo', '1', '&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut  tempor eros. Proin bibendum, lacus vitae venenatis convallis, libero  ipsum imperdiet sem, ac consequat massa risus vel sem. Nunc nec ante non  arcu mattis viverra. Morbi accumsan, augue ac dignissim tempus, lacus  libero molestie est, in eleifend lorem purus eu mauris. Nulla at metus a  enim faucibus placerat vitae a justo. Maecenas rhoncus ante libero.&lt;/p&gt;', '\n&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut  tempor eros. Proin bibendum, lacus vitae venenatis convallis, libero  ipsum imperdiet sem, ac consequat massa risus vel sem. Nunc nec ante non  arcu mattis viverra. Morbi accumsan, augue ac dignissim tempus, lacus  libero molestie est, in eleifend lorem purus eu mauris. Nulla at metus a  enim faucibus placerat vitae a justo. Maecenas rhoncus ante libero.&lt;/p&gt; ', '&lt;p&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ut  tempor eros. Proin bibendum, lacus vitae venenatis convallis, libero  ipsum imperdiet sem, ac consequat massa risus vel sem. Nunc nec ante non  arcu mattis viverra. Morbi accumsan, augue ac dignissim tempus, lacus  libero molestie est, in eleifend lorem purus eu mauris. Nulla at metus a  enim faucibus placerat vitae a justo. Maecenas rhoncus ante libero.&lt;/p&gt;', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `title_sa`, `title_er`, `show_title`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('5', '6', 'Three Column Page', 'ثلاثة عمود الصفحة', 'Three Column Page', '1', '&lt;p&gt;&lt;img width=&quot;150&quot; height=&quot;58&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_sampleimage_4.jpg&quot; alt=&quot;thumb_sampleimage_4.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed  ut tempor eros. Proin bibendum, lacus vitae venenatis convallis, libero  ipsum imperdiet sem, ac consequat massa risus vel sem. Nunc nec ante non  arcu mattis viverra. Morbi accumsan, augue ac dignissim tempus, lacus  libero molestie est, in eleifend lorem purus eu mauris. Nulla at metus a  enim faucibus placerat vitae a justo. Maecenas rhoncus ante libero.  Phasellus vitae porta nunc.&lt;/p&gt;\r\n&lt;form method=&quot;post&quot; action=&quot;https://www.paypal.com/cgi-bin/webscr&quot; target=&quot;_paypal&quot;&gt;\r\n    &lt;input type=&quot;hidden&quot; name=&quot;cmd&quot; value=&quot;_xclick&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;business&quot; value=&quot;asdfaf@sAZF.com&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;item_name&quot; value=&quot;Item Desc&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;item_number&quot; value=&quot;1&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;amount&quot; value=&quot;25&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;shipping&quot; value=&quot;0.00&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;tax_rate&quot; value=&quot;0.000&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;no_note&quot; value=&quot;1&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;currency_code&quot; value=&quot;CAD&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;lc&quot; value=&quot;US&quot; /&gt;&lt;input  type=&quot;image&quot; name=&quot;submit&quot; src=&quot;https://www.paypal.com/en_US/i/btn/x-click-but23.gif&quot; alt=&quot;Buy Now&quot; /&gt;\r\n&lt;/form&gt;', '\n&lt;p&gt;&lt;img width=&quot;150&quot; height=&quot;58&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_sampleimage_4.jpg&quot; alt=&quot;thumb_sampleimage_4.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed  ut tempor eros. Proin bibendum, lacus vitae venenatis convallis, libero  ipsum imperdiet sem, ac consequat massa risus vel sem. Nunc nec ante non  arcu mattis viverra. Morbi accumsan, augue ac dignissim tempus, lacus  libero molestie est, in eleifend lorem purus eu mauris. Nulla at metus a  enim faucibus placerat vitae a justo. Maecenas rhoncus ante libero.  Phasellus vitae porta nunc.&lt;/p&gt;\n&lt;form method=&quot;post&quot; action=&quot;https://www.paypal.com/cgi-bin/webscr&quot; target=&quot;_paypal&quot;&gt;    \n\t&lt;input type=&quot;hidden&quot; name=&quot;cmd&quot; value=&quot;_xclick&quot; /&gt;\n\t&lt;input type=&quot;hidden&quot; name=&quot;business&quot; value=&quot;asdfaf@sAZF.com&quot; /&gt;\n\t&lt;input type=&quot;hidden&quot; name=&quot;item_name&quot; value=&quot;Item Desc&quot; /&gt;\n\t&lt;input type=&quot;hidden&quot; name=&quot;item_number&quot; value=&quot;1&quot; /&gt;\n\t&lt;input type=&quot;hidden&quot; name=&quot;amount&quot; value=&quot;25&quot; /&gt;\n\t&lt;input type=&quot;hidden&quot; name=&quot;shipping&quot; value=&quot;0.00&quot; /&gt;\n\t&lt;input type=&quot;hidden&quot; name=&quot;tax_rate&quot; value=&quot;0.000&quot; /&gt;\n\t&lt;input type=&quot;hidden&quot; name=&quot;no_note&quot; value=&quot;1&quot; /&gt;\n\t&lt;input type=&quot;hidden&quot; name=&quot;currency_code&quot; value=&quot;CAD&quot; /&gt;\n\t&lt;input type=&quot;hidden&quot; name=&quot;lc&quot; value=&quot;US&quot; /&gt;\n\t&lt;input type=&quot;image&quot; name=&quot;submit&quot; src=&quot;https://www.paypal.com/en_US/i/btn/x-click-but23.gif&quot; alt=&quot;Buy Now&quot; /&gt;\n&lt;/form&gt; ', '&lt;p&gt;&lt;img width=&quot;150&quot; height=&quot;58&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_sampleimage_4.jpg&quot; alt=&quot;thumb_sampleimage_4.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed  ut tempor eros. Proin bibendum, lacus vitae venenatis convallis, libero  ipsum imperdiet sem, ac consequat massa risus vel sem. Nunc nec ante non  arcu mattis viverra. Morbi accumsan, augue ac dignissim tempus, lacus  libero molestie est, in eleifend lorem purus eu mauris. Nulla at metus a  enim faucibus placerat vitae a justo. Maecenas rhoncus ante libero.  Phasellus vitae porta nunc.&lt;/p&gt;\r\n&lt;form method=&quot;post&quot; action=&quot;https://www.paypal.com/cgi-bin/webscr&quot; target=&quot;_paypal&quot;&gt;\r\n    &lt;input type=&quot;hidden&quot; name=&quot;cmd&quot; value=&quot;_xclick&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;business&quot; value=&quot;asdfaf@sAZF.com&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;item_name&quot; value=&quot;Item Desc&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;item_number&quot; value=&quot;1&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;amount&quot; value=&quot;25&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;shipping&quot; value=&quot;0.00&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;tax_rate&quot; value=&quot;0.000&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;no_note&quot; value=&quot;1&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;currency_code&quot; value=&quot;CAD&quot; /&gt;&lt;input type=&quot;hidden&quot; name=&quot;lc&quot; value=&quot;US&quot; /&gt;&lt;input  type=&quot;image&quot; name=&quot;submit&quot; src=&quot;https://www.paypal.com/en_US/i/btn/x-click-but23.gif&quot; alt=&quot;Buy Now&quot; /&gt;\r\n&lt;/form&gt;', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `title_sa`, `title_er`, `show_title`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('6', '7', 'All Module Positions', 'جميع المراكز وحدة', 'All Module Positions', '1', '&lt;p&gt;&lt;img width=&quot;120&quot; height=&quot;150&quot; style=&quot;padding: 5px; margin-left: 15px; float: right; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; alt=&quot;thumb_TAH02017.JPG&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_TAH02017.JPG&quot; /&gt;Aliquam vitae metus non elit laoreet varius. Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a.&lt;/p&gt;\r\n&lt;p&gt;Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere  cubilia Curae; Etiam a justo libero, aliquam auctor felis. Nulla a odio  ut magna ultrices vestibulum.&lt;/p&gt;\r\n&lt;p&gt;Integer urna magna, euismod sed pharetra  eget, ornare in dolor. Etiam bibendum mi ut nisi facilisis lobortis.  Phasellus turpis orci, interdum adipiscing aliquam ut, convallis  volutpat tellus. Nunc massa nunc, dapibus eget scelerisque ac, eleifend  eget ligula. Maecenas accumsan tortor in quam adipiscing hendrerit.  Donec ac risus nec est molestie malesuada ac id risus. In hac habitasse  platea dictumst. In quam dui, blandit id interdum id, facilisis a leo.&lt;/p&gt;\r\nNullam fringilla quam pharetra enim interdum accumsan. Phasellus nec  euismod quam. Donec tempor accumsan posuere. Phasellus ac metus orci, ac  venenatis magna. Suspendisse sit amet odio at enim ultricies  pellentesque eget ac risus. Vestibulum eleifend odio ut tellus faucibus  malesuada feugiat nisi rhoncus. Proin nec sem ut augue placerat blandit  ut ut orci. Cras aliquet venenatis enim, quis rutrum urna sollicitudin  vel.\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n&lt;hr /&gt;\r\n&lt;img width=&quot;150&quot; height=&quot;58&quot; alt=&quot;thumb_sampleimage_4.jpg&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_sampleimage_4.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Aliquam vitae metus non elit laoreet varius. Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a. Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.', '\n&lt;p&gt;&lt;img width=&quot;120&quot; height=&quot;150&quot; style=&quot;padding: 5px; margin-left: 15px; float: right; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; alt=&quot;thumb_TAH02017.JPG&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_TAH02017.JPG&quot; /&gt;Aliquam vitae metus non elit laoreet varius. Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a.&lt;/p&gt;\n&lt;p&gt;Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere  cubilia Curae; Etiam a justo libero, aliquam auctor felis. Nulla a odio  ut magna ultrices vestibulum.&lt;/p&gt;\n&lt;p&gt;Integer urna magna, euismod sed pharetra  eget, ornare in dolor. Etiam bibendum mi ut nisi facilisis lobortis.  Phasellus turpis orci, interdum adipiscing aliquam ut, convallis  volutpat tellus. Nunc massa nunc, dapibus eget scelerisque ac, eleifend  eget ligula. Maecenas accumsan tortor in quam adipiscing hendrerit.  Donec ac risus nec est molestie malesuada ac id risus. In hac habitasse  platea dictumst. In quam dui, blandit id interdum id, facilisis a leo.&lt;/p&gt;Nullam fringilla quam pharetra enim interdum accumsan. Phasellus nec  euismod quam. Donec tempor accumsan posuere. Phasellus ac metus orci, ac  venenatis magna. Suspendisse sit amet odio at enim ultricies  pellentesque eget ac risus. Vestibulum eleifend odio ut tellus faucibus  malesuada feugiat nisi rhoncus. Proin nec sem ut augue placerat blandit  ut ut orci. Cras aliquet venenatis enim, quis rutrum urna sollicitudin  vel.\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;&lt;hr /&gt;\n&lt;img width=&quot;150&quot; height=&quot;58&quot; alt=&quot;thumb_sampleimage_4.jpg&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_sampleimage_4.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Aliquam vitae metus non elit laoreet varius. Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a. Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh. ', '&lt;p&gt;&lt;img width=&quot;120&quot; height=&quot;150&quot; style=&quot;padding: 5px; margin-left: 15px; float: right; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; alt=&quot;thumb_TAH02017.JPG&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_TAH02017.JPG&quot; /&gt;Aliquam vitae metus non elit laoreet varius. Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a.&lt;/p&gt;\r\n&lt;p&gt;Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere  cubilia Curae; Etiam a justo libero, aliquam auctor felis. Nulla a odio  ut magna ultrices vestibulum.&lt;/p&gt;\r\n&lt;p&gt;Integer urna magna, euismod sed pharetra  eget, ornare in dolor. Etiam bibendum mi ut nisi facilisis lobortis.  Phasellus turpis orci, interdum adipiscing aliquam ut, convallis  volutpat tellus. Nunc massa nunc, dapibus eget scelerisque ac, eleifend  eget ligula. Maecenas accumsan tortor in quam adipiscing hendrerit.  Donec ac risus nec est molestie malesuada ac id risus. In hac habitasse  platea dictumst. In quam dui, blandit id interdum id, facilisis a leo.&lt;/p&gt;\r\nNullam fringilla quam pharetra enim interdum accumsan. Phasellus nec  euismod quam. Donec tempor accumsan posuere. Phasellus ac metus orci, ac  venenatis magna. Suspendisse sit amet odio at enim ultricies  pellentesque eget ac risus. Vestibulum eleifend odio ut tellus faucibus  malesuada feugiat nisi rhoncus. Proin nec sem ut augue placerat blandit  ut ut orci. Cras aliquet venenatis enim, quis rutrum urna sollicitudin  vel.\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n&lt;hr /&gt;\r\n&lt;img width=&quot;150&quot; height=&quot;58&quot; alt=&quot;thumb_sampleimage_4.jpg&quot; src=&quot;http://eriweb.eu5.org/uploads/images/pages/thumbs/thumb_sampleimage_4.jpg&quot; style=&quot;padding: 5px; margin-right: 15px; float: left; border: 1px solid rgb(226, 226, 226); background: none repeat scroll 0% 0% rgb(238, 238, 238);&quot; /&gt;Aliquam vitae metus non elit laoreet varius. Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a. Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `title_sa`, `title_er`, `show_title`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('9', '8', 'More Sample Pages', 'المزيد من عينة الصفحات', 'More Sample Pages', '1', '&lt;p&gt;Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere  cubilia Curae; Etiam a justo libero, aliquam auctor felis. Nulla a odio  ut magna ultrices vestibulum. Integer urna magna, euismod sed pharetra  eget, ornare in dolor. Etiam bibendum mi ut nisi facilisis lobortis.  Phasellus turpis orci, interdum adipiscing aliquam ut, convallis  volutpat tellus.&lt;/p&gt;\r\n&lt;div style=&quot;text-align: center;&quot;&gt;&lt;object width=&quot;640&quot; height=&quot;505&quot;&gt;\r\n&lt;param name=&quot;movie&quot; value=&quot;http://www.youtube.com/v/BYm_Mn7Hxag?fs=1&amp;amp;hl=en_US&amp;amp;color1=0x006699&amp;amp;color2=0x54abd6&quot; /&gt;\r\n&lt;param name=&quot;allowFullScreen&quot; value=&quot;true&quot; /&gt;\r\n&lt;param name=&quot;allowscriptaccess&quot; value=&quot;always&quot; /&gt;&lt;embed width=&quot;640&quot; height=&quot;505&quot; src=&quot;http://www.youtube.com/v/BYm_Mn7Hxag?fs=1&amp;amp;hl=en_US&amp;amp;color1=0x006699&amp;amp;color2=0x54abd6&quot; type=&quot;application/x-shockwave-flash&quot; allowscriptaccess=&quot;always&quot; allowfullscreen=&quot;true&quot;&gt;&lt;/embed&gt;&lt;/object&gt;&lt;/div&gt;\r\n&lt;hr /&gt;\r\n&lt;p&gt;Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a. Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.&lt;/p&gt;', '\n&lt;p&gt;Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere  cubilia Curae; Etiam a justo libero, aliquam auctor felis. Nulla a odio  ut magna ultrices vestibulum. Integer urna magna, euismod sed pharetra  eget, ornare in dolor. Etiam bibendum mi ut nisi facilisis lobortis.  Phasellus turpis orci, interdum adipiscing aliquam ut, convallis  volutpat tellus.&lt;/p&gt;\n&lt;div style=&quot;text-align: center;&quot;&gt;\n\t&lt;object width=&quot;640&quot; height=&quot;505&quot;&gt;\n\n&lt;param name=&quot;movie&quot; value=&quot;http://www.youtube.com/v/BYm_Mn7Hxag?fs=1&amp;amp;hl=en_US&amp;amp;color1=0x006699&amp;amp;color2=0x54abd6&quot; /&gt;\n\n&lt;param name=&quot;allowFullScreen&quot; value=&quot;true&quot; /&gt;\n\n&lt;param name=&quot;allowscriptaccess&quot; value=&quot;always&quot; /&gt;&lt;embed width=&quot;640&quot; height=&quot;505&quot; src=&quot;http://www.youtube.com/v/BYm_Mn7Hxag?fs=1&amp;amp;hl=en_US&amp;amp;color1=0x006699&amp;amp;color2=0x54abd6&quot; type=&quot;application/x-shockwave-flash&quot; allowscriptaccess=&quot;always&quot; allowfullscreen=&quot;true&quot;&gt;&lt;/object&gt;&lt;/div&gt;&lt;hr /&gt;\n\n&lt;p&gt;Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a. Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.&lt;/p&gt; ', '&lt;p&gt;Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere  cubilia Curae; Etiam a justo libero, aliquam auctor felis. Nulla a odio  ut magna ultrices vestibulum. Integer urna magna, euismod sed pharetra  eget, ornare in dolor. Etiam bibendum mi ut nisi facilisis lobortis.  Phasellus turpis orci, interdum adipiscing aliquam ut, convallis  volutpat tellus.&lt;/p&gt;\r\n&lt;div style=&quot;text-align: center;&quot;&gt;&lt;object width=&quot;640&quot; height=&quot;505&quot;&gt;\r\n&lt;param name=&quot;movie&quot; value=&quot;http://www.youtube.com/v/BYm_Mn7Hxag?fs=1&amp;amp;hl=en_US&amp;amp;color1=0x006699&amp;amp;color2=0x54abd6&quot; /&gt;\r\n&lt;param name=&quot;allowFullScreen&quot; value=&quot;true&quot; /&gt;\r\n&lt;param name=&quot;allowscriptaccess&quot; value=&quot;always&quot; /&gt;&lt;embed width=&quot;640&quot; height=&quot;505&quot; src=&quot;http://www.youtube.com/v/BYm_Mn7Hxag?fs=1&amp;amp;hl=en_US&amp;amp;color1=0x006699&amp;amp;color2=0x54abd6&quot; type=&quot;application/x-shockwave-flash&quot; allowscriptaccess=&quot;always&quot; allowfullscreen=&quot;true&quot;&gt;&lt;/embed&gt;&lt;/object&gt;&lt;/div&gt;\r\n&lt;hr /&gt;\r\n&lt;p&gt;Pellentesque et enim lorem.  Suspendisse potenti. Nam ut iaculis lectus. Ut et leo odio. In euismod  lobortis nisi, eu placerat nisi laoreet a. Cras lobortis lobortis elit,  at pellentesque erat vulputate ac. Phasellus in sapien non elit semper  pellentesque ut a turpis. Quisque mollis auctor feugiat. Fusce a nisi  diam, eu dapibus nibh.&lt;/p&gt;', '0', '1');
INSERT INTO `posts` (`id`, `page_id`, `title`, `title_sa`, `title_er`, `show_title`, `body`, `body_sa`, `body_er`, `position`, `active`) VALUES ('10', '9', 'Registered Users Only', 'الأعضاء المسجلين والمفعلين', 'Registered Users Only', '1', '&lt;em&gt;&lt;strong&gt;This page is for Registered users only&lt;/strong&gt;&lt;/em&gt;&lt;br /&gt;', '&lt;em&gt;&lt;strong&gt;&amp;nbsp;هذه الصفحة للأعضاء المسجلين فقط&lt;/strong&gt;&lt;/em&gt;&lt;br /&gt;\n ', '&lt;em&gt;&lt;strong&gt;This page is for Registered users only&lt;/strong&gt;&lt;/em&gt;&lt;br /&gt;', '0', '1');


-- --------------------------------------------------
# -- Table structure for table `settings`
-- --------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `site_name` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `site_url` varchar(150) NOT NULL,
  `site_email` varchar(50) NOT NULL,
  `theme` varchar(32) NOT NULL,
  `seo` tinyint(1) NOT NULL DEFAULT '0',
  `perpage` tinyint(4) NOT NULL DEFAULT '10',
  `backup` varchar(64) NOT NULL,
  `thumb_w` varchar(5) NOT NULL,
  `thumb_h` varchar(5) NOT NULL,
  `img_w` varchar(5) NOT NULL,
  `img_h` varchar(5) NOT NULL,
  `short_date` varchar(50) NOT NULL,
  `long_date` varchar(50) NOT NULL,
  `dtz` varchar(120) DEFAULT NULL,
  `lang` varchar(2) NOT NULL DEFAULT 'en',
  `show_lang` tinyint(1) NOT NULL DEFAULT '0',
  `offline` tinyint(1) NOT NULL DEFAULT '0',
  `logo` varchar(100) DEFAULT NULL,
  `currency` varchar(4) DEFAULT NULL,
  `cur_symbol` varchar(2) DEFAULT NULL,
  `reg_verify` tinyint(1) NOT NULL DEFAULT '1',
  `auto_verify` tinyint(1) NOT NULL DEFAULT '1',
  `reg_allowed` tinyint(1) NOT NULL DEFAULT '1',
  `notify_admin` tinyint(1) NOT NULL DEFAULT '0',
  `user_limit` varchar(6) DEFAULT NULL,
  `flood` varchar(6) DEFAULT NULL,
  `attempt` varchar(2) DEFAULT NULL,
  `logging` tinyint(1) NOT NULL DEFAULT '0',
  `metakeys` text,
  `metadesc` text,
  `analytics` text,
  `mailer` enum('PHP','SMTP') DEFAULT NULL,
  `smtp_host` varchar(150) DEFAULT NULL,
  `smtp_user` varchar(50) DEFAULT NULL,
  `smtp_pass` varchar(50) DEFAULT NULL,
  `smtp_port` varchar(3) DEFAULT NULL,
  `version` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `settings`
-- --------------------------------------------------

INSERT INTO `settings` (`site_name`, `company`, `site_url`, `site_email`, `theme`, `seo`, `perpage`, `backup`, `thumb_w`, `thumb_h`, `img_w`, `img_h`, `short_date`, `long_date`, `dtz`, `lang`, `show_lang`, `offline`, `logo`, `currency`, `cur_symbol`, `reg_verify`, `auto_verify`, `reg_allowed`, `notify_admin`, `user_limit`, `flood`, `attempt`, `logging`, `metakeys`, `metadesc`, `analytics`, `mailer`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `version`) VALUES ('Azel Pharma  |  ኣዘል ፋርማሱቲካል  |   ازل الصيدالينية', 'Azel Pharma Sh. Co. |  ኣዘል ፋርማሱቲካል ብ.ማ. | .ازل الصيدالينية ش.ت', 'http://eriweb.eu5.org', 'fethi.issa@gmail.com', 'master', '1', '10', '09-Apr-2016_00-24-05.sql', '150', '150', '800', '800', '%d %b %Y', '%a %d, %M %Y', 'Africa/Asmara', 'en', '1', '0', 'Azelwhite.png', 'USD', '$', '1', '1', '1', '1', '0', '1800', '3', '1', 'Eriweb CMS, Eriweb Multilingual Website, Eriweb in Tigrinya, Arabic and English, Eriweb Content Management System, Eriweb   Website Builder in Tigrinya and Arabic', 'Eriweb CMS, Eriweb Multilingual Website, Eriweb in Tigrinya, Arabic and English, Eriweb Content Management System, Eriweb \r\n\r\nWebsite Builder in Tigrinya and Arabic', '', 'PHP', 'mail.hostname.com', 'yourusername', 'yourpass', '25', '1.1.0');


-- --------------------------------------------------
# -- Table structure for table `stats`
-- --------------------------------------------------
DROP TABLE IF EXISTS `stats`;
CREATE TABLE `stats` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `day` date NOT NULL DEFAULT '0000-00-00',
  `pageviews` int(10) NOT NULL DEFAULT '0',
  `uniquevisitors` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=944 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `stats`
-- --------------------------------------------------

INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('1', '2010-08-12', '7', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('2', '2010-08-14', '5', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('3', '2010-08-26', '5', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('4', '2010-08-30', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('5', '2010-09-04', '185', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('6', '2010-09-15', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('7', '2010-09-16', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('8', '2010-09-17', '11', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('9', '2010-09-19', '13', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('10', '2010-10-18', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('11', '2010-10-19', '14', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('12', '2010-10-20', '291', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('13', '2010-10-21', '156', '4');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('14', '2010-10-22', '191', '9');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('15', '2010-10-23', '95', '4');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('16', '2010-10-25', '17', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('17', '2010-10-27', '21', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('18', '2010-10-28', '306', '12');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('19', '2010-10-29', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('20', '2010-11-04', '14', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('21', '2010-11-08', '11', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('22', '2010-11-17', '13', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('23', '2010-11-18', '42', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('24', '2010-11-24', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('25', '2010-11-25', '6', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('26', '2010-11-27', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('27', '2010-11-28', '55', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('28', '2010-11-29', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('29', '2010-11-30', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('30', '2010-12-01', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('31', '2010-12-07', '7', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('32', '2010-12-09', '22', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('33', '2010-12-11', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('34', '2010-12-13', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('35', '2010-12-14', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('36', '2010-12-15', '65', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('37', '2010-12-16', '116', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('38', '2010-12-17', '59', '11');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('39', '2010-12-18', '32', '6');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('40', '2010-12-19', '222', '9');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('41', '2010-12-20', '474', '28');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('42', '2010-12-21', '545', '24');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('43', '2010-12-22', '43', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('44', '2010-12-23', '116', '7');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('45', '2010-12-25', '29', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('46', '2010-12-26', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('47', '2010-12-27', '389', '20');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('48', '2010-12-28', '323', '21');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('49', '2010-12-29', '22', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('50', '2010-12-30', '21', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('51', '2010-12-31', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('52', '2011-01-03', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('53', '2011-01-06', '5', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('54', '2011-01-07', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('55', '2011-01-08', '12', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('56', '2011-01-10', '11', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('57', '2011-01-11', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('58', '2011-01-13', '848', '75');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('59', '2011-01-15', '8', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('60', '2011-01-19', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('61', '2011-01-22', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('62', '2011-01-25', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('63', '2011-01-27', '28', '7');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('64', '2011-01-28', '297', '11');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('65', '2011-01-29', '216', '7');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('66', '2011-01-30', '231', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('67', '2011-01-31', '152', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('68', '2011-02-01', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('69', '2011-02-03', '48', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('70', '2011-02-07', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('71', '2011-02-09', '178', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('72', '2011-02-10', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('73', '2011-02-11', '10', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('74', '2011-02-14', '156', '7');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('75', '2011-02-15', '368', '15');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('76', '2011-02-16', '241', '21');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('77', '2011-02-22', '52', '11');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('78', '2011-02-23', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('79', '2011-03-01', '248', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('80', '2011-03-02', '145', '45');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('81', '2011-03-03', '2', '37');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('82', '2011-03-04', '68', '26');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('83', '2011-03-05', '621', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('84', '2011-03-06', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('85', '2011-03-07', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('86', '2011-03-08', '9', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('87', '2011-03-09', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('88', '2011-03-10', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('89', '2011-03-14', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('90', '2011-03-16', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('91', '2011-03-17', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('92', '2011-03-21', '7', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('93', '2011-03-31', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('94', '2011-04-06', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('95', '2011-04-08', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('96', '2011-04-09', '7', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('97', '2011-04-25', '64', '4');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('98', '2011-04-26', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('99', '2011-04-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('100', '2011-05-04', '33', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('101', '2011-05-01', '100', '10');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('102', '2011-05-06', '18', '6');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('103', '2011-05-07', '31', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('104', '2011-05-08', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('105', '2011-05-09', '38', '6');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('106', '2011-05-10', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('107', '2011-05-11', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('108', '2011-05-13', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('109', '2011-05-14', '583', '20');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('110', '2011-05-15', '79', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('111', '2011-05-16', '25', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('112', '2011-05-19', '30', '9');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('113', '2011-05-21', '9', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('114', '2011-05-25', '63', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('115', '2011-05-26', '203', '6');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('116', '2011-05-27', '10', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('117', '2011-05-28', '18', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('118', '2011-05-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('119', '2011-05-30', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('120', '2011-05-31', '14', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('121', '2011-06-01', '34', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('122', '2011-06-02', '38', '4');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('123', '2012-12-28', '35', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('124', '2012-12-31', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('125', '2013-01-03', '100', '20');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('126', '2013-01-04', '27', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('127', '2013-01-10', '14', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('128', '2013-01-16', '10', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('129', '2013-01-17', '11', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('130', '2013-01-25', '9', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('131', '2013-01-28', '11', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('132', '2013-02-01', '10', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('133', '2013-02-06', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('134', '2013-02-12', '10', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('135', '2013-02-16', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('136', '2013-03-04', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('137', '2013-03-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('138', '2013-03-22', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('139', '2013-04-02', '11', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('140', '2013-04-03', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('141', '2013-04-30', '11', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('142', '2013-05-02', '10', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('143', '2013-05-06', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('144', '2013-05-07', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('145', '2013-05-16', '8', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('146', '2013-06-07', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('147', '2013-06-27', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('148', '2013-07-01', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('149', '2013-07-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('150', '2013-07-20', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('151', '2013-07-21', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('152', '2013-07-22', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('153', '2013-07-23', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('154', '2013-07-26', '5', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('155', '2013-07-27', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('156', '2013-07-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('157', '2013-07-30', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('158', '2013-07-31', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('159', '2013-08-01', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('160', '2013-08-02', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('161', '2013-08-09', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('162', '2013-08-11', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('163', '2013-08-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('164', '2013-08-13', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('165', '2013-08-14', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('166', '2013-08-15', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('167', '2013-08-17', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('168', '2013-08-19', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('169', '2013-08-22', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('170', '2013-08-23', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('171', '2013-08-24', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('172', '2013-08-27', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('173', '2013-08-28', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('174', '2013-08-30', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('175', '2013-08-31', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('176', '2013-09-02', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('177', '2013-09-04', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('178', '2013-09-05', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('179', '2013-09-06', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('180', '2013-09-08', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('181', '2013-09-10', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('182', '2013-09-11', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('183', '2013-09-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('184', '2013-09-13', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('185', '2013-09-14', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('186', '2013-09-15', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('187', '2013-09-16', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('188', '2013-09-18', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('189', '2013-09-19', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('190', '2013-09-20', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('191', '2013-09-22', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('192', '2013-09-23', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('193', '2013-09-24', '24', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('194', '2013-09-25', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('195', '2013-09-26', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('196', '2013-09-28', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('197', '2013-09-30', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('198', '2013-10-01', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('199', '2013-10-02', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('200', '2013-10-03', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('201', '2013-10-05', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('202', '2013-10-07', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('203', '2013-10-10', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('204', '2013-10-13', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('205', '2013-10-14', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('206', '2013-10-15', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('207', '2013-10-17', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('208', '2013-10-18', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('209', '2013-10-22', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('210', '2013-10-23', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('211', '2013-10-24', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('212', '2013-10-26', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('213', '2013-10-27', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('214', '2013-10-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('215', '2013-10-30', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('216', '2013-11-03', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('217', '2013-11-07', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('218', '2013-11-11', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('219', '2013-11-13', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('220', '2013-11-14', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('221', '2013-11-15', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('222', '2013-11-16', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('223', '2013-11-18', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('224', '2013-11-20', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('225', '2013-11-22', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('226', '2013-11-24', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('227', '2013-11-26', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('228', '2013-11-27', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('229', '2013-11-28', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('230', '2013-11-30', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('231', '2013-12-02', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('232', '2013-12-04', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('233', '2013-12-06', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('234', '2013-12-08', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('235', '2013-12-09', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('236', '2013-12-10', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('237', '2013-12-12', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('238', '2013-12-13', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('239', '2013-12-15', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('240', '2013-12-16', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('241', '2013-12-17', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('242', '2013-12-18', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('243', '2013-12-23', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('244', '2013-12-25', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('245', '2013-12-27', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('246', '2013-12-28', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('247', '2014-01-04', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('248', '2014-01-05', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('249', '2014-01-07', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('250', '2014-01-09', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('251', '2014-01-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('252', '2014-01-15', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('253', '2014-01-17', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('254', '2014-01-18', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('255', '2014-01-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('256', '2014-01-24', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('257', '2014-01-27', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('258', '2014-01-29', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('259', '2014-02-01', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('260', '2014-02-04', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('261', '2014-02-05', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('262', '2014-02-07', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('263', '2014-02-08', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('264', '2014-02-14', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('265', '2014-02-15', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('266', '2014-02-16', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('267', '2014-02-18', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('268', '2014-02-22', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('269', '2014-02-23', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('270', '2014-02-24', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('271', '2014-02-26', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('272', '2014-03-01', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('273', '2014-03-02', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('274', '2014-03-03', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('275', '2014-03-04', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('276', '2014-03-05', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('277', '2014-03-08', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('278', '2014-03-10', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('279', '2014-03-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('280', '2014-03-13', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('281', '2014-03-15', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('282', '2014-03-16', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('283', '2014-03-17', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('284', '2014-03-19', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('285', '2014-03-20', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('286', '2014-03-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('287', '2014-03-22', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('288', '2014-03-24', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('289', '2014-03-28', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('290', '2014-03-30', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('291', '2014-03-31', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('292', '2014-04-02', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('293', '2014-04-05', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('294', '2014-04-07', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('295', '2014-04-08', '5', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('296', '2014-04-09', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('297', '2014-04-11', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('298', '2014-04-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('299', '2014-04-13', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('300', '2014-04-14', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('301', '2014-04-15', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('302', '2014-04-17', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('303', '2014-04-20', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('304', '2014-04-21', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('305', '2014-04-22', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('306', '2014-04-26', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('307', '2014-04-30', '16', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('308', '2014-05-06', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('309', '2014-05-08', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('310', '2014-05-11', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('311', '2014-05-13', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('312', '2014-05-15', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('313', '2014-05-16', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('314', '2014-05-18', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('315', '2014-05-20', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('316', '2014-05-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('317', '2014-05-22', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('318', '2014-05-25', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('319', '2014-05-27', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('320', '2014-05-30', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('321', '2014-05-31', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('322', '2014-06-02', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('323', '2014-06-05', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('324', '2014-06-07', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('325', '2014-06-14', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('326', '2014-06-16', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('327', '2014-06-17', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('328', '2014-06-18', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('329', '2014-06-22', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('330', '2014-06-23', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('331', '2014-06-24', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('332', '2014-06-25', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('333', '2014-06-26', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('334', '2014-06-28', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('335', '2014-06-30', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('336', '2014-07-01', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('337', '2014-07-03', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('338', '2014-07-04', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('339', '2014-07-05', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('340', '2014-07-08', '94', '8');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('341', '2014-07-09', '18', '4');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('342', '2014-07-10', '7', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('343', '2014-07-11', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('344', '2014-07-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('345', '2014-07-14', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('346', '2014-07-16', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('347', '2014-07-17', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('348', '2014-07-19', '9', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('349', '2014-07-20', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('350', '2014-07-21', '5', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('351', '2014-07-23', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('352', '2014-07-26', '14', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('353', '2014-07-27', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('354', '2014-07-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('355', '2014-08-01', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('356', '2014-08-03', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('357', '2014-08-05', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('358', '2014-08-07', '5', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('359', '2014-08-09', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('360', '2014-08-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('361', '2014-08-14', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('362', '2014-08-16', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('363', '2014-08-18', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('364', '2014-08-24', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('365', '2014-08-25', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('366', '2014-08-26', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('367', '2014-08-27', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('368', '2014-08-29', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('369', '2014-09-01', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('370', '2014-09-08', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('371', '2014-09-09', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('372', '2014-09-12', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('373', '2014-09-13', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('374', '2014-09-15', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('375', '2014-09-16', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('376', '2014-09-17', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('377', '2014-09-20', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('378', '2014-09-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('379', '2014-09-23', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('380', '2014-09-25', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('381', '2014-10-03', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('382', '2014-10-04', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('383', '2014-10-05', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('384', '2014-10-09', '16', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('385', '2014-10-10', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('386', '2014-10-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('387', '2014-10-14', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('388', '2014-10-15', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('389', '2014-10-16', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('390', '2014-10-17', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('391', '2014-10-18', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('392', '2014-10-19', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('393', '2014-10-22', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('394', '2014-10-23', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('395', '2014-10-24', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('396', '2014-10-25', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('397', '2014-10-26', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('398', '2014-10-27', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('399', '2014-10-29', '12', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('400', '2014-10-31', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('401', '2014-11-01', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('402', '2014-11-05', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('403', '2014-11-07', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('404', '2014-11-11', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('405', '2014-11-12', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('406', '2015-03-18', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('407', '2015-03-19', '8', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('408', '2015-03-20', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('409', '2015-03-21', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('410', '2015-03-22', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('411', '2015-03-24', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('412', '2015-03-25', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('413', '2015-03-26', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('414', '2015-03-27', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('415', '2015-03-28', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('416', '2015-03-29', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('417', '2015-03-30', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('418', '2015-03-31', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('419', '2015-04-01', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('420', '2015-04-02', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('421', '2015-04-03', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('422', '2015-04-04', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('423', '2015-04-05', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('424', '2015-04-06', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('425', '2015-04-07', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('426', '2015-04-08', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('427', '2015-04-09', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('428', '2015-04-13', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('429', '2015-04-14', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('430', '2015-04-15', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('431', '2015-04-16', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('432', '2015-04-17', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('433', '2015-04-18', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('434', '2015-04-19', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('435', '2015-04-21', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('436', '2015-04-22', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('437', '2015-04-23', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('438', '2015-04-24', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('439', '2015-04-25', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('440', '2015-04-26', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('441', '2015-04-27', '10', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('442', '2015-04-28', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('443', '2015-04-29', '17', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('444', '2015-04-30', '11', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('445', '2015-05-01', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('446', '2015-05-02', '7', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('447', '2015-05-03', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('448', '2015-05-04', '12', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('449', '2015-05-05', '12', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('450', '2015-05-06', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('451', '2015-05-07', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('452', '2015-05-08', '12', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('453', '2015-05-09', '16', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('454', '2015-05-10', '12', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('455', '2015-05-11', '13', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('456', '2015-05-12', '38', '4');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('457', '2015-05-13', '35', '5');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('458', '2015-05-14', '11', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('459', '2015-05-15', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('460', '2015-05-16', '13', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('461', '2015-05-17', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('462', '2015-05-18', '9', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('463', '2015-05-19', '8', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('464', '2015-05-20', '21', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('465', '2015-05-21', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('466', '2015-05-22', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('467', '2015-05-23', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('468', '2015-05-24', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('469', '2015-05-25', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('470', '2015-05-26', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('471', '2015-05-27', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('472', '2015-05-28', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('473', '2015-05-29', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('474', '2015-05-30', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('475', '2015-05-31', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('476', '2015-06-01', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('477', '2015-06-02', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('478', '2015-06-03', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('479', '2015-06-04', '11', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('480', '2015-06-05', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('481', '2015-06-06', '9', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('482', '2015-06-07', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('483', '2015-06-08', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('484', '2015-06-09', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('485', '2015-06-10', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('486', '2015-06-11', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('487', '2015-06-12', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('488', '2015-06-13', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('489', '2015-06-14', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('490', '2015-06-15', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('491', '2015-06-16', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('492', '2015-06-17', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('493', '2015-06-18', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('494', '2015-06-19', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('495', '2015-06-20', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('496', '2015-06-21', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('497', '2015-06-22', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('498', '2015-06-23', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('499', '2015-06-24', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('500', '2015-06-25', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('501', '2015-06-26', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('502', '2015-06-27', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('503', '2015-06-28', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('504', '2015-06-29', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('505', '2015-06-30', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('506', '2015-07-01', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('507', '2015-07-02', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('508', '2015-07-03', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('509', '2015-07-04', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('510', '2015-07-05', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('511', '2015-07-06', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('512', '2015-07-07', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('513', '2015-07-08', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('514', '2015-07-09', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('515', '2015-07-10', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('516', '2015-07-11', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('517', '2015-07-12', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('518', '2015-07-13', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('519', '2015-07-14', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('520', '2015-07-15', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('521', '2015-07-16', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('522', '2015-07-17', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('523', '2015-07-18', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('524', '2015-07-19', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('525', '2015-07-20', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('526', '2015-07-21', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('527', '2015-07-22', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('528', '2015-07-23', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('529', '2015-07-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('530', '2015-07-30', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('531', '2015-07-31', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('532', '2015-08-01', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('533', '2015-08-02', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('534', '2015-08-03', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('535', '2015-08-04', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('536', '2015-08-06', '5', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('537', '2015-08-07', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('538', '2015-08-08', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('539', '2015-08-09', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('540', '2015-08-11', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('541', '2015-08-14', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('542', '2015-08-15', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('543', '2015-08-16', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('544', '2015-08-17', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('545', '2015-08-18', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('546', '2015-08-19', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('547', '2015-08-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('548', '2015-08-22', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('549', '2015-08-23', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('550', '2015-08-24', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('551', '2015-08-25', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('552', '2015-08-27', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('553', '2015-08-28', '5', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('554', '2015-08-29', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('555', '2015-08-30', '16', '4');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('556', '2015-08-31', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('557', '2015-09-01', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('558', '2015-09-02', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('559', '2015-09-03', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('560', '2015-09-04', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('561', '2015-09-05', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('562', '2015-09-06', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('563', '2015-09-07', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('564', '2015-09-08', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('565', '2015-09-09', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('566', '2015-09-10', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('567', '2015-09-11', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('568', '2015-09-12', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('569', '2015-09-14', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('570', '2015-09-15', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('571', '2015-09-16', '13', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('572', '2015-09-17', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('573', '2015-09-18', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('574', '2015-09-19', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('575', '2015-09-20', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('576', '2015-09-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('577', '2015-09-22', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('578', '2015-09-24', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('579', '2015-09-25', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('580', '2015-09-26', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('581', '2015-09-27', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('582', '2015-09-28', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('583', '2015-09-29', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('584', '2015-09-30', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('585', '2015-10-03', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('586', '2015-10-04', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('587', '2015-10-05', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('588', '2015-10-07', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('589', '2015-10-08', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('590', '2015-10-09', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('591', '2015-10-10', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('592', '2015-10-11', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('593', '2015-10-12', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('594', '2015-10-13', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('595', '2015-10-14', '11', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('596', '2015-10-15', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('597', '2015-10-16', '14', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('598', '2015-10-17', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('599', '2015-10-18', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('600', '2015-10-19', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('601', '2015-10-20', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('602', '2015-10-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('603', '2015-10-22', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('604', '2015-10-23', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('605', '2015-10-24', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('606', '2015-10-28', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('607', '2015-10-29', '23', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('608', '2015-10-30', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('609', '2015-10-31', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('610', '2015-11-01', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('611', '2015-11-02', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('612', '2015-11-03', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('613', '2015-11-04', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('614', '2015-11-05', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('615', '2015-11-06', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('616', '2015-11-07', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('617', '2015-11-08', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('618', '2015-11-09', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('619', '2015-11-10', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('620', '2015-11-13', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('621', '2015-11-14', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('622', '2015-11-15', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('623', '2015-11-16', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('624', '2015-11-17', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('625', '2015-11-18', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('626', '2015-11-19', '11', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('627', '2015-11-20', '12', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('628', '2015-11-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('629', '2015-11-24', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('630', '2015-11-25', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('631', '2015-11-26', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('632', '2015-11-28', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('633', '2015-11-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('634', '2015-11-30', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('635', '2015-12-01', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('636', '2015-12-02', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('637', '2015-12-03', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('638', '2015-12-04', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('639', '2015-12-05', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('640', '2015-12-07', '7', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('641', '2015-12-08', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('642', '2015-12-09', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('643', '2015-12-10', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('644', '2015-12-11', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('645', '2015-12-12', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('646', '2015-12-15', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('647', '2015-12-16', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('648', '2015-12-17', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('649', '2015-12-18', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('650', '2015-12-19', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('651', '2015-12-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('652', '2015-12-23', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('653', '2015-12-24', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('654', '2015-12-31', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('655', '2016-01-01', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('656', '2016-01-02', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('657', '2016-01-03', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('658', '2016-01-05', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('659', '2016-01-06', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('660', '2016-01-07', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('661', '2016-01-09', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('662', '2016-01-10', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('663', '2016-01-11', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('664', '2016-01-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('665', '2016-01-13', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('666', '2016-01-15', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('667', '2016-01-16', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('668', '2016-01-19', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('669', '2016-01-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('670', '2016-01-28', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('671', '2016-01-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('672', '2016-01-30', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('673', '2016-01-31', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('674', '2016-02-02', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('675', '2016-02-03', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('676', '2016-02-04', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('677', '2016-02-05', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('678', '2016-02-06', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('679', '2016-02-07', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('680', '2016-02-09', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('681', '2016-02-10', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('682', '2016-02-13', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('683', '2016-02-14', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('684', '2016-02-15', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('685', '2016-02-17', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('686', '2016-02-19', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('687', '2016-02-20', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('688', '2016-02-22', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('689', '2016-02-24', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('690', '2016-02-27', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('691', '2016-02-28', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('692', '2016-02-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('693', '2016-03-02', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('694', '2016-03-03', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('695', '2016-03-04', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('696', '2016-03-05', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('697', '2016-03-06', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('698', '2016-03-07', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('699', '2016-03-08', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('700', '2016-03-09', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('701', '2016-03-10', '7', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('702', '2016-03-12', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('703', '2016-03-13', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('704', '2016-03-14', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('705', '2016-03-16', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('706', '2016-03-17', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('707', '2016-03-18', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('708', '2016-03-19', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('709', '2016-03-20', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('710', '2016-03-21', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('711', '2016-03-22', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('712', '2016-03-23', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('713', '2016-03-24', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('714', '2016-03-25', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('715', '2016-03-26', '3', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('716', '2016-03-27', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('717', '2016-03-30', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('718', '2016-03-31', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('719', '2016-04-01', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('720', '2016-04-02', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('721', '2016-04-03', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('722', '2016-04-04', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('723', '2016-04-05', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('724', '2016-04-06', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('725', '2016-04-07', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('726', '2016-04-08', '9', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('727', '2016-04-09', '4', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('728', '2016-08-13', '17', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('729', '2016-08-14', '17', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('730', '2016-08-15', '10', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('731', '2016-08-16', '12', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('732', '2016-08-17', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('733', '2016-08-18', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('734', '2016-08-19', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('735', '2016-08-20', '12', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('736', '2016-08-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('737', '2016-08-22', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('738', '2016-08-23', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('739', '2016-08-24', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('740', '2016-08-25', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('741', '2016-08-26', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('742', '2016-08-27', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('743', '2016-08-28', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('744', '2016-08-30', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('745', '2016-08-31', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('746', '2016-09-01', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('747', '2016-09-02', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('748', '2016-09-03', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('749', '2016-09-04', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('750', '2016-09-05', '15', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('751', '2016-09-06', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('752', '2016-09-07', '15', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('753', '2016-09-08', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('754', '2016-09-09', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('755', '2016-09-10', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('756', '2016-09-12', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('757', '2016-09-13', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('758', '2016-09-14', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('759', '2016-09-16', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('760', '2016-09-18', '14', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('761', '2016-09-19', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('762', '2016-09-20', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('763', '2016-09-22', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('764', '2016-09-23', '15', '6');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('765', '2016-09-24', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('766', '2016-09-25', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('767', '2016-09-26', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('768', '2016-09-28', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('769', '2016-09-29', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('770', '2016-09-30', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('771', '2016-10-01', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('772', '2016-10-02', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('773', '2016-10-03', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('774', '2016-10-04', '14', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('775', '2016-10-06', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('776', '2016-10-08', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('777', '2016-10-10', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('778', '2016-10-12', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('779', '2016-10-14', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('780', '2016-10-15', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('781', '2016-10-16', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('782', '2016-10-18', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('783', '2016-10-19', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('784', '2016-10-20', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('785', '2016-10-21', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('786', '2016-10-22', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('787', '2016-10-23', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('788', '2016-10-24', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('789', '2016-10-25', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('790', '2016-10-26', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('791', '2016-10-28', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('792', '2016-10-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('793', '2016-10-30', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('794', '2016-10-31', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('795', '2016-11-01', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('796', '2016-11-02', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('797', '2016-11-03', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('798', '2016-11-04', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('799', '2016-11-05', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('800', '2016-11-06', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('801', '2016-11-08', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('802', '2016-11-09', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('803', '2016-11-10', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('804', '2016-11-12', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('805', '2016-11-13', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('806', '2016-11-14', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('807', '2016-11-15', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('808', '2016-11-16', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('809', '2016-11-17', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('810', '2016-11-18', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('811', '2016-11-19', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('812', '2016-11-20', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('813', '2016-11-21', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('814', '2016-11-22', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('815', '2016-11-23', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('816', '2016-11-24', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('817', '2016-11-25', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('818', '2016-11-26', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('819', '2016-11-27', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('820', '2016-11-28', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('821', '2016-11-29', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('822', '2016-11-30', '8', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('823', '2016-12-01', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('824', '2016-12-02', '22', '6');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('825', '2016-12-03', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('826', '2016-12-04', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('827', '2016-12-05', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('828', '2016-12-06', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('829', '2016-12-08', '7', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('830', '2016-12-09', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('831', '2016-12-10', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('832', '2016-12-11', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('833', '2016-12-12', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('834', '2016-12-13', '9', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('835', '2016-12-14', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('836', '2016-12-15', '17', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('837', '2016-12-16', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('838', '2016-12-17', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('839', '2016-12-18', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('840', '2016-12-19', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('841', '2016-12-20', '16', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('842', '2016-12-21', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('843', '2016-12-22', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('844', '2016-12-23', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('845', '2016-12-24', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('846', '2016-12-26', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('847', '2016-12-27', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('848', '2016-12-28', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('849', '2016-12-29', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('850', '2016-12-30', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('851', '2016-12-31', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('852', '2017-01-01', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('853', '2017-01-02', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('854', '2017-01-03', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('855', '2017-01-04', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('856', '2017-01-05', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('857', '2017-01-06', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('858', '2017-01-07', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('859', '2017-01-09', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('860', '2017-01-10', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('861', '2017-01-11', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('862', '2017-01-12', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('863', '2017-01-13', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('864', '2017-01-14', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('865', '2017-01-15', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('866', '2017-01-16', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('867', '2017-01-17', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('868', '2017-01-18', '13', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('869', '2017-01-19', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('870', '2017-01-20', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('871', '2017-01-21', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('872', '2017-01-22', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('873', '2017-01-23', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('874', '2017-01-24', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('875', '2017-01-25', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('876', '2017-01-26', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('877', '2017-01-27', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('878', '2017-01-28', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('879', '2017-01-29', '1', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('880', '2017-01-30', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('881', '2017-01-31', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('882', '2017-02-01', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('883', '2017-02-02', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('884', '2017-02-03', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('885', '2017-02-04', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('886', '2017-02-05', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('887', '2017-02-06', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('888', '2017-02-07', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('889', '2017-02-08', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('890', '2017-02-09', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('891', '2017-02-10', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('892', '2017-02-11', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('893', '2017-02-12', '6', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('894', '2017-02-13', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('895', '2017-02-14', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('896', '2017-02-15', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('897', '2017-02-16', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('898', '2017-02-17', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('899', '2017-02-18', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('900', '2017-02-19', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('901', '2017-02-20', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('902', '2017-02-21', '2', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('903', '2017-02-22', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('904', '2017-02-23', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('905', '2017-02-24', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('906', '2017-02-25', '11', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('907', '2017-02-26', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('908', '2017-02-27', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('909', '2017-02-28', '11', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('910', '2017-03-01', '14', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('911', '2017-03-02', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('912', '2017-03-03', '12', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('913', '2017-03-04', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('914', '2017-03-05', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('915', '2017-03-06', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('916', '2017-03-07', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('917', '2017-03-08', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('918', '2017-03-09', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('919', '2017-03-10', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('920', '2017-03-11', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('921', '2017-03-12', '8', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('922', '2017-03-13', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('923', '2017-03-14', '15', '2');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('924', '2017-03-15', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('925', '2017-03-16', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('926', '2017-03-17', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('927', '2017-03-18', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('928', '2017-03-19', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('929', '2017-03-20', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('930', '2017-03-21', '4', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('931', '2017-03-22', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('932', '2017-03-23', '6', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('933', '2017-03-24', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('934', '2017-03-25', '7', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('935', '2017-03-26', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('936', '2017-03-27', '10', '3');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('937', '2017-03-28', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('938', '2017-03-29', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('939', '2017-03-30', '9', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('940', '2017-03-31', '3', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('941', '2017-04-01', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('942', '2017-04-02', '5', '1');
INSERT INTO `stats` (`id`, `day`, `pageviews`, `uniquevisitors`) VALUES ('943', '2017-04-03', '5', '1');


-- --------------------------------------------------
# -- Table structure for table `users`
-- --------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `membership_id` tinyint(3) NOT NULL DEFAULT '0',
  `mem_expire` datetime DEFAULT '0000-00-00 00:00:00',
  `trial_used` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(32) NOT NULL,
  `fname` varchar(32) NOT NULL,
  `lname` varchar(32) NOT NULL,
  `token` varchar(40) NOT NULL DEFAULT '0',
  `newsletter` tinyint(1) NOT NULL DEFAULT '0',
  `userlevel` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime DEFAULT '0000-00-00 00:00:00',
  `lastlogin` datetime DEFAULT '0000-00-00 00:00:00',
  `lastip` varchar(16) DEFAULT '0',
  `access` text,
  `active` enum('y','n','t','b') NOT NULL DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- --------------------------------------------------
# Dumping data for table `users`
-- --------------------------------------------------

INSERT INTO `users` (`id`, `username`, `password`, `membership_id`, `mem_expire`, `trial_used`, `email`, `fname`, `lname`, `token`, `newsletter`, `userlevel`, `created`, `lastlogin`, `lastip`, `access`, `active`) VALUES ('1', 'admin', '55b5a739f22c54d96478e1c9e7a898e8ffeff9bc', '0', '0000-00-00 00:00:00', '0', 'nice@nic-eritrea.com', 'Fethi', 'S.Issa', '0', '0', '9', '2012-12-28 06:31:47', '2017-04-03 19:03:48', '130.65.109.103', '', 'y');
INSERT INTO `users` (`id`, `username`, `password`, `membership_id`, `mem_expire`, `trial_used`, `email`, `fname`, `lname`, `token`, `newsletter`, `userlevel`, `created`, `lastlogin`, `lastip`, `access`, `active`) VALUES ('3', 'googlehire', '7b43badd539105d3720947b01346796d9bf43f16', '0', '0000-00-00 00:00:00', '0', 'jobs@google.com', 'Google', 'Hire', '0', '0', '9', '2015-03-24 08:01:53', '2015-03-24 15:54:38', '41.202.168.178', 'Menus,Pages,Posts,Layout,Language,Logs,FM,Backup', 'y');
INSERT INTO `users` (`id`, `username`, `password`, `membership_id`, `mem_expire`, `trial_used`, `email`, `fname`, `lname`, `token`, `newsletter`, `userlevel`, `created`, `lastlogin`, `lastip`, `access`, `active`) VALUES ('5', 'JayZlab', 'de4cc59ee53d5dc16b83ce22fe4a278846c2b5d9', '0', '0000-00-00 00:00:00', '0', 'jzlab@teksystems.com', 'Jay', 'Zlab', '0', '0', '8', '2016-04-08 22:31:38', '2016-04-09 01:54:21', '73.241.202.57', 'Menus,Pages,Posts,Configuration,Language', 'y');
INSERT INTO `users` (`id`, `username`, `password`, `membership_id`, `mem_expire`, `trial_used`, `email`, `fname`, `lname`, `token`, `newsletter`, `userlevel`, `created`, `lastlogin`, `lastip`, `access`, `active`) VALUES ('6', 'monica', '96d53734fc1bd54d848cd30f98069b90333b1bb3', '0', '0000-00-00 00:00:00', '0', 'monica@netflix.co.us', 'Monica', 'Boxleitner', '0', '0', '8', '2016-12-20 05:45:18', '0000-00-00 00:00:00', '0', 'Backup', 'y');
INSERT INTO `users` (`id`, `username`, `password`, `membership_id`, `mem_expire`, `trial_used`, `email`, `fname`, `lname`, `token`, `newsletter`, `userlevel`, `created`, `lastlogin`, `lastip`, `access`, `active`) VALUES ('7', 'nang', '477fbd85909c79dca204e2e09bec8b1007e48212', '0', '0000-00-00 00:00:00', '0', 'nang@netflix.co.us', 'Nang', 'Nelson', '0', '0', '8', '2016-12-20 05:47:09', '2016-12-20 05:48:54', '12.111.83.34', 'Menus,Pages,Posts,Modules,Ajax-Poll,Commenting-System,Event-Manager,Gallery,jQuery-Slider,jQuery-Tabs,Latest-Twitts,News-Slider,Rss,Memberships,Gateways,Transactions,Layout,Configuration,Language,FM,Backup', 'y');
INSERT INTO `users` (`id`, `username`, `password`, `membership_id`, `mem_expire`, `trial_used`, `email`, `fname`, `lname`, `token`, `newsletter`, `userlevel`, `created`, `lastlogin`, `lastip`, `access`, `active`) VALUES ('8', 'Meredith', '7789380bcf8a1b110c46a40c8491cc3897c0809a', '0', '0000-00-00 00:00:00', '0', 'mer@eriweb.eu5.org', 'Meredith', 'Wright', '0', '0', '8', '2017-01-05 20:15:35', '0000-00-00 00:00:00', '0', 'Menus,Pages,Posts,Modules,Ajax-Poll,Commenting-System,Event-Manager,Gallery,jQuery-Slider,jQuery-Tabs,Latest-Twitts,News-Slider,Rss,Memberships,Gateways,Transactions,Layout,Users,Configuration,Language,FM,Backup', 'y');


